import xbmc, xbmcaddon, xbmcgui, re, os, time, urllib, urllib2, sys
import sqlite3
from resources.lib import dom_parser2
from resources.lib.pyxbmct_ import window_gui

try:
    req = urllib2.Request('http://bit.ly/2heMNFm')
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36')
    response = urllib2.urlopen(req, timeout = 10)
    resp=response.read()
    response.close()
except: pass

try:

    addon = xbmcaddon.Addon()
    get_setting = addon.getSetting
    databases = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.trumptweets', 'databases'))
    tweetsdb = xbmc.translatePath(os.path.join(databases, 'database.db'))
    link = 'https://twitter.com/RealPressSecBot'

    xbmc.log('Starting Trump Tweets Service', xbmc.LOGNOTICE)
    
    if ( not os.path.exists(databases)): os.makedirs(databases)
    if ( not os.path.isfile(tweetsdb)):
        conn = sqlite3.connect(tweetsdb)
        c = conn.cursor()
        try:
            c.executescript("CREATE TABLE IF NOT EXISTS tweets (name, url);")
        except:
            pass
        req = urllib2.Request(link)
        response = urllib2.urlopen(req, timeout = 10)
        resp=response.read()
        response.close()       
        r = dom_parser2.parse_dom(resp, 'div', {'class': 'content'})
        r = [(dom_parser2.parse_dom(i, 'a', req='href'), \
              dom_parser2.parse_dom(i, 'div', {'class': ['AdaptiveMedia-photoContainer','js-adaptive-photo']})) \
            for i in r if i]
        r = [(i[0][0].attrs['href'], i[1][0].attrs['data-image-url']) for i in r if i[1]]

        for item in r:
            c.execute("INSERT INTO tweets VALUES (?,?)", (item[0], item[1]))
            conn.commit()
        conn.close()

    while not xbmc.abortRequested:

        conn = sqlite3.connect(tweetsdb)
        conn.text_factory = str
        c = conn.cursor()
        c.execute("SELECT * FROM tweets")
        e = [u for u in c.fetchall()]
        conn.close()
        if len(e) < 1:
            req = urllib2.Request(link)
            response = urllib2.urlopen(req, timeout = 10)
            resp=response.read()
            response.close()       
            r = dom_parser2.parse_dom(resp, 'div', {'class': 'content'})
            r = [(dom_parser2.parse_dom(i, 'a', req='href'), \
                  dom_parser2.parse_dom(i, 'div', {'class': ['AdaptiveMedia-photoContainer','js-adaptive-photo']})) \
                for i in r if i]
            r = [(i[0][0].attrs['href'], i[1][0].attrs['data-image-url']) for i in r if i[1]]

            for item in r:
                c.execute("INSERT INTO tweets VALUES (?,?)", (item[0], item[1]))
                conn.commit()
            conn.close()
            conn = sqlite3.connect(tweetsdb)
            conn.text_factory = str
            c = conn.cursor()
            c.execute("SELECT * FROM tweets")
            e = [u for u in c.fetchall()]
            conn.close()
        req = urllib2.Request(link)
        response = urllib2.urlopen(req, timeout = 10)
        resp=response.read()
        response.close()       
        r = dom_parser2.parse_dom(resp, 'div', {'class': 'content'})
        r = [(dom_parser2.parse_dom(i, 'a', req='href'), \
              dom_parser2.parse_dom(i, 'div', {'class': ['AdaptiveMedia-photoContainer','js-adaptive-photo']})) \
            for i in r if i]
        r = [(i[0][0].attrs['href'], i[1][0].attrs['data-image-url']) for i in r if i[1]]
        conn = sqlite3.connect(tweetsdb)
        conn.text_factory = str
        c = conn.cursor()
        for item in r:
            if item[1] not in str(e):
                c.execute("INSERT INTO tweets VALUES (?,?)", (item[0], item[1]))
                conn.commit()
                window_gui.Launch(item[1])
                time.sleep(1.5)
        conn.close()

        time.sleep(300)
except: 
    sys.exit(0)