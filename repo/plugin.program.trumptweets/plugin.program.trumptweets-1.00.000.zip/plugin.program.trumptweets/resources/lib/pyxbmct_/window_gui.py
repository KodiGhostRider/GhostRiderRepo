#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import re
import sys
import urllib
import urllib2
import urlparse
from resources.lib.pyxbmct import addonwindow
pyxbmct = addonwindow

#############################################################
#################### SET ADDON ID ###########################
_self_          = xbmcaddon.Addon(id='plugin.program.trumptweets')

#############################################################
########## Function To Call That Starts The Window ##########
def Launch(image):

    global display_image 
    display_image = image
    
    window = Main()
    window.doModal()
    del window

#############################################################
######### Class Containing the GUi Code / Controls ##########
class Main(pyxbmct.BlankDialogWindow):

    def __init__(self):
        super(Main, self).__init__()
		
		#set the location and size of your window in kodi
        self.setGeometry(500, 300, 100, 50)
		
		## Set The backGround Image using PYX Image
        Background			= pyxbmct.Image(display_image)
		
		## Place The BackGround Image (X, Y, W, H)
        self.placeControl(Background, -30, -15, 135, 80)
		
		## function to set active controls that users interact with 
        self.set_active_controls()
        
        self.set_info_controls()
		
        self.setFocus(self.button)
		
		## connect the back button to pyx to close window
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.connect(self.button, self.close)
        
    def set_info_controls(self):
        return
        
    def set_active_controls(self):
        self.button = pyxbmct.Button('Close')
        self.placeControl(self.button, 87,54,15,10)
        
    def setAnimation(self, control):
        control.setAnimations([('WindowOpen', 'effect=fade start=0 end=100 time=1000',),('WindowClose', 'effect=fade start=100 end=0 time=1000',)])