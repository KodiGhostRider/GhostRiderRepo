import xbmc,xbmcaddon,xbmcvfs,xbmcgui
import sys
which = sys.argv[1]

ADDON = xbmcaddon.Addon(id='script.tvguide.Assassins')

if which == "commands":
    path = xbmc.translatePath('special://home/addons/script.tvguide.Assassins/commands.txt')
elif which == "autoplaywith":
    path = xbmc.translatePath('special://home/addons/script.tvguide.Assassins/resources/playwith/readme.txt')
elif which == "Features":
    path = xbmc.translatePath('special://home/addons/script.tvguide.Assassins/Features.txt')
elif which == "Customini":
    path = xbmc.translatePath('special://home/addons/script.tvguide.Assassins/Customini.txt')
elif which == "Resets":
    path = xbmc.translatePath('special://home/addons/script.tvguide.Assassins/Resets.txt')
f = xbmcvfs.File(path,"rb")
data = f.read()
dialog = xbmcgui.Dialog()
dialog.textviewer('Help', data)
