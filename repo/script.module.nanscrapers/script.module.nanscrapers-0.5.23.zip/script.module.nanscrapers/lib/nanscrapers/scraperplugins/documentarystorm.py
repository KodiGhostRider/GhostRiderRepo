# -*- coding: utf-8 -*-
import urlparse

import requests
from BeautifulSoup import BeautifulSoup
from nanscrapers.common import clean_title, random_agent, replaceHTMLCodes
from nanscrapers.scraper import Scraper

class DocumentaryStorm(Scraper):
    domains = ['documentarystorm.com']
    name = "DocumentaryStorm"
    sources = []

    def __init__(self):
        self.base_link = 'https://documentarystorm.com'
        self.movie_search_path = '/?s=%s'

    def scrape_movie(self, title, year, imdb, debris=False):
        sources = []
        headers = {'User-Agent': random_agent()}
        query = (self.movie_search_path % title)
        query = urlparse.urljoin(self.base_link, query)
        html = BeautifulSoup(requests.get(query, headers=headers, timeout=30).content)
        containers = html.findAll('div', attrs={'class': 'tile col-md-2 col-xs-4 col-sm-3'})
        for container in containers:
            page_link = container.find('a', attrs={'class': 'btn btn-primary btn-block'})['href']
            html = BeautifulSoup(requests.get(page_link, headers=headers, timeout=30).content)
            url = html.find('iframe')['src']
            sources.append(
                {'source': 'various', 'quality': 'SD', 'scraper': self.name, 'url': url, 'direct': True})
        return sources

