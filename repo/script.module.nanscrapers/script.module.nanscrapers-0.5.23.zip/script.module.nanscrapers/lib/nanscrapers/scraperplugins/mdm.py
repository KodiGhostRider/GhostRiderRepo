import re
import requests
import xbmc
from ..scraper import Scraper

class Mydigitalmovies(Scraper):
    domains = ['mydigitalmovies.co.uk']
    name = "mydigitalmovies"
    sources = []

    def __init__(self):
        self.base_link = 'http://mydigitalmovies.co.uk'

    def scrape_movie(self, title, year, imdb, debrid = False):
        try:
            start_url = self.base_link+'/search.php?keywords='+title.replace(' ','+')+'+'+year.replace(' ','+')+'&video-id='
            html = requests.get(start_url).text
            match = re.compile('<h3><a href="(.+?)".+?title="(.+?)"').findall(html)
            for filmurl, name in match:
                if title.lower() in name.lower() and year in name.lower():
                    html2 = requests.get(filmurl).text
                    p = re.compile('<link rel="video_src" href="(.+?)"').findall(html2)
                    for playlink in p:
                        playlink = playlink.replace('http://mydigitalmovies.co.uk/uploads/videos/','')
                        self.sources.append({'source': 'mdm', 'quality': 'SD', 'scraper': self.name, 'url': playlink,'direct': True})
                        
        except:
            pass

        return self.sources
