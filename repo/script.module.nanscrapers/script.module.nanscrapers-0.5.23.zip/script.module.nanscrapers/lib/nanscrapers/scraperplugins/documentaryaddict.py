# -*- coding: utf-8 -*-
import urlparse

import requests
from BeautifulSoup import BeautifulSoup
from nanscrapers.common import clean_title, random_agent, replaceHTMLCodes
from nanscrapers.scraper import Scraper


class DocumentaryAddict(Scraper):
    domains = ['documentaryaddict.com']
    name = "DocumentaryAddict"
    sources = []

    def __init__(self):
        self.base_link = 'https://documentaryaddict.com'
        self.movie_search_path = '/films?utf8=✓&q[C_Name_cont]=%s'

    def scrape_movie(self, title, year, imdb, debris=False):
        sources = []
        headers = {'User-Agent': random_agent()}
        query = (self.movie_search_path % title)
        query = urlparse.urljoin(self.base_link, query)
        html = BeautifulSoup(requests.get(query, headers=headers, timeout=30).content)
        containers = html.findAll('div', attrs={'class': 'col-xs-12 col-sm-6 col-md-3 widget-film'})
        print len(containers)
        for container in containers:
            page_link = container.find('a')['href']
            html = BeautifulSoup(requests.get(page_link, headers=headers, timeout=30).content)
            url = html.find('meta', attrs={'itemprop': 'embedUrl'})['content']
            sources.append(
                {'source': 'youtube', 'quality': 'SD', 'scraper': self.name, 'url': url, 'direct': True})
        return sources