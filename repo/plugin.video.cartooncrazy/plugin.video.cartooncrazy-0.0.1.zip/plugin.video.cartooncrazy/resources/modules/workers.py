from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import wait
from concurrent.futures import as_completed
from resources import sources
import importlib
import urllib

class Sites:
    def __init__(self):
        self.sources = sources.__all__
        self.links = []
        
    def search(self, term):
        pool = ThreadPoolExecutor(len(sources.__all__)) # 1 per source
        cleaned = ''.join([x for x in term.replace('&','and') if any([x.isalnum(), x.isspace()])])
        # ['yes' if v == 1 else 'no' if v == 2 else 'idle' for v in l]
        futures = [pool.submit(self.thread, source, urllib.quote(term)) if not source in ['gostream','toonova','9cartoon','kisscartooneu'] 
                   else pool.submit(self.thread, source, urllib.quote_plus(cleaned)) if source in ['gostream','9cartoon']
                   else pool.submit(self.thread, source, urllib.quote_plus(term)) for source in self.sources]
        [self.links.extend(r.result()) for r in as_completed(futures)]
        print list(self.links)
        return self.links
        
    def thread(self, source, term):
        print '=====searching for ({}) on ({})====='.format(term,source)
        source = importlib.import_module('.'+source, package='resources.sources')
        return source.SEARCH(term)