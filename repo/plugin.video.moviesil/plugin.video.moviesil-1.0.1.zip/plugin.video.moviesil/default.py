# -*- coding: utf-8 -*-
#------------------------------------------------------------
# The Movies IL Addon By ToMeR | 
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: ToMeR © Movies IL
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.moviesil'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PLiRWC7Q54Gip9icb8RHdeAhr6PMjX_c8M"
YOUTUBE_CHANNEL_ID_2 = "PLiRWC7Q54GirohaedaEQGnz57YGPNI-Cu"
YOUTUBE_CHANNEL_ID_3 = "PLiRWC7Q54Gip5WWLh6cU4f2t_8MxQTfEX"
YOUTUBE_CHANNEL_ID_4 = ""


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="סרטים ישראליים - לצפייה לחצו כאן - מתעדכן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="http://i1064.photobucket.com/albums/u363/tomer198585/icon_zpshxysvra7.png",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="סרטי אסקימו לימון-מתעדכן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="http://i1064.photobucket.com/albums/u363/tomer198585/logo_zpsnhnwwdp8.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="ילדים - נוסטלגיה - מתעדכן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="http://i1064.photobucket.com/albums/u363/tomer198585/_zps7wf0zhae.jpg",
        folder=True )        
              
    plugintools.add_item( 
        #action="", 
        title="בקרוב הפתעות חדשות",
        url=""+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://i1064.photobucket.com/albums/u363/tomer198585/image_gallery_zpst5ifm6vy.jpg",
        folder=True )
     
                                                
run()
