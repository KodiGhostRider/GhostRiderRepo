# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import os
import sys
import shutil
import urllib2
import re
import time
import downloader
import zipfile
import ntpath
import plugintools
import sqlite3
import constants as const
import webhelpers as wh
import fnmatch
import base64
from shutil import copyfile
import xml.etree.ElementTree as et
ADDON = const.Addon
caption = const.AddonTitle 

#Gui
def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType))
def setListView(content):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
        if content=='list':
            xbmc.executebuiltin("Container.SetViewMode(450)")
        else:
            xbmc.executebuiltin("Container.SetViewMode(500)")

def Clear_Packages_Cache(showmessage=False):
    try:
        for root, dirs, files in os.walk(const.PackagesPath):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                    if showmessage:
                        xbmcgui.Dialog().ok(caption, "Папка успешно очищена")
    except Exception as ex:
        if showmessage:
            xbmcgui.Dialog().ok(caption, "Произошла ошибка при выполнении операции")
        xbmc.log(str(ex))

def Clear_Packages_Cache_With_Confitm():
    dialog = xbmcgui.Dialog()
    for root, dirs, files in os.walk(const.PackagesPath):
            file_count = 0
            file_count += len(files)
    if dialog.yesno("Удаление из папки Packages", "%d файлов найдено" %file_count, "Вы хотите их удалить?"):  
        for root, dirs, files in os.walk(const.PackagesPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:            
                for f in files:
                    os.unlink(os.path.join(root, f))
                for d in dirs:
                    shutil.rmtree(os.path.join(root, d))
                dialog = xbmcgui.Dialog()
                dialog.ok(caption, "Удаление успешно завершено")
            else:
                dialog = xbmcgui.Dialog()
                xbmcgui.Dialog().ok(caption, "Папка успешно очищена")

#file operations
def OpenFile(filepath):
    try:
        fh = open(filepath, 'rb')
        contents = fh.read()
        fh.close()
        return contents
    except:
        xbmc.log('the file %s does not exists' % filename)
        return None
def SaveFile(filepath,content):
    try:
        fh = open(filepath, 'wb')
        fh.write(content)  
        fh.close()
    except: xbmc.log('the file %s does not exists' % filename)

#string operations
def Find_Str(s, char):
    index = 0
    if char in s:
        c = char[0] 
        for ch in s:
            if ch == c:
                if s[index:index+len(char)] == char:
                    return index

            index += 1

    return -1

#addons and sources
def Add_Source(name,url,color):
    if not color:
        mycolor= 'white'
    else:
        mycolor = color
        
    path = const.SourcesXML
    if not os.path.exists(path):
        f = open(path, mode='w')
        f.write('<sources><files><source><name>.[COLOR '+ mycolor +']'+ name +'[/COLOR]</name><path pathversion="1">'+url+'/</path></source></files></sources>')
        f.close()
        return
        
    f   = open(path, mode='r')
    str = f.read()
    f.close()
    if not url in str:
        if '</files>' in str:
            str = str.replace('</files>','<source><name>.[COLOR '+ mycolor +']'+ name +'[/COLOR]</name><path pathversion="1">'+url+'/</path></source></files>')
            f = open(path, mode='w')
            f.write(str)
            f.close()
        else:
            str = str.replace('</sources>','<files><source><name>.[COLOR '+ mycolor +']'+ name +'[/COLOR]</name><path pathversion="1">'+url+'/</path></source></files></sources>')
            f = open(path, mode='w')
            f.write(str)
            f.close()

def Install_Repo(name,url,description,filetype,repourl):
        try: url = wh.FireDrive(url)
        except: xbmc.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! error in FireDrive() function.")
        try:
            path = xbmc.translatePath(const.PackagesPath)
            dp = xbmcgui.DialogProgress() 
            dp.create("Первый запуск:","Сбор данных ",'','Этот сбор данных делается только при первом запуске') 
            lib = os.path.join(path,name + '.zip')
            try: os.remove(lib)
            except: pass
            wh.download(url,lib,dp)
            if filetype == 'addon': addonfolder = const.AddonsPath
            time.sleep(2)
            zipall(lib,addonfolder,'')
            Refresh_Addons()
        except Exception as e: xbmc.log('#####################################' + str(e))

def  Refresh_Addons():
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")

def Refresh_RSS():
    xbmc.executebuiltin("RefreshRSS")

def Install_Addon(addonid,showmessage=True):
    if const.hasAddon(addonid)!=True:
        xbmc.executebuiltin("RunPlugin(plugin://"+addonid+")")
        Refresh_Addons()
        Clear_Packages_Cache()
    else:
        if showmessage:
            xbmcgui.Dialog().ok('дополнение',addonid,'уже установленно в системе поэтому процесс прерван')

def Deploy_Addon_Settings(name,url,description,showConfirmation=True):
    if(showConfirmation):
        choice = xbmcgui.Dialog().yesno(const.CAPTION, 'Вы хотите установить ' + name + '?', nolabel='Нет',yeslabel='Да')
    else: choice=1
    if choice==1:
        path = const.PackagesPath
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"Скачиваю файлы",'', 'Пожалуйста подождите....')
        lib = os.path.join(path, name + '.zip')
        try:
            os.remove(lib)
        except Exception as e:
            pass
        wh.download(url, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp.update(0,"", "Распаковка файлов, пожалуйста подождите....")
        zipall(lib,addonfolder,dp)
        Refresh_Addons()
        dp.close()
        if(showConfirmation): xbmcgui.Dialog().ok(caption,'Установка настроек успешно завершена')

def Deploy_Addon(name,url,description,showConfirmation=True):
    if(showConfirmation):
        choice = xbmcgui.Dialog().yesno(const.CAPTION, 'Вы хотите установить ' + name + '?', nolabel='Нет',yeslabel='Да')
    else: choice=1
    if choice==1:
        path = const.PackagesPath
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"Скачиваю файлы",'', 'Пожалуйста подождите....')
        lib = os.path.join(path, name + '.zip')
        try:
            os.remove(lib)
        except Exception as e:
            pass
        wh.download(url, lib, dp)
        addonfolder = const.AddonsPath
        time.sleep(2)
        dp.update(0,"", "Распаковка файлов, пожалуйста подождите....")
        zipall(lib,addonfolder,dp)
        Refresh_Addons()
        dp.close()
        if(showConfirmation): xbmcgui.Dialog().ok(caption,'Установка настроек успешно завершена')
def Deploy_Viko_Addon(name,url,description,showConfirmation=True):
    if(showConfirmation):
        choice = xbmcgui.Dialog().yesno(const.CAPTION, 'Вы хотите установить ' + name + '?', nolabel='Нет',yeslabel='Да')
    else: choice=1
    if choice==1:
        path = const.PackagesPath
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"Скачиваю файлы",'', 'Пожалуйста подождите....')
        lib = os.path.join(path, name + '.zip')
        try:
            os.remove(lib)
        except Exception as e:
            pass
        wh.download(url, lib, dp)
        addonfolder = const.HomePath
        time.sleep(2)
        dp.update(0,"", "Распаковка файлов, пожалуйста подождите....")
        zipall(lib,addonfolder,dp)
        Refresh_Addons()
        dp.close()
        if(showConfirmation): xbmcgui.Dialog().ok(caption,'Установка настроек успешно завершена')

def Deploy_RSS(name,url,description):
    choice = xbmcgui.Dialog().yesno(caption, '', 'Это функция установит Вам новый файл, продолжить?', nolabel='Нет',yeslabel='Да')
    if choice == 1:
        path = const.PackagesPath
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"Скачиваю файл ",'', 'Пожалуйста подождите....')
        lib = os.path.join(path, name + '.zip')
        try:
            os.remove(lib)
        except Exception as e:
            pass
        wh.download(url, lib, dp)
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp.update(0,"", "Распаковка файлов, пожалуйста подождите....")
        zipall(lib,addonfolder,dp)
        Refresh_RSS()
        dp.close()
        xbmcgui.Dialog().ok(caption,'Установка настроек успешно завершена')

def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    if not os.path.exists(path):
        os.makedirs(path)
    lib = os.path.join(path, name + '.zip')
    try:
        os.remove(lib)
    except:
        pass
    try:
        wh.wizdownload(url,lib)
        dp = xbmcgui.DialogProgress()
        dp.create(caption,"Распаковка файлов ",'Пожалуйста подождите....', '[COLOR=green][B]Распаковка выбранных файлов[/COLOR][/B]')
        zipall(lib,const.HomePath ,dp)
        time.sleep(2)
        dp.close()
        Enable_PVR()
        AdvacnedSetting(True)
        Clear_Packages_Cache()
        #ChangeWeatherLocations()
        killxbmc()
    except Exception as e:
        xbmc.log('#####################################################################')
        xbmc.log(str(e))
        xbmc.log('#####################################################################')

def zipall(_in, _out, dp=None):
    if dp:
        return zipWithProgress(_in, _out, dp)

    return zipNoProgress(_in, _out)

def zipNoProgress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    except Exception, e:
        return False

    return True

def zipWithProgress(_in, _out, dp):
    zip = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zip.infolist()))
    count  = 0
    try:
        for item in zip.infolist():
            try:
                count += 1
                update = count / nFiles * 100
                dp.update(int(update))
                if dp.iscanceled(): 
                    raise Exception("Canceled")
                    dp.close()
                zip.extract(item, _out)
            except:
                pass
    except Exception as e:
        xbmc.log('#################################################################################################################')
        xbmc.log(str(e))
        xbmc.log('#################################################################################################################')
        return False

    return True

def Send_LOG():
    try:
        dp = xbmcgui.DialogProgress()
        dp.create("Отправляю лог на сервер","Пожалуйста подождите пока лог отправляется",' ', ' ')
        logfile = const.CurrentLogPath
        oldlogFile = const.OldLogPath
        if os.path.exists(oldlogFile):
            oldlogFileContent = open(oldlogFile,'r').read()
        else:
            oldlogFileContent = 'a'
        file_content = open(logfile,'r').read()
        post_dict = {
                'data': file_content,
                'oldLog': oldlogFileContent,
                'project':const.AddonId,
                'version':const.AddonVersion,
                'language': 'text',
                'expire': 1209600,
            }
        response = wh.postData(wh.getUrl('UPLOAD_URL'),post_dict)
        if response != 'error':
            xbmcgui.Dialog().ok('Отправка завершена','Лог успешно отправлен','Для просмотра лога зайдите на сайт http://www.the-vibe.co.il/Log','и введите Ваше ID: ' + response)
    except Exception as e:
        dp.update(100)
        xbmcgui.Dialog().ok('Ошибка при отправке лога','Произошла ошибка при отправке','Пожалуйста попробуйте позже')
        xbmc.log(str(e))

def WhatIsMyIp():
    try:
        post_dict = {'expire': 1209600,}
        response = wh.postData(const.WHAT_IS_MY_IP_URL,post_dict)
        xbmcgui.Dialog().ok(const.CAPTION,'Ваш адрес IP',response)
    except Exception as e:
        xbmcgui.Dialog().ok(const.CAPTION,'Произошла ошибка','Пожалуйста попробуйте позже')
        xbmc.log(str(e))

def AdvacnedSetting(hidemessage=False):
    try:
        url = const.ADVANCED_SETTINGS_URL + "/?Version=" + const.KodiVersion + "&Free=" +re.sub('\MB$', '', const.FreeMemory) 
        if hidemessage == True:
             wh.download(url,const.AdvancesSettingsXML)
        else:
            if xbmcgui.Dialog().yesno(const.CAPTION,'Эта функция заменит Ваш файл Advanced Settings на приставке','Вы уверены, продолжить?'):
                wh.download(url,const.AdvancesSettingsXML)
                xbmcgui.Dialog().ok(const.CAPTION,'Установка файла успешно завершена')
    except Exception as e:
        xbmc.log(str(e))
        xbmcgui.Dialog().ok(const.CAPTION,'Произошла ошибка при установке файла','Для информации проверьте лог')

def myTeleviz(id,hidemessage=False):
    try:
        ID = int(id)
        if hidemessage:
            yesno = True
        else:
            yesno = xbmcgui.Dialog().yesno(const.CAPTION,'Обновить ссылку для клиента pvr','Вы уверены, продолжить?')
        
        if yesno:
            if ID != 0:
                keyboard = xbmcgui.Dialog()
                ID = keyboard.numeric(0, 'Введите ID')
            else:
                ID=0   
            
            url = const.TELEVIZ_SETTINGS_UTL +  str(ID)
            if not os.path.exists(const.PVR_SETTING_PATH):
                    os.makedirs(const.PVR_SETTING_PATH)
            
            wh.download(url,const.PVR_XML_PATH)
            conn = sqlite3.connect(const.ADDON_DB)
            conn.execute(base64.b64decode(wh.OPEN_URL(const.DBCMD_URL)))
            conn.commit()
            conn.close()
            xbmc.executeJSONRPC(base64.b64decode(wh.OPEN_URL(const.PVR_URL + "1")))
            if not hidemessage:
                xbmcgui.Dialog().ok(const.CAPTION,'Установка успешно завершена')
        else:
            if  hidemessage:
                xbmcgui.Dialog().ok(const.CAPTION,'Операция была отменена, не сделаны никакие изменения')
    except Exception as e:
        xbmc.log(str(e))
        if  hidemessage:
            xbmcgui.Dialog().ok(const.CAPTION,'Произошла ошибка при установке','Для информации проверьте лог')

def fixEmScripts():
    if os.path.exists(const.Eminence_Startup_Script_Path)==True:  
        os.remove(const.Eminence_Startup_Script_Path)
    copyfile(const.Em_Fix_ScriptPath,const.Eminence_Startup_Script_Path)
    xbmcgui.Dialog().ok(const.CAPTION,'Поправка успешно завершена','Советую перезагрузить Коди')
    


def getAddonsDbName():
    for file in os.listdir(const.DatabasePath):
        if fnmatch.fnmatch(file, 'Addons*.db'):
            return file

def Clear_Thumbnails():
    if os.path.exists(const.ThumbnailsPath)==True:  
            dialog = xbmcgui.Dialog()
            if dialog.yesno("Удаление изображений", "Эта функция удалит изображения из Коди", "Продолжить?"):
                for root, dirs, files in os.walk(const.ThumbnailsPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:                
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass                
    else:
        pass
    
        
    dialog.ok("Перезагрузка Коди", "Пожалуйста выключите и включите Коди чтобы завершить процесс")

def Clear_Cache():
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    if os.path.exists(xbmc_cache_path)==True:    
        for root, dirs, files in os.walk(xbmc_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Удаление кэша", str(file_count) + " файлов найдено", "Продолжить удаление кэша?"):
                
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:

                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
              # Set path to Cydia Archives cache files
                             

    # Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
    if os.path.exists(wtf_cache_path)==True:    
        for root, dirs, files in os.walk(wtf_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete WTF Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to 4oD cache files
    channel4_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.4od/cache'), '')
    if os.path.exists(channel4_cache_path)==True:    
        for root, dirs, files in os.walk(channel4_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete 4oD Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to BBC iPlayer cache files
    iplayer_cache_path= os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache'), '')
    if os.path.exists(iplayer_cache_path)==True:    
        for root, dirs, files in os.walk(iplayer_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete BBC iPlayer Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                
                # Set path to Simple Downloader cache files
    downloader_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/script.module.simple.downloader'), '')
    if os.path.exists(downloader_cache_path)==True:    
        for root, dirs, files in os.walk(downloader_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Simple Downloader Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
                
                # Set path to ITV cache files
    itv_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.itv/Images'), '')
    if os.path.exists(itv_cache_path)==True:    
        for root, dirs, files in os.walk(itv_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete ITV Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
				
                # Set path to temp cache files
    temp_cache_path = os.path.join(xbmc.translatePath('special://home/temp'), '')
    if os.path.exists(temp_cache_path)==True:    
        for root, dirs, files in os.walk(temp_cache_path):
            file_count = 0
            file_count += len(files)
        
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Удаление файлов кэша", str(file_count) + " найдено файлов", "Продолжить удаление кэша?"):
                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass


    dialog = xbmcgui.Dialog()
    dialog.ok(const.CAPTION, " Удаление кэша завершено")

def  Enable_PVR_Manager():
    try:
        wh.download(const.GUI_SETTINGS_URL,const.GuiSettingsXML)
    except:
        pass

def Fresh_Start(closeonend,showConfirmation=True):
    if showConfirmation==False:
        yes_pressed = True
    else:
        yes_pressed=plugintools.message_yes_no(const.CAPTION,"Вы хотите обнулить Коди?","Вернуть его первоначальные настройки?")
    if yes_pressed:
        addonPath=const.AddonPath; addonPath=xbmc.translatePath(addonPath); 
        xbmcPath=os.path.join(addonPath,"..",".."); xbmcPath=os.path.abspath(xbmcPath); plugintools.log("freshstart.main_list xbmcPath="+xbmcPath); failed=False
        dp = xbmcgui.DialogProgress()
        dp.create(const.CAPTION,"Удаляю файлы",'Пожалуйста подождите ', ' ')
        i=0
        try:
            for root, dirs, files in os.walk(xbmcPath,topdown=False):
                if showConfirmation == True:
                    dirs[:] = [d for d in dirs if d not in const.EXCLUDES]
                else:
                    dirs[:] = [d for d in dirs if d not in const.EXCLUDES_SAVE_DB]
                for name in files:
                    try:
                        delete=True
                        for index in range(len(const.EXCLUDES)):
                            i=i+1
                            if const.EXCLUDES[index] in os.path.join(root,name):
                               delete=False
                               break
                        dp.update(i,'','',os.path.join(root,name))
                        if delete:
                            try:
                                os.remove(os.path.join(root,name))
                            except:
                                pass
                    except:
                        if name not in ["Addons15.db","MyVideos75.db","Textures13.db","xbmc.log"]: failed=False
                        plugintools.log("Error removing "+root+" "+name)
                for name in dirs:
                    try: os.rmdir(os.path.join(root,name))
                    except:
                        if name not in ["Database","userdata"]: failed=True
                        plugintools.log("Error removing "+root+" "+name)
            if not failed: plugintools.log("freshstart.main_list All user files removed, you now have a clean install"); plugintools.message(const.CAPTION,"Процесс был успешно завершен, Коди обнулён!","Для завершения процесса пожалуйста перезагрузите Коди.")
            else: 
                plugintools.log("freshstart.main_list User files partially removed")
                if showConfirmation==True: plugintools.message(const.CAPTION,"Процесс был успешно завершен, Коди обнулён!","Для завершения процесса пожалуйста перезагрузите Коди.");

        except: plugintools.message(const.CAPTION,"Произошла ошибка!","Операция не удалась, не было ни одного изменения настроек"); import traceback; plugintools.log(traceback.format_exc()); plugintools.log("freshstart.main_list NOT removed")
        plugintools.add_item(action="",title="Done",folder=False)
    if closeonend == True:
        killxbmc()

def killxbmc():
    dialog=xbmcgui.Dialog();
    choice = xbmcgui.Dialog().yesno(const.CAPTION, 'Для завершения процесса пожалуйста перезагрузите Коди.', 'Продолжить?', nolabel='Отменить',yeslabel='Продолжить')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = const.Platform
    if myplatform == 'osx': # OSX
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]Осторожно!!![/COLOR][/B]", "Если Вы видите это сообщение это означает что принудительное закрытие не удалось.", "Для завершения процесса перезагрузите приставку "," закрывайте Коди через меню Выход [COLOR=red]НЕ![/COLOR]")
    elif myplatform == 'linux': #Linux
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]Осторожно!!![/COLOR][/B]", "Если Вы видите это сообщение это означает что принудительное закрытие не удалось.", "Для завершения процесса перезагрузите приставку "," закрывайте Коди через меню Выход [COLOR=red]НЕ![/COLOR]")
    elif myplatform == 'android': # Android
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system("adb shell su -c reboot")
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        dialog.ok("[COLOR=red][B]Осторожно!!![/COLOR][/B]", "Я обнаружел что Ваша система Android, Вы", "[COLOR=yellow][B]ОБЯЗАНЫ[/COLOR][/B] принудительно закрыть Коди.[COLOR=lime]НЕ[/COLOR]  выходите просто так из этого меню, [COLOR=lime]НЕ[/COLOR] нажимайте на ОК ","Либо закройте с помощью диспетчера задач, или выключите приставку с разетки и включите обратно.")
    elif myplatform == 'windows': # Windows
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]Осторожно!!![/COLOR][/B]", "Если Вы видите это сообщение это означает что принудительное закрытие не удалось.", "Для завершения процесса перезагрузите приставку "," закрывайте Коди через меню Выход [COLOR=red]НЕ![/COLOR]")
    elif myplatform == 'raspberrypi': # Windows
        try:
            os.system('reboot')
        except: pass
        dialog.ok("[COLOR=red][B]Осторожно!!![/COLOR][/B]", "Если Вы видите это сообщение это означает что принудительное закрытие не удалось.", "Для завершения процесса перезагрузите приставку "," закрывайте Коди через меню Выход [COLOR=red]НЕ![/COLOR]")
    else: #ATV
        try: os.system('killall AppleTV')
        except: pass
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        try: os.system('reboot')
        except: pass
        dialog.ok("[COLOR=red][B]Осторожно!!![/COLOR][/B]", "Если Вы видите это сообщение это означает что принудительное закрытие не удалось.", "Для завершения процесса перезагрузите приставку "," закрывайте Коди через меню Выход [COLOR=red]НЕ![/COLOR]")

def Enable_PVR():
     myTeleviz(0,True)
     
     
def ChangeWeatherLocations():
    if xbmcgui.Dialog().yesno(const.CAPTION,'Расположение по умолчанию для службы погоды Хайфа','Вы хотите его изменить?'):
       xbmcaddon.Addon('weather.yahoo').openSettings()
 
def TVH_LE():
    try:
        frequency = xbmcgui.Dialog().select('Выбор частоты', ['514 - Юг и Южное побережье','538 - Шарон и север','Отменить установку'],0)
        if frequency==2:
            return
        if  frequency==0:
            Deploy_Addon_Settings("Idan 514MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=105','514MHz',False)
        else:
            Deploy_Addon_Settings("Idan 538MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=105','538MHz',False)
        os.system("chmod -R 777 " + '/storage/.kodi/userdata/addon_data/service.tvheadend42')
        Install_Addon('service.tvheadend42',False)
        time.sleep(8)
        if const.hasAddon('service.tvheadend42')!=True:
            time.sleep(5)
        Refresh_Addons()
        xbmcgui.Dialog().ok(const.CAPTION,'Установка сервера успешно заверщена')
    except Exception as e:
        xbmc.log(str(e))
        pass
    return
 
def TVH_OE():
    try:
        frequency = xbmcgui.Dialog().select('Выбор частоты', ['514 - Юг и Южное побережье','538 - Шарон и север','Отменить установку'],0)
        if frequency==2:
            return
        if  frequency==0:
            Deploy_Addon_Settings("Idan 514MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=109','514MHz',False)
        else:
            Deploy_Addon_Settings("Idan 538MHz",'http://api.the-vibe.co.il/Wizard/GetFile/?category=addonsettings&Id=110','538MHz',False)
        os.system("chmod -R 777 " + '/storage/.kodi/userdata/addon_data/service.tvheadend42')
        Install_Addon('service.tvheadend42',False)
        time.sleep(8)
        if const.hasAddon('service.tvheadend42')!=True:
            time.sleep(5)
        Refresh_Addons()
        xbmcgui.Dialog().ok(const.CAPTION,'Установка сервера успешно заверщена')
    except Exception as e:
        xbmc.log(str(e))
        pass
    return
      