#! /usr/bin/python
# coding: UTF-8
import sys
l1ll1l1lFuck_You_Anonymous = sys.version_info [0] == 2
l11ll11Fuck_You_Anonymous = 2048
l1llll1lFuck_You_Anonymous = 7
def l111Fuck_You_Anonymous (l1l11lFuck_You_Anonymous):
    global l11lll1Fuck_You_Anonymous
    l1111llFuck_You_Anonymous = ord (l1l11lFuck_You_Anonymous [-1])
    l1ll1ll1Fuck_You_Anonymous = l1l11lFuck_You_Anonymous [:-1]
    l1l1lllFuck_You_Anonymous = l1111llFuck_You_Anonymous % len (l1ll1ll1Fuck_You_Anonymous)
    l11l1lFuck_You_Anonymous = l1ll1ll1Fuck_You_Anonymous [:l1l1lllFuck_You_Anonymous] + l1ll1ll1Fuck_You_Anonymous [l1l1lllFuck_You_Anonymous:]
    if l1ll1l1lFuck_You_Anonymous:
        l11l1Fuck_You_Anonymous = unicode () .join ([unichr (ord (char) - l11ll11Fuck_You_Anonymous - (l1l1Fuck_You_Anonymous + l1111llFuck_You_Anonymous) % l1llll1lFuck_You_Anonymous) for l1l1Fuck_You_Anonymous, char in enumerate (l11l1lFuck_You_Anonymous)])
    else:
        l11l1Fuck_You_Anonymous = str () .join ([chr (ord (char) - l11ll11Fuck_You_Anonymous - (l1l1Fuck_You_Anonymous + l1111llFuck_You_Anonymous) % l1llll1lFuck_You_Anonymous) for l1l1Fuck_You_Anonymous, char in enumerate (l11l1lFuck_You_Anonymous)])
    return eval (l11l1Fuck_You_Anonymous)
license = (
'''Copyright 2014, 2015, 2016, 2017 Jacques de Hooge, GEATEC engineering, www.geatec.com
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.'''
)
import re
import os
import sys
import errno
import keyword
import importlib
import random
import codecs
import shutil
l1lllllllFuck_You_Anonymous = l111Fuck_You_Anonymous (u"ࠩࡲࡴࡾ࠭ছ")
l1l111llFuck_You_Anonymous = l111Fuck_You_Anonymous (u"ࠪ࠵࠳࠷࠮࠳࠶ࠪজ")
if __name__ == l111Fuck_You_Anonymous (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭ঝ"):
    print (l111Fuck_You_Anonymous (u"ࠬࢁࡽࠡࠪࡗࡑ࠮ࠦࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡤ࡯ࡩࠥࡓࡵ࡭ࡶ࡬ࠤࡒࡵࡤࡶ࡮ࡨࠤࡕࡿࡴࡩࡱࡱࠤࡔࡨࡦࡶࡵࡦࡥࡹࡵࡲࠡࡘࡨࡶࡸ࡯࡯࡯ࠢࡾࢁࠬঞ").format (l1lllllllFuck_You_Anonymous.capitalize (), l1l111llFuck_You_Anonymous))
    print (l111Fuck_You_Anonymous (u"࠭ࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࠫࡇ࠮ࠦࡇࡦࡣࡷࡩࡨࠦࡅ࡯ࡩ࡬ࡲࡪ࡫ࡲࡪࡰࡪ࠲ࠥࡒࡩࡤࡧࡱࡷࡪࡀࠠࡂࡲࡤࡧ࡭࡫ࠠ࠳࠰࠳ࠤࡦࡺࠠࠡࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡰࡢࡥ࡫ࡩ࠳ࡵࡲࡨ࠱࡯࡭ࡨ࡫࡮ࡴࡧࡶ࠳ࡑࡏࡃࡆࡐࡖࡉ࠲࠸࠮࠱࡞ࡱࠫট"))
    random.seed ()
    l1lll1111Fuck_You_Anonymous = sys.version_info [0] == 2
    l1lll1l11Fuck_You_Anonymous = 2048
    l1111llFuck_You_Anonymous = l1lll1l11Fuck_You_Anonymous
    l11l1ll1Fuck_You_Anonymous = 7
    def l11ll11lFuck_You_Anonymous (l1111lllFuck_You_Anonymous, open = False):
        try:
            os.makedirs (l1111lllFuck_You_Anonymous.rsplit (l111Fuck_You_Anonymous (u"ࠧ࠰ࠩঠ"), 1) [0])
        except OSError as exception:
            if exception.errno != errno.EEXIST:
                raise
        if open:
            return codecs.open (l1111lllFuck_You_Anonymous, encoding = l111Fuck_You_Anonymous (u"ࠨࡷࡷࡪ࠲࠾ࠧড"), mode = l111Fuck_You_Anonymous (u"ࠩࡺࠫঢ"))
    def l1111ll1Fuck_You_Anonymous (l1111l1lFuck_You_Anonymous, name):
        return l111Fuck_You_Anonymous (u"ࠪࡿ࠵ࢃࡻ࠲ࡿࡾ࠶ࢂ࠭ণ").format (
            l111Fuck_You_Anonymous (u"ࠫࡤࡥࠧত") if name.startswith (l111Fuck_You_Anonymous (u"ࠬࡥ࡟ࠨথ")) else l111Fuck_You_Anonymous (u"࠭࡟ࠨদ") if name.startswith (l111Fuck_You_Anonymous (u"ࠧࡠࠩধ")) else l111Fuck_You_Anonymous (u"ࠨ࡮ࠪন"),
            bin (l1111l1lFuck_You_Anonymous) [2:] .replace (l111Fuck_You_Anonymous (u"ࠩ࠳ࠫ঩"), l111Fuck_You_Anonymous (u"ࠪࡰࠬপ")),
            l1l11l1lFuck_You_Anonymous
        )
    def l1ll1llllFuck_You_Anonymous (l11l1Fuck_You_Anonymous):
        global l1111llFuck_You_Anonymous
        if l1lll1111Fuck_You_Anonymous:
            l11l1lFuck_You_Anonymous = unicode () .join ([unichr (l1lll1l11Fuck_You_Anonymous + ord (char) + (l1l1Fuck_You_Anonymous + l1111llFuck_You_Anonymous) % l11l1ll1Fuck_You_Anonymous) for l1l1Fuck_You_Anonymous, char in enumerate (l11l1Fuck_You_Anonymous)])
            l111l1llFuck_You_Anonymous = unichr (l1111llFuck_You_Anonymous)
        else:
            l11l1lFuck_You_Anonymous = str () .join ([chr (l1lll1l11Fuck_You_Anonymous + ord (char) + (l1l1Fuck_You_Anonymous + l1111llFuck_You_Anonymous) % l11l1ll1Fuck_You_Anonymous) for l1l1Fuck_You_Anonymous, char in enumerate (l11l1Fuck_You_Anonymous)])
            l111l1llFuck_You_Anonymous = chr (l1111llFuck_You_Anonymous)
        l1l1lllFuck_You_Anonymous = l1111llFuck_You_Anonymous % len (l11l1Fuck_You_Anonymous)
        l1ll1ll1Fuck_You_Anonymous = l11l1lFuck_You_Anonymous [:-l1l1lllFuck_You_Anonymous] + l11l1lFuck_You_Anonymous [-l1l1lllFuck_You_Anonymous:]
        l1l11lFuck_You_Anonymous = l1ll1ll1Fuck_You_Anonymous + l111l1llFuck_You_Anonymous
        l1111llFuck_You_Anonymous += 1
        return l111Fuck_You_Anonymous (u"ࠫࡺࠨࠧফ") + l1l11lFuck_You_Anonymous + l111Fuck_You_Anonymous (u"ࠬࠨࠧব")
    def l1l11lllFuck_You_Anonymous (l111l111Fuck_You_Anonymous):
        return l111Fuck_You_Anonymous (u"࠭ࠧࠨࠏࠍ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡾࡹࠍࠋࠏࠍ࡭ࡸࡖࡹࡵࡪࡲࡲ࠷ࢁ࠰ࡾࠢࡀࠤࡸࡿࡳ࠯ࡸࡨࡶࡸ࡯࡯࡯ࡡ࡬ࡲ࡫ࡵࠠ࡜࠲ࡠࠤࡂࡃࠠ࠳ࠏࠍࡧ࡭ࡧࡲࡃࡣࡶࡩࢀ࠶ࡽࠡ࠿ࠣࡿ࠶ࢃࠍࠋࡥ࡫ࡥࡷࡓ࡯ࡥࡷ࡯ࡹࡸࢁ࠰ࡾࠢࡀࠤࢀ࠸ࡽࠎࠌࠐࠎࡩ࡫ࡦࠡࡷࡱࡗࡨࡸࡡ࡮ࡤ࡯ࡩࢀ࠶ࡽࠡࠪ࡮ࡩࡾ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩ࠻ࠏࠍࠤࠥࠦࠠࡨ࡮ࡲࡦࡦࡲࠠࡴࡶࡵ࡭ࡳ࡭ࡎࡳࡽ࠳ࢁࠒࠐࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࡶࡸࡷ࡯࡮ࡨࡐࡵࠤࡂࠦ࡯ࡳࡦࠣࠬࡰ࡫ࡹࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢ࡞࠱࠶ࡣࠩࠎࠌࠣࠤࠥࠦࡲࡰࡶࡤࡸࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱࠦ࠽ࠡ࡭ࡨࡽࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡒࡩࡵࡧࡵࡥࡱ࡛ࠦ࠻࠯࠴ࡡࠒࠐࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࡵࡳࡹࡧࡴࡪࡱࡱࡈ࡮ࡹࡴࡢࡰࡦࡩࠥࡃࠠࡴࡶࡵ࡭ࡳ࡭ࡎࡳࠢࠨࠤࡱ࡫࡮ࠡࠪࡵࡳࡹࡧࡴࡦࡦࡖࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠫࠐࠎࠥࠦࠠࠡࡴࡨࡧࡴࡪࡥࡥࡕࡷࡶ࡮ࡴࡧࡍ࡫ࡷࡩࡷࡧ࡬ࠡ࠿ࠣࡶࡴࡺࡡࡵࡧࡧࡗࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠣ࡟࠿ࡸ࡯ࡵࡣࡷ࡭ࡴࡴࡄࡪࡵࡷࡥࡳࡩࡥ࡞ࠢ࠮ࠤࡷࡵࡴࡢࡶࡨࡨࡘࡺࡲࡪࡰࡪࡐ࡮ࡺࡥࡳࡣ࡯ࠤࡠࡸ࡯ࡵࡣࡷ࡭ࡴࡴࡄࡪࡵࡷࡥࡳࡩࡥ࠻࡟ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤ࡮࡬ࠠࡪࡵࡓࡽࡹ࡮࡯࡯࠴ࡾ࠴ࢂࡀࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡶࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢࡀࠤࡺࡴࡩࡤࡱࡧࡩࠥ࠮ࠩࠡ࠰࡭ࡳ࡮ࡴࠠࠩ࡝ࡸࡲ࡮ࡩࡨࡳࠢࠫࡳࡷࡪࠠࠩࡥ࡫ࡥࡷ࠯ࠠ࠮ࠢࡦ࡬ࡦࡸࡂࡢࡵࡨࡿ࠵ࢃࠠ࠮ࠢࠫࡧ࡭ࡧࡲࡊࡰࡧࡩࡽࠦࠫࠡࡵࡷࡶ࡮ࡴࡧࡏࡴࠬࠤࠪࠦࡣࡩࡣࡵࡑࡴࡪࡵ࡭ࡷࡶࡿ࠵ࢃࠩࠡࡨࡲࡶࠥࡩࡨࡢࡴࡌࡲࡩ࡫ࡸ࠭ࠢࡦ࡬ࡦࡸࠠࡪࡰࠣࡩࡳࡻ࡭ࡦࡴࡤࡸࡪࠦࠨࡳࡧࡦࡳࡩ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩ࡞ࠫࠐࠎࠥࠦࠠࠡࡧ࡯ࡷࡪࡀࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡶࡸࡷ࡯࡮ࡨࡎ࡬ࡸࡪࡸࡡ࡭ࠢࡀࠤࡸࡺࡲࠡࠪࠬࠤ࠳ࡰ࡯ࡪࡰࠣࠬࡠࡩࡨࡳࠢࠫࡳࡷࡪࠠࠩࡥ࡫ࡥࡷ࠯ࠠ࠮ࠢࡦ࡬ࡦࡸࡂࡢࡵࡨࡿ࠵ࢃࠠ࠮ࠢࠫࡧ࡭ࡧࡲࡊࡰࡧࡩࡽࠦࠫࠡࡵࡷࡶ࡮ࡴࡧࡏࡴࠬࠤࠪࠦࡣࡩࡣࡵࡑࡴࡪࡵ࡭ࡷࡶࡿ࠵ࢃࠩࠡࡨࡲࡶࠥࡩࡨࡢࡴࡌࡲࡩ࡫ࡸ࠭ࠢࡦ࡬ࡦࡸࠠࡪࡰࠣࡩࡳࡻ࡭ࡦࡴࡤࡸࡪࠦࠨࡳࡧࡦࡳࡩ࡫ࡤࡔࡶࡵ࡭ࡳ࡭ࡌࡪࡶࡨࡶࡦࡲࠩ࡞ࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤࡪࡼࡡ࡭ࠢࠫࡷࡹࡸࡩ࡯ࡩࡏ࡭ࡹ࡫ࡲࡢ࡮ࠬࠑࠏࠦࠠࠡࠢࠪࠫࠬভ").format (l1lll11l1Fuck_You_Anonymous, l1lll1l11Fuck_You_Anonymous, l11l1ll1Fuck_You_Anonymous)
    def l1llll111Fuck_You_Anonymous (l1llll11lFuck_You_Anonymous):
        print (l111Fuck_You_Anonymous (u"ࡲࠨࠩࠪࠑࠏࠓࠊࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬࠐࠎࢀ࠶ࡽࠡࡹ࡬ࡰࡱࠦ࡯ࡣࡨࡸࡷࡨࡧࡴࡦࠢࡼࡳࡺࡸࠠࡦࡺࡷࡩࡳࡹࡩࡷࡧ࠯ࠤࡷ࡫ࡡ࡭ࠢࡺࡳࡷࡲࡤ࠭ࠢࡰࡹࡱࡺࡩࠡ࡯ࡲࡨࡺࡲࡥࠡࡒࡼࡸ࡭ࡵ࡮ࠡࡵࡲࡹࡷࡩࡥࠡࡥࡲࡨࡪࠦࡦࡰࡴࠣࡪࡷ࡫ࡥࠢࠏࠍࡅࡳࡪ࡚ࠠࡑࡘࠤࡨ࡮࡯ࡰࡵࡨࠤࡵ࡫ࡲࠡࡲࡵࡳ࡯࡫ࡣࡵࠢࡺ࡬ࡦࡺࠠࡵࡱࠣࡳࡧ࡬ࡵࡴࡥࡤࡸࡪࠦࡡ࡯ࡦࠣࡻ࡭ࡧࡴࠡࡰࡲࡸ࠱ࠦࡢࡺࠢࡨࡨ࡮ࡺࡴࡪࡰࡪࠤࡹ࡮ࡥࠡࡥࡲࡲ࡫࡯ࡧࠡࡨ࡬ࡰࡪ࠴ࠍࠋࠏࠍࡆࡆࡉࡋࡖࡒࠣ࡝ࡔ࡛ࡒࠡࡅࡒࡈࡊࠦࡁࡏࡆ࡚ࠣࡆࡒࡕࡂࡄࡏࡉࠥࡊࡁࡕࡃࠣࡘࡔࠦࡁࡏࠢࡒࡊࡋ࠳ࡌࡊࡐࡈࠤࡒࡋࡄࡊࡗࡐࠤࡋࡏࡒࡔࡖࠣࡘࡔࠦࡐࡓࡇ࡙ࡉࡓ࡚ࠠࡂࡅࡆࡍࡉࡋࡎࡕࡃࡏࠤࡑࡕࡓࡔࠢࡒࡊࠥ࡝ࡏࡓࡍࠤࠥࠦࠓࠊࠎࠌࡗ࡬ࡪࡴࠠࡤࡱࡳࡽࠥࡺࡨࡦࠢࡧࡩ࡫ࡧࡵ࡭ࡶࠣࡧࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡶࡲࠤࡹ࡮ࡥࠡࡵࡲࡹࡷࡩࡥࠡࡶࡲࡴࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹࠡ࠾ࡷࡳࡵࡪࡩࡳࡀࠣࡥࡳࡪࠠࡳࡷࡱࠤࢀ࠶ࡽࠡࡨࡵࡳࡲࠦࡴࡩࡧࡵࡩ࠳ࠓࠊࡊࡶࠣࡻ࡮ࡲ࡬ࠡࡩࡨࡲࡪࡸࡡࡵࡧࠣࡥࡳࠦ࡯ࡣࡨࡸࡷࡨࡧࡴࡪࡱࡱࠤࡩ࡯ࡲࡦࡥࡷࡳࡷࡿࠠ࠽ࡶࡲࡴࡩ࡯ࡲ࠿࠱࠱࠲࠴ࡂࡴࡰࡲࡧ࡭ࡷࡄ࡟ࡼ࠳ࢀࠑࠏࠓࠊࡂࡶࠣࡪ࡮ࡸࡳࡵࠢࡶࡳࡲ࡫ࠠࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࡷࠥࡳࡡࡺࠢࡥࡩࠥࡵࡢࡧࡷࡶࡧࡦࡺࡥࡥࠢࡷ࡬ࡦࡺࠠࡴࡪࡲࡹࡱࡪ࡮ࠨࡶࠣࡦࡪ࠲ࠠࡦ࠰ࡪ࠲ࠥࡹ࡯࡮ࡧࠣࡳ࡫ࠦࡴࡩࡱࡶࡩࠥ࡯࡭ࡱࡱࡵࡸࡪࡪࠠࡧࡴࡲࡱࠥ࡫ࡸࡵࡧࡵࡲࡦࡲࠠ࡮ࡱࡧࡹࡱ࡫ࡳ࠯ࠢࠣࠤࠒࠐࡁࡥࡣࡳࡸࠥࡿ࡯ࡶࡴࠣࡧࡴࡴࡦࡪࡩࠣࡪ࡮ࡲࡥࠡࡶࡲࠤࡦࡼ࡯ࡪࡦࠣࡸ࡭࡯ࡳ࠭ࠢࡨ࠲࡬࠴ࠠࡣࡻࠣࡥࡩࡪࡩ࡯ࡩࠣࡩࡽࡺࡥࡳࡰࡤࡰࠥࡳ࡯ࡥࡷ࡯ࡩࠥࡴࡡ࡮ࡧࡶࠤࡹ࡮ࡡࡵࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡶࡪࡩࡵࡳࡵ࡬ࡺࡪࡲࡹࠡࡵࡦࡥࡳࡴࡥࡥࠢࡩࡳࡷࠦࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࡶ࠲ࠒࠐ࡙ࡰࡷࠣࡱࡦࡿࠠࡢ࡮ࡶࡳࠥ࡫ࡸࡤ࡮ࡸࡨࡪࠦࡣࡦࡴࡷࡥ࡮ࡴࠠࡸࡱࡵࡨࡸࠦ࡯ࡳࠢࡩ࡭ࡱ࡫ࡳࠡ࡫ࡱࠤࡾࡵࡵࡳࠢࡳࡶࡴࡰࡥࡤࡶࠣࡪࡷࡵ࡭ࠡࡱࡥࡪࡺࡹࡣࡢࡶ࡬ࡳࡳࠦࡥࡹࡲ࡯࡭ࡨ࡯ࡴ࡭ࡻ࠱ࠑࠏ࡙࡯ࡶࡴࡦࡩࠥࡪࡩࡳࡧࡦࡸࡴࡸࡹ࠭ࠢࡲࡦ࡫ࡻࡳࡤࡣࡷ࡭ࡴࡴࠠࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡻࠣࡥࡳࡪࠠࡤࡱࡱࡪ࡮࡭ࠠࡧ࡫࡯ࡩࠥࡶࡡࡵࡪࠣࡧࡦࡴࠠࡢ࡮ࡶࡳࠥࡨࡥࠡࡵࡸࡴࡵࡲࡩࡦࡦࠣࡥࡸࠦࡣࡰ࡯ࡰࡥࡳࡪࠠ࡭࡫ࡱࡩࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠢ࡬ࡲࠥࡺࡨࡢࡶࠣࡳࡷࡪࡥࡳ࠰ࠐࠎࡈࡵ࡭࡮ࡧࡱࡸࡸࠦࡡ࡯ࡦࠣࡷࡹࡸࡩ࡯ࡩࠣࡰ࡮ࡺࡥࡳࡣ࡯ࡷࠥࡩࡡ࡯ࠢࡥࡩࠥࡳࡡࡳ࡭ࡨࡨࠥࡧࡳࠡࡲ࡯ࡥ࡮ࡴࠬࠡࡤࡼࡴࡦࡹࡳࡪࡰࡪࠤࡴࡨࡦࡶࡵࡦࡥࡹ࡯࡯࡯ࠏࠍࠑࠏࡑ࡮ࡰࡹࡱࠤࡱ࡯࡭ࡪࡶࡤࡸ࡮ࡵ࡮ࡴ࠼ࠐࠎࠒࠐࡁࠡࡥࡲࡱࡲ࡫࡮ࡵࠢࡤࡪࡹ࡫ࡲࠡࡣࠣࡷࡹࡸࡩ࡯ࡩࠣࡰ࡮ࡺࡥࡳࡣ࡯ࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡱࡴࡨࡧࡪࡪࡥࡥࠢࡥࡽࠥࡽࡨࡪࡶࡨࡷࡵࡧࡣࡦࠏࠍࡅࠥ࠭ࠠࡰࡴࠣࠦࠥ࡯࡮ࡴ࡫ࡧࡩࠥࡧࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭࡫ࡷࡩࡷࡧ࡬ࠡࡵ࡫ࡳࡺࡲࡤࠡࡤࡨࠤࡪࡹࡣࡢࡲࡨࡨࠥࡽࡩࡵࡪࠣࡠࠥࡸࡡࡵࡪࡨࡶࠥࡺࡨࡦࡰࠣࡨࡴࡻࡢ࡭ࡧࡧࠑࠏࡏࡦࠡࡶ࡫ࡩࠥࡶࡥࡱ࠺ࡢࡧࡴࡳ࡭ࡦࡰࡷࡷࠥࡵࡰࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡈࡤࡰࡸ࡫ࠠࠩࡶ࡫ࡩࠥࡪࡥࡧࡣࡸࡰࡹ࠯ࠬࠡࡣࠣࡿ࠷ࢃࠠࡪࡰࠣࡥࠥࡹࡴࡳ࡫ࡱ࡫ࠥࡲࡩࡵࡧࡵࡥࡱࠦࡣࡢࡰࠣࡳࡳࡲࡹࠡࡤࡨࠤࡺࡹࡥࡥࠢࡤࡸࠥࡺࡨࡦࠢࡶࡸࡦࡸࡴ࠭ࠢࡶࡳࠥࡻࡳࡦࠢࠪࡴࠬ࠭ࡻ࠳ࡿࠪࠫࡷ࠭ࠠࡳࡣࡷ࡬ࡪࡸࠠࡵࡪࡤࡲࠥ࠭ࡰࡼ࠴ࢀࡶࠬࠓࠊࡊࡨࠣࡸ࡭࡫ࠠࡱࡧࡳ࠼ࡤࡩ࡯࡮࡯ࡨࡲࡹࡹࠠࡰࡲࡷ࡭ࡴࡴࠠࡪࡵࠣࡷࡪࡺࠠࡵࡱࠣࡘࡷࡻࡥ࠭ࠢ࡫ࡳࡼ࡫ࡶࡦࡴ࠯ࠤࡴࡴ࡬ࡺࠢࡤࠤࡁࡨ࡬ࡢࡰ࡮ࡂࡁࡨ࡬ࡢࡰ࡮ࡂࢀ࠸ࡽ࠽ࡤ࡯ࡥࡳࡱ࠾ࠡࡥࡤࡲࡳࡵࡴࠡࡤࡨࠤࡺࡹࡥࡥࠢ࡬ࡲࠥࡺࡨࡦࠢࡰ࡭ࡩࡪ࡬ࡦࠢࡲࡶࠥࡧࡴࠡࡶ࡫ࡩࠥ࡫࡮ࡥࠢࡲࡪࠥࡧࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭࡫ࡷࡩࡷࡧ࡬ࠎࠌࡒࡦ࡫ࡻࡳࡤࡣࡷ࡭ࡴࡴࠠࡰࡨࠣࡷࡹࡸࡩ࡯ࡩࠣࡰ࡮ࡺࡥࡳࡣ࡯ࡷࠥ࡯ࡳࠡࡷࡱࡷࡺ࡯ࡴࡢࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡶࡩࡳࡹࡩࡵ࡫ࡹࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡷ࡮ࡴࡣࡦࠢ࡬ࡸࠥࡩࡡ࡯ࠢࡥࡩࠥࡺࡲࡪࡸ࡬ࡥࡱࡲࡹࠡࡤࡵࡳࡰ࡫࡮ࠎࠌࡑࡳࠥࡸࡥ࡯ࡣࡰ࡭ࡳ࡭ࠠࡣࡣࡦ࡯ࡩࡵ࡯ࡳࠢࡶࡹࡵࡶ࡯ࡳࡶࠣࡪࡴࡸࠠ࡮ࡧࡷ࡬ࡴࡪࡳࠡࡵࡷࡥࡷࡺࡩ࡯ࡩࠣࡻ࡮ࡺࡨࠡࡡࡢࠤ࠭ࡴ࡯࡯࠯ࡲࡺࡪࡸࡲࡪࡦࡤࡦࡱ࡫ࠠ࡮ࡧࡷ࡬ࡴࡪࡳ࠭ࠢࡤࡰࡸࡵࠠ࡬ࡰࡲࡻࡳࠦࡡࡴࠢࡳࡶ࡮ࡼࡡࡵࡧࠣࡱࡪࡺࡨࡰࡦࡶ࠭ࠒࠐࠍࠋࡎ࡬ࡧࡪࡴࡣࡦ࠼ࠐࠎࢀ࠹ࡽࠎࠌ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪম").format (l1lllllllFuck_You_Anonymous.capitalize (), l1lllllllFuck_You_Anonymous, l111Fuck_You_Anonymous (u"ࡳࠩࠦࠫয"), license))
        exit (l1llll11lFuck_You_Anonymous)
    if len (sys.argv) > 1:
        if l111Fuck_You_Anonymous (u"ࠩࡂࠫর") in sys.argv [1]:
            l1llll111Fuck_You_Anonymous (0)
        l11llll1Fuck_You_Anonymous = sys.argv [1]
    else:
        l11llll1Fuck_You_Anonymous = os.getcwd () .replace (l111Fuck_You_Anonymous (u"ࠪࡠࡡ࠭঱"), l111Fuck_You_Anonymous (u"ࠫ࠴࠭ল"))
    if len (sys.argv) > 2:
        l1lll1ll1Fuck_You_Anonymous = sys.argv [2]
    else:
        l1lll1ll1Fuck_You_Anonymous = l111Fuck_You_Anonymous (u"ࠬࢁ࠰ࡾ࠱ࡾ࠵ࢂࡥࡻ࠳ࡿࠪ঳").format (* (l11llll1Fuck_You_Anonymous.rsplit (l111Fuck_You_Anonymous (u"࠭࠯ࠨ঴"), 1) + [l1lllllllFuck_You_Anonymous]))
    if len (sys.argv) > 3:
        l11l1lllFuck_You_Anonymous = sys.argv [3]
    else:
        l11l1lllFuck_You_Anonymous = l111Fuck_You_Anonymous (u"ࠧࡼ࠲ࢀ࠳ࢀ࠷ࡽࡠࡥࡲࡲ࡫࡯ࡧ࠯ࡶࡻࡸࠬ঵").format (l11llll1Fuck_You_Anonymous, l1lllllllFuck_You_Anonymous)
    obfuscate_strings = False
    obfuscated_name_tail = l111Fuck_You_Anonymous (u"ࠨࡡࡾࢁࡤ࠭শ").format (l1lllllllFuck_You_Anonymous)
    plain_marker = l111Fuck_You_Anonymous (u"ࠩࡢࡿࢂࡥࠧষ").format (l1lllllllFuck_You_Anonymous)
    source_extensions = l111Fuck_You_Anonymous (u"ࠪࠫস")
    skip_extensions = l111Fuck_You_Anonymous (u"ࠫࠬহ")
    external_modules = l111Fuck_You_Anonymous (u"ࠬ࠭঺")
    plain_files = l111Fuck_You_Anonymous (u"࠭ࠧ঻")
    plain_names = l111Fuck_You_Anonymous (u"ࠧࠨ়")
    try:
        l11l11llFuck_You_Anonymous = open (l11l1lllFuck_You_Anonymous)
    except Exception as exception:
        print (exception)
        l1llll111Fuck_You_Anonymous (1)
    exec (l11l11llFuck_You_Anonymous.read ())
    l11l11llFuck_You_Anonymous.close ()
    try:
        l11lll1lFuck_You_Anonymous = obfuscate_strings
    except:
        l11lll1lFuck_You_Anonymous = False
    try:
        l11111llFuck_You_Anonymous = l1llll1llFuck_You_Anonymous
    except:
        l11111llFuck_You_Anonymous = False
    try:
        l1l11l1lFuck_You_Anonymous = obfuscated_name_tail
    except:
        l1l11l1lFuck_You_Anonymous = l111Fuck_You_Anonymous (u"ࠨࠩঽ")
    try:
        l1lll11l1Fuck_You_Anonymous = plain_marker
    except:
        l1lll11l1Fuck_You_Anonymous = l111Fuck_You_Anonymous (u"ࠩࡢࡿ࠵ࢃ࡟ࠨা").format (l1lllllllFuck_You_Anonymous)
    try:
        l1l11111Fuck_You_Anonymous = pep8_comments
    except:
        l1l11111Fuck_You_Anonymous = False
    l1111l11Fuck_You_Anonymous = source_extensions.split ()
    l1lllll11Fuck_You_Anonymous = skip_extensions.split ()
    l111llllFuck_You_Anonymous = external_modules.split ()
    l11l1l1lFuck_You_Anonymous = plain_files.split ()
    l11lllllFuck_You_Anonymous = plain_names.split ()
    l11l111lFuck_You_Anonymous = [
        l111Fuck_You_Anonymous (u"ࠪࡿ࠵ࢃ࠯ࡼ࠳ࢀࠫি").format (directory.replace (l111Fuck_You_Anonymous (u"ࠫࡡࡢࠧী"), l111Fuck_You_Anonymous (u"ࠬ࠵ࠧু")), fileName)
        for directory, l111lll1Fuck_You_Anonymous, l1lll11llFuck_You_Anonymous in os.walk (l11llll1Fuck_You_Anonymous)
        for fileName in l1lll11llFuck_You_Anonymous
    ]
    l1l1l111Fuck_You_Anonymous = re.compile (l111Fuck_You_Anonymous (u"ࡸࠧ࡟ࡽ࠳ࢁࠦ࠭ূ").format (l111Fuck_You_Anonymous (u"ࡲࠨࠥࠪৃ")))
    l111111lFuck_You_Anonymous = re.compile (l111Fuck_You_Anonymous (u"ࠨࡥࡲࡨ࡮ࡴࡧ࡜࠼ࡀࡡࡡࡹࠪࠩ࡝࠰ࡠࡼ࠴࡝ࠬࠫࠪৄ"))
    l11l1l11Fuck_You_Anonymous = re.compile (l111Fuck_You_Anonymous (u"ࠩ࠱࠮ࢀ࠶ࡽ࠯ࠬࠪ৅").format (l1lll11l1Fuck_You_Anonymous), re.DOTALL)
    def l1lll111lFuck_You_Anonymous (l111ll11Fuck_You_Anonymous):
        comment = l111ll11Fuck_You_Anonymous.group (0)
        if l11l1l11Fuck_You_Anonymous.search (comment):
            l1l1111lFuck_You_Anonymous.append (comment.replace (l1lll11l1Fuck_You_Anonymous, l111Fuck_You_Anonymous (u"ࠪࠫ৆")))
            return l111ll1lFuck_You_Anonymous
        else:
            return l111Fuck_You_Anonymous (u"ࠫࠬে")
    def l1llllll1Fuck_You_Anonymous (l111ll11Fuck_You_Anonymous):
        global l11lll11Fuck_You_Anonymous
        l11lll11Fuck_You_Anonymous += 1
        return l1l1111lFuck_You_Anonymous [l11lll11Fuck_You_Anonymous]
    l1lll1l1lFuck_You_Anonymous = (
            re.compile (l111Fuck_You_Anonymous (u"ࡷ࠭ࡻ࠱ࡿࡾ࠵ࢂࢁ࠲ࡾ࠰࠭ࡃࠩ࠭ৈ").format (
                l111Fuck_You_Anonymous (u"ࡸࠢࠩࡁ࠿ࠥࠬ࠯ࠢ৉"),
                l111Fuck_You_Anonymous (u"ࡲࠨࠪࡂࡀࠦࠨࠩࠨ৊"),
                l111Fuck_You_Anonymous (u"ࡳࠩࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࠭࠱ࠦࡲࡦ࠰ࡐ࡙ࡑ࡚ࡉࡍࡋࡑࡉ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡ࡫ࡩࠤࡵ࡫ࡰ࠹ࡡࡦࡳࡲࡳࡥ࡯ࡶࡶࠤࡪࡲࡳࡦࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡴࡨ࠲ࡨࡵ࡭ࡱ࡫࡯ࡩࠥ࠮ࡲࠨো"){0}{1}{2}.*?$l111Fuck_You_Anonymous (u"ࠩ࠱ࡪࡴࡸ࡭ࡢࡶࠣࠬࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡴࠥࠬࡄࡂࠡࠨৌ"))l111Fuck_You_Anonymous (u"ࠥ࠰ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡴࠪࠬࡄࡂ্ࠡࠣ"))l111Fuck_You_Anonymous (u"ࠫ࠱ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡵࠫৎ")#l111Fuck_You_Anonymous (u"ࠬࠦࠠࠡࠢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠫ࠯ࠤࡷ࡫࠮ࡎࡗࡏࡘࡎࡒࡉࡏࡇࠬࠑࠏࠦࠠࠡࠢࠬࠑࠏࠦࠠࠡࠢࡦࡳࡲࡳࡥ࡯ࡶࡓࡰࡦࡩࡥࡩࡱ࡯ࡨࡪࡸࠠ࠾ࠢࠪ৏")_{0}_11ll111Fuck_You_Anonymous (u"࠭࠮ࡧࡱࡵࡱࡦࡺࠠࠩࡲࡵࡳ࡬ࡸࡡ࡮ࡐࡤࡱࡪ࠯ࠍࠋࠢࠣࠤࠥࡩ࡯࡮࡯ࡨࡲࡹࡖ࡬ࡢࡥࡨ࡬ࡴࡲࡤࡦࡴࡕࡩ࡬ࡋࡸࠡ࠿ࠣࡶࡪ࠴ࡣࡰ࡯ࡳ࡭ࡱ࡫ࠠࠩࡴࠪ৐"){0}l111Fuck_You_Anonymous (u"ࠧ࠯ࡨࡲࡶࡲࡧࡴࠡࠪࡦࡳࡲࡳࡥ࡯ࡶࡓࡰࡦࡩࡥࡩࡱ࡯ࡨࡪࡸࠩࠪࠏࠍࠑࠏࠦࠠࠡࠢࠍࠑࠏࠦࠠࠡࠢ࡮ࡩࡪࡶࡓࡵࡴ࡬ࡲ࡬ࡘࡥࡨࡇࡻࠤࡂࠦࡲࡦ࠰ࡦࡳࡲࡶࡩ࡭ࡧࠣࠬࡷ࠭৑").*{0}.*l111Fuck_You_Anonymous (u"ࠨ࠰ࡩࡳࡷࡳࡡࡵࠢࠫࡴࡱࡧࡩ࡯ࡏࡤࡶࡰ࡫ࡲࠪࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࡩ࡫ࡦࠡࡩࡨࡸࡉ࡫ࡣࡰࡦࡨࡨࡘࡺࡲࡪࡰࡪࡔࡱࡧࡣࡦࡪࡲࡰࡩ࡫ࡲࡂࡰࡧࡖࡪ࡭ࡩࡴࡶࡨࡶࠥ࠮࡭ࡢࡶࡦ࡬ࡔࡨࡪࡦࡥࡷ࠭࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࡵࡷࡶ࡮ࡴࡧࠡ࠿ࠣࡱࡦࡺࡣࡩࡑࡥ࡮ࡪࡩࡴ࠯ࡩࡵࡳࡺࡶࠠࠩ࠲ࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࡩࡧࠢࡲࡦ࡫ࡻࡳࡤࡣࡷࡩࡘࡺࡲࡪࡰࡪࡷ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࡯ࡦࠡ࡭ࡨࡩࡵ࡙ࡴࡳ࡫ࡱ࡫ࡗ࡫ࡧࡆࡺ࠱ࡷࡪࡧࡲࡤࡪࠣࠬࡸࡺࡲࡪࡰࡪ࠭࠿ࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡵࡩࡵࡲࡡࡤࡧࡧࡗࡹࡸࡩ࡯ࡩࡶ࠲ࡦࡶࡰࡦࡰࡧࠤ࠭ࡹࡴࡳ࡫ࡱ࡫࠳ࡸࡥࡱ࡮ࡤࡧࡪࠦࠨࡱ࡮ࡤ࡭ࡳࡓࡡࡳ࡭ࡨࡶ࠱ࠦࠧ৒")l111Fuck_You_Anonymous (u"ࠩࠬ࠭ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡴࡨࡸࡺࡸ࡮ࠡࡵࡷࡶ࡮ࡴࡧࡑ࡮ࡤࡧࡪ࡮࡯࡭ࡦࡨࡶࠥࠦࠠࠡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡵࡩࡵࡲࡡࡤࡧࡧࡗࡹࡸࡩ࡯ࡩࡶ࠲ࡦࡶࡰࡦࡰࡧࠤ࠭ࡹࡣࡳࡣࡰࡦࡱ࡫ࠠࠩࡵࡷࡶ࡮ࡴࡧࠪࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࠦࠧ৓")l1l11ll1Fuck_You_Anonymous{0} ({1})l111Fuck_You_Anonymous (u"ࠪ࠲࡫ࡵࡲ࡮ࡣࡷࠤ࠭ࡶ࡬ࡢ࡫ࡱࡑࡦࡸ࡫ࡦࡴ࠯ࠤࡸࡺࡲࡪࡰࡪࡔࡱࡧࡣࡦࡪࡲࡰࡩ࡫ࡲࠪࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࡦ࡮ࡶࡩ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡸࡥࡱ࡮ࡤࡧࡪࡪࡓࡵࡴ࡬ࡲ࡬ࡹ࠮ࡢࡲࡳࡩࡳࡪࠠࠩࡵࡷࡶ࡮ࡴࡧࠪࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡴࡨࡸࡺࡸ࡮ࠡࡵࡷࡶ࡮ࡴࡧࡑ࡮ࡤࡧࡪ࡮࡯࡭ࡦࡨࡶࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࡤࡦࡨࠣ࡫ࡪࡺࡓࡵࡴ࡬ࡲ࡬ࠦࠨ࡮ࡣࡷࡧ࡭ࡕࡢ࡫ࡧࡦࡸ࠮ࡀࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡪࡰࡴࡨࡡ࡭ࠢࡶࡸࡷ࡯࡮ࡨࡋࡱࡨࡪࡾࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡶࡸࡷ࡯࡮ࡨࡋࡱࡨࡪࡾࠠࠬ࠿ࠣ࠵ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࠠࡳࡧࡳࡰࡦࡩࡥࡥࡕࡷࡶ࡮ࡴࡧࡴࠢ࡞ࡷࡹࡸࡩ࡯ࡩࡌࡲࡩ࡫ࡸ࡞ࠏࠍࠑࠏࠦࠠࠡࠢࡶࡸࡷ࡯࡮ࡨࡔࡨ࡫ࡊࡾࠠ࠾ࠢࡵࡩ࠳ࡩ࡯࡮ࡲ࡬ࡰࡪࠦࠨࡳࠩ৔")([l11ll1l1Fuck_You_Anonymous]|l11ll1l1Fuck_You_Anonymous|l111l1l1Fuck_You_Anonymous)?(({0})|({1})|({2})|({3}))l111Fuck_You_Anonymous (u"ࠫ࠳࡬࡯ࡳ࡯ࡤࡸࠥ࠮ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡵࠦࠬ৕")l111Fuck_You_Anonymous (u"ࠬ࠭৖").*?(?<![^\\]\\)(?<![^\\]\l111Fuck_You_Anonymous (u"࠭ࠩࠨৗ")l111Fuck_You_Anonymous (u"ࠧࠨ৘")l111Fuck_You_Anonymous (u"ࠣ࠮ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࡸࠧࠣ৙")l111Fuck_You_Anonymous (u"ࠤࠥ৚").*?(?<![^\\]\\)(?<![^\\]\l111Fuck_You_Anonymous (u"ࠥ࠭ࠧ৛")l111Fuck_You_Anonymous (u"ࠦࠧড়")l111Fuck_You_Anonymous (u"ࠬ࠲ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡵࠦࠬঢ়").*?(?<![^\\]\\)l111Fuck_You_Anonymous (u"࠭ࠢ࠭ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࡷ࠭৞")l111Fuck_You_Anonymous (u"ࠢ࠯ࠬࡂࠬࡄࡂࠡ࡜ࡠ࡟ࡠࡢࡢ࡜ࠪࠤয়")l111Fuck_You_Anonymous (u"ࠨࠏࠍࠤࠥࠦࠠࠪ࠮ࠣࡶࡪ࠴ࡍࡖࡎࡗࡍࡑࡏࡎࡆࠢࡿࠤࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠠࡽࠢࡵࡩ࠳࡜ࡅࡓࡄࡒࡗࡊ࠯ࠍࠋࠏࠍࠤࠥࠦࠠࡴࡶࡵ࡭ࡳ࡭ࡐ࡭ࡣࡦࡩ࡭ࡵ࡬ࡥࡧࡵࠤࡂࠦࠧৠ")_{0}_11l1111Fuck_You_Anonymous (u"ࠩ࠱ࡪࡴࡸ࡭ࡢࡶࠣࠬࡵࡸ࡯ࡨࡴࡤࡱࡓࡧ࡭ࡦࠫࠐࠎࠥࠦࠠࠡࡵࡷࡶ࡮ࡴࡧࡑ࡮ࡤࡧࡪ࡮࡯࡭ࡦࡨࡶࡗ࡫ࡧࡆࡺࠣࡁࠥࡸࡥ࠯ࡥࡲࡱࡵ࡯࡬ࡦࠢࠫࡶࠬৡ"){0}l111Fuck_You_Anonymous (u"ࠪ࠲࡫ࡵࡲ࡮ࡣࡷࠤ࠭ࡹࡴࡳ࡫ࡱ࡫ࡕࡲࡡࡤࡧ࡫ࡳࡱࡪࡥࡳࠫࠬࠑࠏࠓࠊࠡࠢࠣࠤࠏࠓࠊࠡࠢࠣࠤࡩ࡫ࡦࠡ࡯ࡲࡺࡪࡌࡲࡰ࡯ࡉࡹࡹࡻࡲࡦࠢࠫࡱࡦࡺࡣࡩࡑࡥ࡮ࡪࡩࡴࠪ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥ࡬ࡲࡰ࡯ࡉࡹࡹࡻࡲࡦࠢࡀࠤࡲࡧࡴࡤࡪࡒࡦ࡯࡫ࡣࡵ࠰ࡪࡶࡴࡻࡰࠡࠪ࠳࠭ࠒࠐࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥ࡬ࡲࡰ࡯ࡉࡹࡹࡻࡲࡦ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡪࡰࡴࡨࡡ࡭ࠢࡱࡶࡔ࡬ࡓࡱࡧࡦ࡭ࡦࡲࡌࡪࡰࡨࡷࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡨࡵ࡮ࡵࡧࡱࡸࡑ࡯ࡳࡵࠢ࡞ࡲࡷࡕࡦࡔࡲࡨࡧ࡮ࡧ࡬ࡍ࡫ࡱࡩࡸࡀ࡮ࡳࡑࡩࡗࡵ࡫ࡣࡪࡣ࡯ࡐ࡮ࡴࡥࡴ࡟ࠣࡁࠥࡡࡦࡳࡱࡰࡊࡺࡺࡵࡳࡧࡠࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡳࡸࡏࡧࡕࡳࡩࡨ࡯ࡡ࡭ࡎ࡬ࡲࡪࡹࠠࠬ࠿ࠣ࠵ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࠠࠨৢ")l111Fuck_You_Anonymous (u"ࠫࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࡦࡳࡱࡰࡊࡺࡺࡵࡳࡧࡕࡩ࡬ࡋࡸࠡ࠿ࠣࡶࡪ࠴ࡣࡰ࡯ࡳ࡭ࡱ࡫ࠠࠩࠩৣ")from\s*__future__\s*import\s*\w+.*$l111Fuck_You_Anonymous (u"ࠬ࠲ࠠࡳࡧ࠱ࡑ࡚ࡒࡔࡊࡎࡌࡒࡊ࠯ࠍࠋࠏࠍࠤࠥࠦࠠࠋࠏࠍࠤࠥࠦࠠࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࡖࡪ࡭ࡅࡹࠢࡀࠤࡷ࡫࠮ࡤࡱࡰࡴ࡮ࡲࡥࠡࠪࡵࠫ৤")l111Fuck_You_Anonymous (u"࠭ࠧ৥")
        \b
        (?!{0})
        (?!{1})
        [^\d\W]
        \w*
        (?<!__)
        (?<!{0})
        (?<!{1})
        \b
    l111Fuck_You_Anonymous (u"ࠧࠨࠩ࠱ࡪࡴࡸ࡭ࡢࡶࠣࠬࡨࡵ࡭࡮ࡧࡱࡸࡕࡲࡡࡤࡧ࡫ࡳࡱࡪࡥࡳ࠮ࠣࡷࡹࡸࡩ࡯ࡩࡓࡰࡦࡩࡥࡩࡱ࡯ࡨࡪࡸࠩ࠭ࠢࡵࡩ࠳࡜ࡅࡓࡄࡒࡗࡊ࠯ࠠࠋࠏࠍࠤࠥࠦࠠࡤࡪࡵࡖࡪ࡭ࡅࡹࠢࡀࠤࡷ࡫࠮ࡤࡱࡰࡴ࡮ࡲࡥࠡࠪࡵࠫࡡࡨࡣࡩࡴ࡟ࡦࠬ࠯ࠍࠋࠏࠍࠤࠥࠦࠠࠋࠏࠍࠤࠥࠦࠠࡴ࡭࡬ࡴ࡜ࡵࡲࡥࡕࡨࡸࠥࡃࠠࡴࡧࡷࠤ࠭ࡱࡥࡺࡹࡲࡶࡩ࠴࡫ࡸ࡮࡬ࡷࡹࠦࠫࠡ࡝ࠪࡣࡤ࡯࡮ࡪࡶࡢࡣࠬࡣࠠࠬࠢࡨࡼࡹࡸࡡࡑ࡮ࡤ࡭ࡳ࡝࡯ࡳࡦࡏ࡭ࡸࡺࠩࠡࠢࠍࠑࠏࠦࠠࠡࠢࡳࡰࡦ࡯࡮ࡇ࡫࡯ࡩࡕࡧࡴࡩࡎ࡬ࡷࡹࠦ࠽ࠡ࡝ࠪࡿ࠵ࢃ࠯ࡼ࠳ࢀࠫ࠳࡬࡯ࡳ࡯ࡤࡸࠥ࠮ࡳࡰࡷࡵࡧࡪࡘ࡯ࡰࡶࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽ࠱ࠦࡰ࡭ࡣ࡬ࡲࡋ࡯࡬ࡦࡔࡨࡰࡕࡧࡴࡩࠫࠣࡪࡴࡸࠠࡱ࡮ࡤ࡭ࡳࡌࡩ࡭ࡧࡕࡩࡱࡖࡡࡵࡪࠣ࡭ࡳࠦࡰ࡭ࡣ࡬ࡲࡋ࡯࡬ࡦࡔࡨࡰࡕࡧࡴࡩࡎ࡬ࡷࡹࡣࠍࠋࠢࠣࠤࠥ࡬࡯ࡳࠢࡳࡰࡦ࡯࡮ࡇ࡫࡯ࡩࡕࡧࡴࡩࠢ࡬ࡲࠥࡶ࡬ࡢ࡫ࡱࡊ࡮ࡲࡥࡑࡣࡷ࡬ࡑ࡯ࡳࡵ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࡶ࡬ࡢ࡫ࡱࡊ࡮ࡲࡥࠡ࠿ࠣࡳࡵ࡫࡮ࠡࠪࡳࡰࡦ࡯࡮ࡇ࡫࡯ࡩࡕࡧࡴࡩࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࠽ࠡࡲ࡯ࡥ࡮ࡴࡆࡪ࡮ࡨ࠲ࡷ࡫ࡡࡥࠢࠫ࠭ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࡱ࡮ࡤ࡭ࡳࡌࡩ࡭ࡧ࠱ࡧࡱࡵࡳࡦࠢࠫ࠭ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠎࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡀࠤࡨࡵ࡭࡮ࡧࡱࡸࡗ࡫ࡧࡆࡺ࠱ࡷࡺࡨࠠࠩࠩࠪ࠰ࠥࡩ࡯࡯ࡶࡨࡲࡹ࠯ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࡧࡴࡴࡴࡦࡰࡷࠤࡂࠦࡳࡵࡴ࡬ࡲ࡬ࡘࡥࡨࡇࡻ࠲ࡸࡻࡢࠡࠪࠪࠫ࠱ࠦࡣࡰࡰࡷࡩࡳࡺࠩࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࡸࡱࡩࡱ࡙ࡲࡶࡩ࡙ࡥࡵ࠰ࡸࡴࡩࡧࡴࡦࠢࠫࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠠࠩ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࡗ࡫ࡧࡆࡺ࠯ࠤࡨࡵ࡮ࡵࡧࡱࡸ࠮࠯ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࡥ࡯ࡥࡸࡹࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࡏࡲࡨࡺࡲࡥࡴ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࡪࡥࡧࠢࡢࡣ࡮ࡴࡩࡵࡡࡢࠤ࠭ࡹࡥ࡭ࡨࠬ࠾ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡫ࡵࡲࠡࡧࡻࡸࡪࡸ࡮ࡢ࡮ࡐࡳࡩࡻ࡬ࡦࡐࡤࡱࡪࠦࡩ࡯ࠢࡨࡼࡹ࡫ࡲ࡯ࡣ࡯ࡑࡴࡪࡵ࡭ࡧࡑࡥࡲ࡫ࡌࡪࡵࡷ࠾ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡣࡷࡸࡷ࡯ࡢࡶࡶࡨࡒࡦࡳࡥࠡ࠿ࠣࡩࡽࡺࡥࡳࡰࡤࡰࡒࡵࡤࡶ࡮ࡨࡒࡦࡳࡥ࠯ࡴࡨࡴࡱࡧࡣࡦࠢࠫࠫ࠳࠭ࠬࠡࡲ࡯ࡥ࡮ࡴࡍࡢࡴ࡮ࡩࡷ࠯ࠠࠡࠢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡷࡶࡾࡀࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡦࡺࡨࡧࠥ࠮ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠬ࠭ࠧ০")
import {0} as currentModule
                        l111Fuck_You_Anonymous (u"ࠨࠩ১")l111Fuck_You_Anonymous (u"ࠩ࠱ࡪࡴࡸ࡭ࡢࡶࠣࠬࡪࡾࡴࡦࡴࡱࡥࡱࡓ࡯ࡥࡷ࡯ࡩࡓࡧ࡭ࡦࠫ࠯ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡩ࡯ࡳࡧࡧ࡬ࡴࠢࠫ࠭ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠯ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡴࡧࡷࡥࡹࡺࡲࠡࠪࡶࡩࡱ࡬ࠬࠡࡣࡷࡸࡷ࡯ࡢࡶࡶࡨࡒࡦࡳࡥ࠭ࠢࡦࡹࡷࡸࡥ࡯ࡶࡐࡳࡩࡻ࡬ࡦࠫࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡩࡽࡩࡥࡱࡶࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡡࡴࠢࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡰࡳ࡫ࡱࡸࠥ࠮ࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡷࡪࡺࡡࡵࡶࡵࠤ࠭ࡹࡥ࡭ࡨ࠯ࠤࡦࡺࡴࡳ࡫ࡥࡹࡹ࡫ࡎࡢ࡯ࡨ࠰ࠥࡔ࡯࡯ࡧࠬࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡵࡸࡩ࡯ࡶࠣࠬࠬ২")Warning: l1lll1lllFuck_You_Anonymous not inspect l1111111Fuck_You_Anonymous module {0}l111Fuck_You_Anonymous (u"ࠪ࠲࡫ࡵࡲ࡮ࡣࡷࠤ࠭࡫ࡸࡵࡧࡵࡲࡦࡲࡍࡰࡦࡸࡰࡪࡔࡡ࡮ࡧࠬ࠭ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࡏࡲࡨࡺࡲࡥࡴࠢࡀࠤࡊࡾࡴࡦࡴࡱࡥࡱࡓ࡯ࡥࡷ࡯ࡩࡸࠦࠨࠪࠏࠍࠤࠥࠦࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࡑࡥ࡮ࡪࡩࡴࡴࠢࡀࠤࡸ࡫ࡴࠡࠪࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࡤࡦࡨࠣࡥࡩࡪࡅࡹࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࡸࠦࠨࡢࡰࡒࡦ࡯࡫ࡣࡵࠫ࠽ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࡩࡧࠢࡤࡲࡔࡨࡪࡦࡥࡷࠤ࡮ࡴࠠࡦࡺࡷࡩࡷࡴࡡ࡭ࡑࡥ࡮ࡪࡩࡴࡴ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡵࡩࡹࡻࡲ࡯ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࡪࡲࡳࡦ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡼࡹ࡫ࡲ࡯ࡣ࡯ࡓࡧࡰࡥࡤࡶࡶ࠲ࡺࡶࡤࡢࡶࡨࠤ࠭ࡡࡡ࡯ࡑࡥ࡮ࡪࡩࡴ࡞ࠫࠐࠎࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࡵࡴࡼ࠾ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡦࡺࡴࡳ࡫ࡥࡹࡹ࡫ࡎࡢ࡯ࡨࡐ࡮ࡹࡴࠡ࠿ࠣࡰ࡮ࡹࡴࠡࠪࡤࡲࡔࡨࡪࡦࡥࡷ࠲ࡤࡥࡤࡪࡥࡷࡣࡤ࠯ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡨࡼࡨ࡫ࡰࡵ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡤࡸࡹࡸࡩࡣࡷࡷࡩࡓࡧ࡭ࡦࡎ࡬ࡷࡹࠦ࠽ࠡ࡝ࡠࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡷࡶࡾࡀࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡩࡧࠢ࡬ࡷࡕࡿࡴࡩࡱࡱ࠶࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡓࡧ࡭ࡦࡎ࡬ࡷࡹࠦ࠽ࠡ࡮࡬ࡷࡹࠦࠨࡢࡰࡒࡦ࡯࡫ࡣࡵ࠰ࡩࡹࡳࡩ࡟ࡤࡱࡧࡩ࠳ࡩ࡯ࡠࡸࡤࡶࡳࡧ࡭ࡦࡵࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡩࡱࡹࡥ࠻ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࡏࡣࡰࡩࡑ࡯ࡳࡵࠢࡀࠤࡱ࡯ࡳࡵࠢࠫࡥࡳࡕࡢ࡫ࡧࡦࡸ࠳ࡥ࡟ࡤࡱࡧࡩࡤࡥ࠮ࡤࡱࡢࡺࡦࡸ࡮ࡢ࡯ࡨࡷ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࡧࡻࡧࡪࡶࡴ࠻ࠢࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࡐࡤࡱࡪࡒࡩࡴࡶࠣࡁࠥࡡ࡝ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࡥࡹࡺࡲࡪࡤࡸࡸࡪࡒࡩࡴࡶࠣࡁࠥࡡࡧࡦࡶࡤࡸࡹࡸࠠࠩࡣࡱࡓࡧࡰࡥࡤࡶ࠯ࠤࡦࡺࡴࡳ࡫ࡥࡹࡹ࡫ࡎࡢ࡯ࡨ࠭ࠥ࡬࡯ࡳࠢࡤࡸࡹࡸࡩࡣࡷࡷࡩࡓࡧ࡭ࡦࠢ࡬ࡲࠥࡧࡴࡵࡴ࡬ࡦࡺࡺࡥࡏࡣࡰࡩࡑ࡯ࡳࡵ࡟ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࡧࡴࡵࡴ࡬ࡦࡺࡺࡥࡔ࡭࡬ࡴ࡜ࡵࡲࡥࡎ࡬ࡷࡹࠦ࠽ࠡࠪࡳࡰࡦ࡯࡮ࡎࡣࡵ࡯ࡪࡸ࠮࡫ࡱ࡬ࡲࠥ࠮ࡡࡵࡶࡵ࡭ࡧࡻࡴࡦࡐࡤࡱࡪࡒࡩࡴࡶࠬ࠭ࠥ࠴ࡳࡱ࡮࡬ࡸࠥ࠮ࡰ࡭ࡣ࡬ࡲࡒࡧࡲ࡬ࡧࡵ࠭ࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࡹࡵࡪࡡࡵࡧࡖࡩࡹࠦ࠽ࠡࡵࡨࡸࠥ࠮࡛ࡦࡰࡷࡶࡾࠦࡦࡰࡴࠣࡩࡳࡺࡲࡺࠢ࡬ࡲࠥ࠮ࡰࡢࡴࡤࡱࡪࡺࡥࡳࡐࡤࡱࡪࡒࡩࡴࡶࠣ࠯ࠥࡧࡴࡵࡴ࡬ࡦࡺࡺࡥࡔ࡭࡬ࡴ࡜ࡵࡲࡥࡎ࡬ࡷࡹ࠯ࠠࡪࡨࠣࡲࡴࡺࠠࠩࡧࡱࡸࡷࡿ࠮ࡴࡶࡤࡶࡹࡹࡷࡪࡶ࡫ࠤ࠭࠭৩")__11111l1Fuck_You_Anonymous (u"ࠫ࠮ࠦࡡ࡯ࡦࠣࡩࡳࡺࡲࡺ࠰ࡨࡲࡩࡹࡷࡪࡶ࡫ࠤ࠭࠭৪")__11111l1Fuck_You_Anonymous (u"ࠬ࠯ࠩ࡞ࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࡷࡰ࡯ࡰࡘࡱࡵࡨࡘ࡫ࡴ࠯ࡷࡳࡨࡦࡺࡥࠡࠪࡸࡴࡩࡧࡴࡦࡕࡨࡸ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࡫ࡵࡲࠡࡣࡷࡸࡷ࡯ࡢࡶࡶࡨࠤ࡮ࡴࠠࡢࡶࡷࡶ࡮ࡨࡵࡵࡧࡏ࡭ࡸࡺ࠺ࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡶࡵࡽ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡤࡨࡩࡋࡸࡵࡧࡵࡲࡦࡲࡎࡢ࡯ࡨࡷࠥ࠮ࡡࡵࡶࡵ࡭ࡧࡻࡴࡦࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡼࡨ࡫ࡰࡵ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡰࡢࡵࡶࠑࠏࠓࠊࠡࠢࠣࠤࡦࡪࡤࡆࡺࡷࡩࡷࡴࡡ࡭ࡐࡤࡱࡪࡹࠠࠩࡡࡢࡦࡺ࡯࡬ࡵ࡫ࡱࡷࡤࡥࠩࠎࠌࠣࠤࠥࠦࡡࡥࡦࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࡒࡦࡳࡥࡴࠢࠫࡩࡽࡺࡥࡳࡰࡤࡰࡒࡵࡤࡶ࡮ࡨࡷ࠮ࠓࠊࠎࠌࠣࠤࠥࠦࡳ࡬࡫ࡳ࡛ࡴࡸࡤࡍ࡫ࡶࡸࠥࡃࠠ࡭࡫ࡶࡸࠥ࠮ࡳ࡬࡫ࡳ࡛ࡴࡸࡤࡔࡧࡷ࠭ࠒࠐࠠࠡࠢࠣࡷࡰ࡯ࡰࡘࡱࡵࡨࡑ࡯ࡳࡵ࠰ࡶࡳࡷࡺࠠࠩ࡭ࡨࡽࠥࡃࠠ࡭ࡣࡰࡦࡩࡧࠠࡴ࠼ࠣࡷ࠳ࡲ࡯ࡸࡧࡵࠤ࠭࠯ࠩࠎࠌࠐࠎࠥࠦࠠࠡࠌࠐࠎࠥࠦࠠࠡࡱࡥࡪࡺࡹࡣࡢࡶࡨࡨ࡜ࡵࡲࡥࡎ࡬ࡷࡹࠦ࠽ࠡ࡝ࡠࠑࠏࠦࠠࠡࠢࡲࡦ࡫ࡻࡳࡤࡣࡷࡩࡩࡘࡥࡨࡇࡻࡐ࡮ࡹࡴࠡ࠿ࠣ࡟ࡢࠓࠊࠎࠌࠣࠤࠥࠦࡦࡰࡴࠣࡷࡴࡻࡲࡤࡧࡉ࡭ࡱ࡫ࡐࡢࡶ࡫ࠤ࡮ࡴࠠࡴࡱࡸࡶࡨ࡫ࡆࡪ࡮ࡨࡔࡦࡺࡨࡍ࡫ࡶࡸ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡ࡫ࡩࠤࡸࡵࡵࡳࡥࡨࡊ࡮ࡲࡥࡑࡣࡷ࡬ࠥࡃ࠽ࠡࡥࡲࡲ࡫࡯ࡧࡇ࡫࡯ࡩࡕࡧࡴࡩ࠼ࠣࠤࠥࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠍࠋࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࡸࡵࡵࡳࡥࡨࡈ࡮ࡸࡥࡤࡶࡲࡶࡾ࠲ࠠࡴࡱࡸࡶࡨ࡫ࡆࡪ࡮ࡨࡒࡦࡳࡥࠡ࠿ࠣࡷࡴࡻࡲࡤࡧࡉ࡭ࡱ࡫ࡐࡢࡶ࡫࠲ࡷࡹࡰ࡭࡫ࡷࠤ࠭࠭৫")/l111Fuck_You_Anonymous (u"࠭ࠬࠡ࠳ࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࡳࡰࡷࡵࡧࡪࡌࡩ࡭ࡧࡓࡶࡪࡔࡡ࡮ࡧ࠯ࠤࡸࡵࡵࡳࡥࡨࡊ࡮ࡲࡥࡏࡣࡰࡩࡊࡾࡴࡦࡰࡶ࡭ࡴࡴࠠ࠾ࠢࠫࡷࡴࡻࡲࡤࡧࡉ࡭ࡱ࡫ࡎࡢ࡯ࡨ࠲ࡷࡹࡰ࡭࡫ࡷࠤ࠭࠭৬").l111Fuck_You_Anonymous (u"ࠧ࠭ࠢ࠴࠭ࠥ࠱ࠠ࡜ࠩ৭")l111Fuck_You_Anonymous (u"ࠨ࡟ࠬࠤࡠࠦ࠺ࠡ࠴ࡠࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࡴࡢࡴࡪࡩࡹࡘࡥ࡭ࡕࡸࡦࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠠ࠾ࠢࠣࡷࡴࡻࡲࡤࡧࡉ࡭ࡱ࡫ࡐࡢࡶ࡫ࠤࡠࡲࡥ࡯ࠢࠫࡷࡴࡻࡲࡤࡧࡕࡳࡴࡺࡄࡪࡴࡨࡧࡹࡵࡲࡺࠫࠣ࠾ࠥࡣࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠐࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡹ࡯ࡶࡴࡦࡩࡋ࡯࡬ࡦࡐࡤࡱࡪࡋࡸࡵࡧࡱࡷ࡮ࡵ࡮ࠡ࡫ࡱࠤࡸࡵࡵࡳࡥࡨࡊ࡮ࡲࡥࡏࡣࡰࡩࡊࡾࡴࡦࡰࡶ࡭ࡴࡴࡌࡪࡵࡷࠤࡦࡴࡤࠡࡰࡲࡸࠥࡹ࡯ࡶࡴࡦࡩࡋ࡯࡬ࡦࡒࡤࡸ࡭ࠦࡩ࡯ࠢࡳࡰࡦ࡯࡮ࡇ࡫࡯ࡩࡕࡧࡴࡩࡎ࡬ࡷࡹࡀࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡳࡵࡴ࡬ࡲ࡬ࡈࡡࡴࡧࠣࡁࠥࡸࡡ࡯ࡦࡲࡱ࠳ࡸࡡ࡯ࡦࡵࡥࡳ࡭ࡥࠡࠪ࠹࠸࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡵࡲࡹࡷࡩࡥࡇ࡫࡯ࡩࠥࡃࠠࡤࡱࡧࡩࡨࡹ࠮ࡰࡲࡨࡲࠥ࠮ࡳࡰࡷࡵࡧࡪࡌࡩ࡭ࡧࡓࡥࡹ࡮ࠬࠡࡧࡱࡧࡴࡪࡩ࡯ࡩࠣࡁࠥ࠭৮")l1llll1l1Fuck_You_Anonymous-8unScramble_opy_ (u"ࠩࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡧࡴࡴࡴࡦࡰࡷࠤࡂࠦࡳࡰࡷࡵࡧࡪࡌࡩ࡭ࡧ࠱ࡶࡪࡧࡤࠡࠪࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡷࡴࡻࡲࡤࡧࡉ࡭ࡱ࡫࠮ࡤ࡮ࡲࡷࡪࠦࠨࠪࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡴࡨࡴࡱࡧࡣࡦࡦࡆࡳࡲࡳࡥ࡯ࡶࡶࠤࡂ࡛ࠦ࡞ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡥࡲࡲࡹ࡫࡮ࡵࡎ࡬ࡷࡹࠦ࠽ࠡࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡶࡴࡱ࡯ࡴࠡࠪࠪ৯")\l11l11l1Fuck_You_Anonymous (u"ࠪ࠰ࠥ࠸ࠩࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡳࡸࡏࡧࡕࡳࡩࡨ࡯ࡡ࡭ࡎ࡬ࡲࡪࡹࠠ࠾ࠢ࠳ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣ࡭ࡳࡹࡥࡳࡶࡆࡳࡩ࡯࡮ࡨࡅࡲࡱࡲ࡫࡮ࡵࠢࡀࠤ࡙ࡸࡵࡦࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࡫ࡩࠤࡱ࡫࡮ࠡࠪࡦࡳࡳࡺࡥ࡯ࡶࡏ࡭ࡸࡺࠩࠡࡀࠣ࠴࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥࡹࡨࡦࡤࡤࡲ࡬ࡉ࡯࡮࡯ࡨࡲࡹࡘࡥࡨࡇࡻ࠲ࡸ࡫ࡡࡳࡥ࡫ࠤ࠭ࡩ࡯࡯ࡶࡨࡲࡹࡒࡩࡴࡶࠣ࡟࠵ࡣࠩ࠻ࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡴࡲࡐࡨࡖࡴࡪࡩࡩࡢ࡮ࡏ࡭ࡳ࡫ࡳࠡ࠭ࡀࠤ࠶ࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡮࡬ࠠ࡭ࡧࡱࠤ࠭ࡩ࡯࡯ࡶࡨࡲࡹࡒࡩࡴࡶࠬࠤࡃࠦ࠱ࠡࡣࡱࡨࠥࡩ࡯ࡥ࡫ࡱ࡫ࡈࡵ࡭࡮ࡧࡱࡸࡗ࡫ࡧࡆࡺ࠱ࡷࡪࡧࡲࡤࡪࠣࠬࡨࡵ࡮ࡵࡧࡱࡸࡑ࡯ࡳࡵࠢ࡞࠵ࡢ࠯࠺ࠡࠢࠣࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࡯ࡴࡒࡪࡘࡶࡥࡤ࡫ࡤࡰࡑ࡯࡮ࡦࡵࠣ࠯ࡂࠦ࠱ࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡩ࡯ࡵࡨࡶࡹࡉ࡯ࡥ࡫ࡱ࡫ࡈࡵ࡭࡮ࡧࡱࡸࠥࡃࠠࡇࡣ࡯ࡷࡪࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡪࡲࡩࡧࠢࡦࡳࡩ࡯࡮ࡨࡅࡲࡱࡲ࡫࡮ࡵࡔࡨ࡫ࡊࡾ࠮ࡴࡧࡤࡶࡨ࡮ࠠࠩࡥࡲࡲࡹ࡫࡮ࡵࡎ࡬ࡷࡹ࡛ࠦ࠱࡟ࠬ࠾ࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࡯ࡴࡒࡪࡘࡶࡥࡤ࡫ࡤࡰࡑ࡯࡮ࡦࡵࠣ࠯ࡂࠦ࠱ࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡩ࡯ࡵࡨࡶࡹࡉ࡯ࡥ࡫ࡱ࡫ࡈࡵ࡭࡮ࡧࡱࡸࠥࡃࠠࡇࡣ࡯ࡷࡪࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࡫ࡩࠤࡴࡨࡦࡶࡵࡦࡥࡹ࡫ࡓࡵࡴ࡬ࡲ࡬ࡹࠠࡢࡰࡧࠤ࡮ࡴࡳࡦࡴࡷࡇࡴࡪࡩ࡯ࡩࡆࡳࡲࡳࡥ࡯ࡶ࠽ࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡨࡵ࡮ࡵࡧࡱࡸࡑ࡯ࡳࡵࠢ࡞ࡲࡷࡕࡦࡔࡲࡨࡧ࡮ࡧ࡬ࡍ࡫ࡱࡩࡸࡀ࡮ࡳࡑࡩࡗࡵ࡫ࡣࡪࡣ࡯ࡐ࡮ࡴࡥࡴ࡟ࠣࡁࠥࡡࠧৰ")# l1l11l11Fuck_You_Anonymous: l111l11lFuck_You_Anonymous-8unScramble_opy_ (u"ࠫࡢࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡴࡲࡐࡨࡖࡴࡪࡩࡩࡢ࡮ࡏ࡭ࡳ࡫ࡳࠡ࠭ࡀࠤ࠶ࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡩࡧࠢࡲࡦ࡫ࡻࡳࡤࡣࡷࡩࡘࡺࡲࡪࡰࡪࡷ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡱࡳࡷࡳࡡ࡭ࡅࡲࡲࡹ࡫࡮ࡵࠢࡀࠤࠬৱ")\l11l11l1Fuck_You_Anonymous (u"ࠬ࠴ࡪࡰ࡫ࡱࠤ࠭ࡡࡧࡦࡶࡘࡲࡘࡩࡲࡢ࡯ࡥࡰࡪࡸࠠࠩࡵࡷࡶ࡮ࡴࡧࡃࡣࡶࡩ࠮ࡣࠠࠬࠢࡦࡳࡳࡺࡥ࡯ࡶࡏ࡭ࡸࡺࠠ࡜ࡰࡵࡓ࡫࡙ࡰࡦࡥ࡬ࡥࡱࡒࡩ࡯ࡧࡶ࠾ࡢ࠯ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡥ࡭ࡵࡨ࠾ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡰࡲࡶࡲࡧ࡬ࡄࡱࡱࡸࡪࡴࡴࠡ࠿ࠣࠫ৲")\l11l11l1Fuck_You_Anonymous (u"࠭࠮࡫ࡱ࡬ࡲࠥ࠮ࡣࡰࡰࡷࡩࡳࡺࡌࡪࡵࡷࠤࡠࡴࡲࡐࡨࡖࡴࡪࡩࡩࡢ࡮ࡏ࡭ࡳ࡫ࡳ࠻࡟ࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡴ࡯ࡳ࡯ࡤࡰࡈࡵ࡮ࡵࡧࡱࡸࠥࡃࠠࡤࡱࡰࡱࡪࡴࡴࡓࡧࡪࡉࡽ࠴ࡳࡶࡤࠣࠬ࡬࡫ࡴࡄࡱࡰࡱࡪࡴࡴࡑ࡮ࡤࡧࡪ࡮࡯࡭ࡦࡨࡶࡆࡴࡤࡓࡧࡪ࡭ࡸࡺࡥࡳ࠮ࠣࡲࡴࡸ࡭ࡢ࡮ࡆࡳࡳࡺࡥ࡯ࡶࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡶࡪࡶ࡬ࡢࡥࡨࡨࡘࡺࡲࡪࡰࡪࡷࠥࡃࠠ࡜࡟ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡱࡳࡷࡳࡡ࡭ࡅࡲࡲࡹ࡫࡮ࡵࠢࡀࠤࡸࡺࡲࡪࡰࡪࡖࡪ࡭ࡅࡹ࠰ࡶࡹࡧࠦࠨࡨࡧࡷࡈࡪࡩ࡯ࡥࡧࡧࡗࡹࡸࡩ࡯ࡩࡓࡰࡦࡩࡥࡩࡱ࡯ࡨࡪࡸࡁ࡯ࡦࡕࡩ࡬࡯ࡳࡵࡧࡵ࠰ࠥࡴ࡯ࡳ࡯ࡤࡰࡈࡵ࡮ࡵࡧࡱࡸ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡲࡴࡸ࡭ࡢ࡮ࡆࡳࡳࡺࡥ࡯ࡶࠣࡁࠥ࡬ࡲࡰ࡯ࡉࡹࡹࡻࡲࡦࡔࡨ࡫ࡊࡾ࠮ࡴࡷࡥࠤ࠭ࡳ࡯ࡷࡧࡉࡶࡴࡳࡆࡶࡶࡸࡶࡪ࠲ࠠ࡯ࡱࡵࡱࡦࡲࡃࡰࡰࡷࡩࡳࡺࠩࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡶࡳࡺࡸࡣࡦ࡙ࡲࡶࡩ࡙ࡥࡵࠢࡀࠤࡸ࡫ࡴࠡࠪࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱࠦࠨࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࡖࡪ࡭ࡅࡹ࠮ࠣࡲࡴࡸ࡭ࡢ࡮ࡆࡳࡳࡺࡥ࡯ࡶࠬࠤ࠰࡛ࠦࡴࡱࡸࡶࡨ࡫ࡆࡪ࡮ࡨࡔࡷ࡫ࡎࡢ࡯ࡨࡡ࠮ࠓࠊࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡳࡵࡴ࡬ࡴࡵ࡫ࡤࡔࡱࡸࡶࡨ࡫ࡗࡰࡴࡧࡗࡪࡺࠠ࠾ࠢࡶࡳࡺࡸࡣࡦ࡙ࡲࡶࡩ࡙ࡥࡵ࠰ࡧ࡭࡫࡬ࡥࡳࡧࡱࡧࡪࠦࠨࡰࡤࡩࡹࡸࡩࡡࡵࡧࡧ࡛ࡴࡸࡤࡍ࡫ࡶࡸ࠮࠴ࡤࡪࡨࡩࡩࡷ࡫࡮ࡤࡧࠣࠬࡸࡱࡩࡱ࡙ࡲࡶࡩ࡙ࡥࡵࠫࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡷࡹࡸࡩࡱࡲࡨࡨࡘࡵࡵࡳࡥࡨ࡛ࡴࡸࡤࡍ࡫ࡶࡸࠥࡃࠠ࡭࡫ࡶࡸࠥ࠮ࡳࡵࡴ࡬ࡴࡵ࡫ࡤࡔࡱࡸࡶࡨ࡫ࡗࡰࡴࡧࡗࡪࡺࠩࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡴࡶࡵ࡭ࡵࡶࡥࡥࡕࡲࡹࡷࡩࡥࡓࡧࡪࡉࡽࡒࡩࡴࡶࠣࡁࠥࡡࡲࡦ࠰ࡦࡳࡲࡶࡩ࡭ࡧࠣࠬࡷ࠭৳")\b{0}\l1l111l1Fuck_You_Anonymous (u"ࠧ࠯ࡨࡲࡶࡲࡧࡴࠡࠪࡶࡳࡺࡸࡣࡦ࡙ࡲࡶࡩ࠯ࠩࠡࡨࡲࡶࠥࡹ࡯ࡶࡴࡦࡩ࡜ࡵࡲࡥࠢ࡬ࡲࠥࡹࡴࡳ࡫ࡳࡴࡪࡪࡓࡰࡷࡵࡧࡪ࡝࡯ࡳࡦࡏ࡭ࡸࡺ࡝ࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡳࡧ࡬ࡵࡴࡥࡤࡸࡪࡪࡗࡰࡴࡧࡐ࡮ࡹࡴࠡ࠭ࡀࠤࡸࡺࡲࡪࡲࡳࡩࡩ࡙࡯ࡶࡴࡦࡩ࡜ࡵࡲࡥࡎ࡬ࡷࡹࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡳࡧ࡬ࡵࡴࡥࡤࡸࡪࡪࡒࡦࡩࡈࡼࡑ࡯ࡳࡵࠢ࠮ࡁࠥࡹࡴࡳ࡫ࡳࡴࡪࡪࡓࡰࡷࡵࡧࡪࡘࡥࡨࡇࡻࡐ࡮ࡹࡴࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡦࡰࡴࠣࡳࡧ࡬ࡵࡴࡥࡤࡸ࡮ࡵ࡮ࡊࡰࡧࡩࡽ࠲ࠠࡰࡤࡩࡹࡸࡩࡡࡵࡧࡧࡖࡪ࡭ࡅࡹࠢ࡬ࡲࠥ࡫࡮ࡶ࡯ࡨࡶࡦࡺࡥࠡࠪࡲࡦ࡫ࡻࡳࡤࡣࡷࡩࡩࡘࡥࡨࡇࡻࡐ࡮ࡹࡴࠪ࠼ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࡮ࡰࡴࡰࡥࡱࡉ࡯࡯ࡶࡨࡲࡹࠦ࠽ࠡࡱࡥࡪࡺࡹࡣࡢࡶࡨࡨࡗ࡫ࡧࡆࡺ࠱ࡷࡺࡨࠠࠩࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡪࡩࡹࡕࡢࡧࡷࡶࡧࡦࡺࡥࡥࡐࡤࡱࡪࠦࠨࡰࡤࡩࡹࡸࡩࡡࡵ࡫ࡲࡲࡎࡴࡤࡦࡺ࠯ࠤࡴࡨࡦࡶࡵࡦࡥࡹ࡫ࡤࡘࡱࡵࡨࡑ࡯ࡳࡵࠢ࡞ࡳࡧ࡬ࡵࡴࡥࡤࡸ࡮ࡵ࡮ࡊࡰࡧࡩࡽࡣࠩ࠭ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡱࡳࡷࡳࡡ࡭ࡅࡲࡲࡹ࡫࡮ࡵࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࠯ࠠࠡࠢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡸࡺࡲࡪࡰࡪࡍࡳࡪࡥࡹࠢࡀࠤ࠲࠷ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࡮ࡰࡴࡰࡥࡱࡉ࡯࡯ࡶࡨࡲࡹࠦ࠽ࠡࡵࡷࡶ࡮ࡴࡧࡑ࡮ࡤࡧࡪ࡮࡯࡭ࡦࡨࡶࡗ࡫ࡧࡆࡺ࠱ࡷࡺࡨࠠࠩࡩࡨࡸࡘࡺࡲࡪࡰࡪ࠰ࠥࡴ࡯ࡳ࡯ࡤࡰࡈࡵ࡮ࡵࡧࡱࡸ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡤࡱࡰࡱࡪࡴࡴࡊࡰࡧࡩࡽࠦ࠽ࠡ࠯࠴ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡲࡴࡸ࡭ࡢ࡮ࡆࡳࡳࡺࡥ࡯ࡶࠣࡁࠥࡩ࡯࡮࡯ࡨࡲࡹࡖ࡬ࡢࡥࡨ࡬ࡴࡲࡤࡦࡴࡕࡩ࡬ࡋࡸ࠯ࡵࡸࡦࠥ࠮ࡧࡦࡶࡆࡳࡲࡳࡥ࡯ࡶ࠯ࠤࡳࡵࡲ࡮ࡣ࡯ࡇࡴࡴࡴࡦࡰࡷ࠭ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡃࠠࠨ৴")\l11l11l1Fuck_You_Anonymous (u"ࠨ࠰࡭ࡳ࡮ࡴࠠࠩࡥࡲࡲࡹ࡫࡮ࡵࡎ࡬ࡷࡹ࡛ࠦ࠻ࡰࡵࡓ࡫࡙ࡰࡦࡥ࡬ࡥࡱࡒࡩ࡯ࡧࡶࡡࠥ࠱ࠠ࡜ࡰࡲࡶࡲࡧ࡬ࡄࡱࡱࡸࡪࡴࡴ࡞ࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡀࠤࠬ৵")\l11l11l1Fuck_You_Anonymous (u"ࠩ࠱࡮ࡴ࡯࡮ࠡࠪ࡞ࡰ࡮ࡴࡥࠡࡨࡲࡶࠥࡲࡩ࡯ࡧࠣ࡭ࡳ࡛ࠦ࡭࡫ࡱࡩ࠳ࡸࡳࡵࡴ࡬ࡴࠥ࠮ࠩࠡࡨࡲࡶࠥࡲࡩ࡯ࡧࠣ࡭ࡳࠦࡣࡰࡰࡷࡩࡳࡺ࠮ࡴࡲ࡯࡭ࡹࠦࠨࠨ৶")\l11l11l1Fuck_You_Anonymous (u"ࠪ࠭ࡢࠦࡩࡧࠢ࡯࡭ࡳ࡫࡝ࠪࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡴࡳࡻ࠽ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡵࡣࡵ࡫ࡪࡺࡆࡪ࡮ࡨࡔࡷ࡫ࡎࡢ࡯ࡨࠤࡂࠦࡧࡦࡶࡒࡦ࡫ࡻࡳࡤࡣࡷࡩࡩࡔࡡ࡮ࡧࠣࠬࡴࡨࡦࡶࡵࡦࡥࡹ࡫ࡤࡘࡱࡵࡨࡑ࡯ࡳࡵ࠰࡬ࡲࡩ࡫ࡸࠡࠪࡶࡳࡺࡸࡣࡦࡈ࡬ࡰࡪࡖࡲࡦࡐࡤࡱࡪ࠯ࠬࠡࡵࡲࡹࡷࡩࡥࡇ࡫࡯ࡩࡕࡸࡥࡏࡣࡰࡩ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࡫ࡸࡤࡧࡳࡸ࠿ࠦࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡷࡥࡷ࡭ࡥࡵࡈ࡬ࡰࡪࡖࡲࡦࡐࡤࡱࡪࠦ࠽ࠡࡵࡲࡹࡷࡩࡥࡇ࡫࡯ࡩࡕࡸࡥࡏࡣࡰࡩࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡸࡦࡸࡧࡦࡶࡆ࡬ࡺࡴ࡫ࡴࠢࡀࠤࡹࡧࡲࡨࡧࡷࡖࡪࡲࡓࡶࡤࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽ࠳ࡹࡰ࡭࡫ࡷࠤ࠭࠭৷")/l111Fuck_You_Anonymous (u"ࠫ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࡬࡯ࡳࠢ࡬ࡲࡩ࡫ࡸࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠣࠬࡱ࡫࡮ࠡࠪࡷࡥࡷ࡭ࡥࡵࡅ࡫ࡹࡳࡱࡳࠪࠫ࠽ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡵࡴࡼ࠾ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡺࡡࡳࡩࡨࡸࡈ࡮ࡵ࡯࡭ࡶࠤࡠ࡯࡮ࡥࡧࡻࡡࠥࡃࠠࡨࡧࡷࡓࡧ࡬ࡵࡴࡥࡤࡸࡪࡪࡎࡢ࡯ࡨࠤ࠭ࡵࡢࡧࡷࡶࡧࡦࡺࡥࡥ࡙ࡲࡶࡩࡒࡩࡴࡶ࠱࡭ࡳࡪࡥࡹࠢࠫࡸࡦࡸࡧࡦࡶࡆ࡬ࡺࡴ࡫ࡴࠢ࡞࡭ࡳࡪࡥࡹ࡟ࠬ࠰ࠥࡺࡡࡳࡩࡨࡸࡈ࡮ࡵ࡯࡭ࡶࠤࡠ࡯࡮ࡥࡧࡻࡡ࠮ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡨࡼࡨ࡫ࡰࡵ࠼ࠣࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡴࡦࡹࡳࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡵࡣࡵ࡫ࡪࡺࡒࡦ࡮ࡖࡹࡧࡊࡩࡳࡧࡦࡸࡴࡸࡹࠡ࠿ࠣࠫ৸")/l111Fuck_You_Anonymous (u"ࠬ࠴ࡪࡰ࡫ࡱࠤ࠭ࡺࡡࡳࡩࡨࡸࡈ࡮ࡵ࡯࡭ࡶ࠭ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡹࡧࡲࡨࡧࡷࡗࡺࡨࡄࡪࡴࡨࡧࡹࡵࡲࡺࠢࡀࠤࠬ৹"){0}{1}l111Fuck_You_Anonymous (u"࠭࠮ࡧࡱࡵࡱࡦࡺࠠࠩࡶࡤࡶ࡬࡫ࡴࡓࡱࡲࡸࡉ࡯ࡲࡦࡥࡷࡳࡷࡿࠬࠡࡶࡤࡶ࡬࡫ࡴࡓࡧ࡯ࡗࡺࡨࡄࡪࡴࡨࡧࡹࡵࡲࡺࠫࠣ࠲ࡷࡹࡰ࡭࡫ࡷࠤ࠭࠭৺")/l111Fuck_You_Anonymous (u"ࠧ࠭ࠢ࠴࠭ࠥࡡ࠰࡞ࠏࠍࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡷࡥࡷ࡭ࡥࡵࡈ࡬ࡰࡪࠦ࠽ࠡࡥࡵࡩࡦࡺࡥࡇ࡫࡯ࡩࡕࡧࡴࡩࠢࠫࠫ৻"){0}/{1}.{2}l111Fuck_You_Anonymous (u"ࠨ࠰ࡩࡳࡷࡳࡡࡵࠢࠫࡸࡦࡸࡧࡦࡶࡖࡹࡧࡊࡩࡳࡧࡦࡸࡴࡸࡹ࠭ࠢࡷࡥࡷ࡭ࡥࡵࡈ࡬ࡰࡪࡖࡲࡦࡐࡤࡱࡪ࠲ࠠࡴࡱࡸࡶࡨ࡫ࡆࡪ࡮ࡨࡒࡦࡳࡥࡆࡺࡷࡩࡳࡹࡩࡰࡰࠬ࠰ࠥࡵࡰࡦࡰࠣࡁ࡚ࠥࡲࡶࡧࠬࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡸࡦࡸࡧࡦࡶࡉ࡭ࡱ࡫࠮ࡸࡴ࡬ࡸࡪࠦࠨࡤࡱࡱࡸࡪࡴࡴࠪࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡶࡤࡶ࡬࡫ࡴࡇ࡫࡯ࡩ࠳ࡩ࡬ࡰࡵࡨࠤ࠭࠯ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࡨࡰ࡮࡬ࠠ࡯ࡱࡷࠤࡸࡵࡵࡳࡥࡨࡊ࡮ࡲࡥࡏࡣࡰࡩࡊࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࡪࡰࠣࡷࡰ࡯ࡰࡇ࡫࡯ࡩࡓࡧ࡭ࡦࡇࡻࡸࡪࡴࡳࡪࡱࡱࡐ࡮ࡹࡴ࠻ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡶࡤࡶ࡬࡫ࡴࡔࡷࡥࡈ࡮ࡸࡥࡤࡶࡲࡶࡾࠦ࠽ࠡࠩৼ"){0}{1}l111Fuck_You_Anonymous (u"ࠩ࠱ࡪࡴࡸ࡭ࡢࡶࠣࠬࡹࡧࡲࡨࡧࡷࡖࡴࡵࡴࡅ࡫ࡵࡩࡨࡺ࡯ࡳࡻ࠯ࠤࡹࡧࡲࡨࡧࡷࡖࡪࡲࡓࡶࡤࡇ࡭ࡷ࡫ࡣࡵࡱࡵࡽ࠮ࠦ࠮ࡳࡵࡳࡰ࡮ࡺࠠࠩࠩ৽")/l111Fuck_You_Anonymous (u"ࠪ࠰ࠥ࠷ࠩࠡ࡝࠳ࡡࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡸࡦࡸࡧࡦࡶࡉ࡭ࡱ࡫ࡐࡢࡶ࡫ࠤࡂࠦࠧ৾"){0}/{1}l111Fuck_You_Anonymous (u"ࠫ࠳࡬࡯ࡳ࡯ࡤࡸࠥ࠮ࡴࡢࡴࡪࡩࡹ࡙ࡵࡣࡆ࡬ࡶࡪࡩࡴࡰࡴࡼ࠰ࠥࡹ࡯ࡶࡴࡦࡩࡋ࡯࡬ࡦࡐࡤࡱࡪ࠯ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡣࡳࡧࡤࡸࡪࡌࡩ࡭ࡧࡓࡥࡹ࡮ࠠࠩࡶࡤࡶ࡬࡫ࡴࡇ࡫࡯ࡩࡕࡧࡴࡩࠫࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡶ࡬ࡺࡺࡩ࡭࠰ࡦࡳࡵࡿࡦࡪ࡮ࡨࠤ࠭ࡹ࡯ࡶࡴࡦࡩࡋ࡯࡬ࡦࡒࡤࡸ࡭࠲ࠠࡵࡣࡵ࡫ࡪࡺࡆࡪ࡮ࡨࡔࡦࡺࡨࠪࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࡱࡴ࡬ࡲࡹࠦࠨࠨ৿")l1lllll1lFuck_You_Anonymous words: {0}'.format (len (l11ll1llFuck_You_Anonymous)))