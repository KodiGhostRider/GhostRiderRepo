# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys, time

addon_id='plugin.video.all_addons_stream_light'
Addon = xbmcaddon.Addon(addon_id)
Config = xbmcaddon.Addon('plugin.video.all_addons_stream_light')
Config.setSetting(id='auto-view', value='true')
time.sleep(5)
showedaad = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.all_addons_stream_light', 'showedaad'))
dialog       =  xbmcgui.Dialog()
localizedString = Addon.getLocalizedString 

def exoduset():
    Config = xbmcaddon.Addon(id='plugin.video.exodus')
    Config.setSetting(id='provider.movieflixter', value='false')
    Config.setSetting(id='provider.moviegross', value='false')
    Config.setSetting(id='provider.watchhd', value='false')	
    Config.setSetting(id='provider.einthusan', value='false')
    Config.setSetting(id='provider.torba', value='false')
    Config.setSetting(id='provider.pubfilm', value='false')
    Config.setSetting(id='provider.xmovies', value='false')		
    Config.setSetting(id='provider.projectfree', value='false')
    Config.setSetting(id='provider.moviegee', value='false')
    Config.setSetting(id='provider.moviexk', value='false')	
    Config.setSetting(id='provider.moviefree', value='false')

def spectoset():
    Config = xbmcaddon.Addon(id='plugin.video.specto')
    Config.setSetting(id='vidics', value='false')
    Config.setSetting(id='vidics_tv', value='false')
    Config.setSetting(id='xmovies', value='false')	
    Config.setSetting(id='pubfilm', value='false')
    Config.setSetting(id='pubfilm_tv', value='false')	
    Config.setSetting(id='playback_captcha_hosts', value='false')	

def exinfoset():
    Config = xbmcaddon.Addon(id='script.extendedinfo')
    Config.setSetting(id='LanguageID', value='he')

def zenset():
    Config = xbmcaddon.Addon(id='plugin.video.zen')
    Config.setSetting(id='provider.moviegee', value='false')
    Config.setSetting(id='provider.vidics', value='false')
    Config.setSetting(id='provider.afdah', value='false')
    Config.setSetting(id='provider.xmovies', value='false')	
    Config.setSetting(id='provider.watchfilm', value='false')	


def fona():
    choice = xbmcgui.Dialog().yesno(localizedString(32212).encode('utf-8'), localizedString(32213).encode('utf-8'), localizedString(32214).encode('utf-8'), nolabel=localizedString(32216).encode('utf-8'),yeslabel=localizedString(32215).encode('utf-8'))
    if choice == 0:
        sys.exit(1)
    elif choice == 1:
        pass

def repoinstall():
   if os.path.isfile(showedaad) == False:
    f = open(showedaad,"w+")
    f.write("")
    f.close()
    import reqwest
    reqwest.requests()
    reqwest.requestsen()
    time.sleep(5)
    xbmcgui.Dialog().notification("Senyor Wizard", localizedString(32259).encode('utf-8'))	
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.all_addons_stream_light/resources/art/try.py)')    

time.sleep(15)
repoinstall()	