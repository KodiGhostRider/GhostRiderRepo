# -*- coding: utf-8 -*-
# thanks to TheWiz Addon Installer....
# Thanks to Blazetamer, Eleazar Coding, Showgun, TheHighway, ....
import requests,shutil, json, sys, os, xbmcgui, time, xbmc, urllib, urllib2, re, zipfile ,xbmcaddon ,xbmcplugin, xbmcvfs
import addonsettings
from xml.dom import minidom


dialog = xbmcgui.Dialog()

ADDON_ID      = 'plugin.video.all_addons_stream_light'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_ID      = REAL_SETTINGS.getAddonInfo('id')
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ADDON_PATH    = (REAL_SETTINGS.getAddonInfo('path').decode('utf-8'))
ADDON_VERSION = REAL_SETTINGS.getAddonInfo('version')
ICON          = os.path.join(ADDON_PATH, 'icon.png')
FANART        = os.path.join(ADDON_PATH, 'fanart.jpg')

CONTENTS = ["unknown",
            "video",
            "audio",
            "image",	
            "executable"]
            
TYPES    = ["unknown",
            "xbmc.player.musicviz",
            "xbmc.pvrclient",
            "xbmc.gui.skin",
            "kodi.adsp",
            "kodi.inputstream",
            "kodi.peripheral",
            "xbmc.python.script",
            "xbmc.python.weather",
            "xbmc.subtitle.module",
            "xbmc.python.lyrics",
            "xbmc.metadata.scraper.albums",
            "xbmc.metadata.scraper.artists",
            "xbmc.metadata.scraper.movies",
            "xbmc.metadata.scraper.musicvideos",
            "xbmc.metadata.scraper.tvshows",
            "xbmc.ui.screensaver",
            "xbmc.python.pluginsource",
            "xbmc.addon.repository",
            "xbmc.webinterface",
            "xbmc.service",
            "xbmc.audioencoder",
            "kodi.context.item",
            "kodi.audiodecoder",
            "kodi.resource.images",
            "kodi.resource.language",
            "kodi.resource.uisounds",
            "xbmc.addon.video",
            "xbmc.addon.audio",
            "xbmc.addon.image",
            "xbmc.addon.executable",
            "xbmc.metadata.scraper.library",
            "xbmc.python.library",
            "xbmc.python.module",
            "kodi.game.controller"]

CONTENT_TYPES = ["xbmc.gui.skin","xbmc.subtitle.module","kodi.context.item", "kodi.resource.language","xbmc.addon.repository","xbmc.addon.skin","xbmc.addon.video","kodi.resource.uisounds","xbmc.addon.audio","xbmc.addon.image","xbmc.addon.executable","xbmc.service","xbmc.python.library","xbmc.python.module","xbmc.python.script"]
 
 

def set_Kodi_JSON(params):
    xbmc.executeJSONRPC('{"jsonrpc": "2.0", %s, "id": 1}' % params)
    
def set_Kodi_Enabled(plugin):
    set_Kodi_JSON('"method":"Addons.SetAddonEnabled","params":{"addonid":"%s","enabled":true}'%plugin)
        
def get_Kodi_JSON(params):
    return json.loads(unicode(xbmc.executeJSONRPC('{"jsonrpc": "2.0", %s, "id": 1}' % params), 'utf-8', errors='ignore'))
    
def get_Kodi_Disabled(type,content):
     return get_Kodi_JSON('"method":"Addons.GetAddons","params":{"type":"%s","content":"%s","enabled":false,"installed":true}'%(type,content))

def get_Kodi_Anabled():	 
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.all_addons_stream_light/skinAddon.py)')	 
	 
def aaa():
    percent       = 0
    count         = 0
    loop          = 0
    details       = []
    dlg           = xbmcgui.DialogProgress()
    dlg.create(ADDON_NAME)
    
    for content in CONTENTS:
        for type in CONTENT_TYPES:
            loop += 1
            if (dlg.iscanceled()):
                dlg.close()
                break
            percent = loop * 100 // len(CONTENT_TYPES)
            dlg.update(percent)
            details.append(get_Kodi_Disabled(type,content))
            
    for json_response in details:
        if json_response.has_key('result') and (json_response['result'] != None) and json_response['result'].has_key('addons'):
            count   = 0
            for item in json_response['result']['addons']:
                if (dlg.iscanceled()):
                    dlg.close()
                    break
                dlg.update((count * 100 // len(json_response['result']['addons'])),'Checking: %s'%item['type'],'Enabling: %s'%item['addonid'])
                set_Kodi_Enabled(item['addonid'])
                xbmc.sleep(200)
    dlg.update(100)
    dlg.close()

def upd():
    xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
    xbmc.executebuiltin("XBMC.UpdateAddonRepos()")

	
def addonsinstall():	
    AddonInstaller("script.exodus.artwork")
    AddonInstaller("script.specto.media")
    AddonInstaller("plugin.program.meta_search")
    AddonInstaller("script.exodus.metadata")
    AddonInstaller("plugin.video.youtube")
    AddonInstaller("plugin.program.senyor.movies.light.favourites")
    AddonInstaller("plugin.program.senyor.tvshow.light.favourites")
    AddonInstaller("plugin.program.senyor.livetv.light.favourites")
    AddonInstaller("plugin.program.senyortools")
    AddonInstaller("plugin.video.anarchitv")
    AddonInstaller("plugin.video.ccloudtv")
    AddonInstaller("plugin.video.filmon.simple")
    AddonInstaller("plugin.video.exodus")
    AddonInstaller("plugin.video.featherence.docu")
    AddonInstaller("plugin.video.featherence.kids")
    AddonInstaller("plugin.video.featherence.music")
    AddonInstaller("plugin.video.hotVOD.video")
    AddonInstaller("plugin.video.israelive")
    AddonInstaller("plugin.video.MakoTV")
    AddonInstaller("plugin.video.zen")	
    AddonInstaller("plugin.video.makoTV.video")
    AddonInstaller("plugin.video.reshet.ebs.video")
    AddonInstaller("plugin.video.specto")
    AddonInstaller("plugin.video.tenil")
    AddonInstaller("plugin.video.Vodil")
    AddonInstaller("plugin.video.wallaNew.video")
    AddonInstaller("plugin.video.phstreams")
    AddonInstaller("plugin.video.ukturk")
    AddonInstaller("plugin.video.one242415")
    AddonInstaller("repository.RoiD	")	
    #AddonInstaller("plugin.video.RoiD")
    AddonInstaller("plugin.video.sanctuary")
    #AddonInstaller("plugin.video.sdarot.tv")
    addonsettings.metalliqplayers()	
	
def AddonInstaller(id):
	global repo_addons
	if id in repo_addons:
		url = repo_addons[id]
		local_filename = url.split('/')[-1]
	else:
		print "*** {0}: ERROR: {1} don't exist in Repo".format(AddonName,id)
		return 0
	addonsfolder = xbmc.translatePath(os.path.join('special://','home','addons'))
	if os.path.isdir(os.path.join(addonsfolder,id)):
		print "*** {0}: Exist {1} in Kodi".format(AddonName,id)
		return 0
	packfolder = xbmc.translatePath(os.path.join('special://','home','addons','packages'))
	dp = xbmcgui.DialogProgress(); 
	dp.create("Senyor Wizard"," Download "+id,'','Please Wait')
	addon_zip = os.path.join(packfolder,local_filename)
	try: os.remove(addon_zip)
	except: pass
	print "*** {0}: Downloading {1}".format(AddonName,id)
	download_try=0
	while True:
		AddonDownload(url,addon_zip,dp)
		try:
			test_zip_file = zipfile.ZipFile(addon_zip)
			ret = test_zip_file.testzip()
			if ret is None:
				break
		except:pass
		download_try += 1
		xbmc.sleep(4000)
		if download_try>4:
			OKmsg("תקלה בהורדה",'לא ניתן להוריד את ההרחבה','לתמיכה חפשו אותנו בפייסבוק','Kodi Senyor')
			print "*** {0}: Error Downloading {1}".format(AddonName,id)
			return 1
	time.sleep(2)
	print "*** {0}: Extracting {1}".format(AddonName,local_filename)
	dp.update(0,"Extracting Zip {0}".format(id),"",'פורס קבצים')
	AddonExtract(addon_zip,addonsfolder,dp)
	try:
		depends = xbmc.translatePath(os.path.join(addonsfolder,id,'addon.xml')); 
		source = open(depends,mode='r'); line=source.read(); source.close();
		regex =ur'import addon="(.+?)"'
		addon_requires = re.findall(regex, line)
		for addon_require in addon_requires:
			if not 'xbmc.' in addon_require:
				dependspath = xbmc.translatePath(os.path.join('special://home/addons',addon_require))
				if not os.path.exists(dependspath): 
					AddonInstaller(addon_require)
	except:pass

def OKmsg(title, line1, line2="", line3=""):
	xbmcgui.Dialog().ok(title, line1, line2, line3)	
	
def AddonDownload(source, target,dp = None):
	if not dp:
		dp = xbmcgui.DialogProgress()
		dp.create("מצב...","בודק התקנה",' ', ' ')
	dp.update(0)
	r = requests.get(source, stream=True, timeout=10)
	try:
		total_size = r.headers['content-length'].strip()
		total_size = int(total_size)
	except:
		return
	bytes_so_far = 0

	with open(target, 'wb') as fp:
		try:
			for chunk in r.iter_content(chunk_size=(1024*8)):
				if chunk:
					bytes_so_far += len(chunk)
					percent = min((100*bytes_so_far/total_size), 100)
					dp.update(percent)

					fp.write(chunk)

					if dp.iscanceled():
						raise Exception("Canceled")
						fp.close();	r.close(); dp.close()
						return 0
		except:pass
	fp.close()
	r.close()
	return 1

def AddonExtract(_in, _out, dp):
    zin = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zin.infolist()))
    count  = 0

    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, _out)
    except Exception, e:
        print str(e)
        return False

    return True


	
def GetRepoInfo(repo):
	global repo_addons
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+id+"/"+id+"-"+version+".zip"

	return 1


def GetRepoInfob(repo):
	global repo_addons
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+"/repo/"+id+"/"+id+"-"+version+".zip"

	return 1

def GetRepoInfoc(repo):
	global repo_addons
	u1=urllib2.urlopen(repo+"addons.xml")
	dom=minidom.parse(u1)
	addons = dom.getElementsByTagName("addon")
	for addon in addons:
		id = addon.getAttribute("id")
		version = addon.getAttribute("version")
		repo_addons[id] = repo+"/Zips/"+id+"/"+id+"-"+version+".zip"

	return 1	
	
def prcolor():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])


    if version >= 15.0 and version <= 15.9:
		GetRepoInfo("https://raw.githubusercontent.com/Helly1206/_repo/jarvis/")
    if version >= 16.0 and version <= 16.9:
		GetRepoInfo("http://mirror.onet.pl/pub/mirrors/kodi/addons/jarvis/")
    if version >= 17.0 and version <= 17.9:
		GetRepoInfo("http://mirror.onet.pl/pub/mirrors/kodi/addons/krypton/")
		
def kodiveraddons():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])


    if version >= 15.0 and version <= 15.9:
		pass
    if version >= 16.0 and version <= 16.9:
		pass
    if version >= 17.0 and version <= 17.9:
		addonsinstall()
		time.sleep(2)
		xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
		xbmc.executebuiltin("XBMC.UpdateAddonRepos()")
		time.sleep(5)
		get_Kodi_Anabled()
		time.sleep(5)
		
	

global repo_addons, AddonName
Addon = xbmcaddon.Addon
AddonName = ("name")
repo_addons = {}


GetRepoInfo("http://repo.thewiz.info/")
AddonInstaller("repository.TheWiz")
GetRepoInfo("https://raw.githubusercontent.com/finalmakerr/featherence/master/")
AddonInstaller("repository.featherence")
GetRepoInfoc("https://raw.githubusercontent.com/kobiko3030/repository.kodisenyor/master/")
GetRepoInfob("https://raw.githubusercontent.com/kodil/kodil/master/")
prcolor()

AddonInstaller("repository.kodil")
AddonInstaller("repository.exodus")
AddonInstaller("repository.xbmc-israel")
AddonInstaller("repository.filmkodi.com")
upd()
kodiveraddons()
time.sleep(5)
xbmcgui.Dialog().notification("Senyor Wizard", "installation completed")


