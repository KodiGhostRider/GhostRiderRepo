'''
    Our Match Add-on
    Copyright (C) 2016 123456

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import xbmcplugin, xbmcgui, urllib, re, os, sys
import dom_parser2
import client
import kodi
art       = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ourmatch/resources/art', ''))

def main(name=None, iconimage=None):
    c = client.request('http://ourmatch.net')
    if not iconimage: iconimage = kodi.addonicon
    if name:
        r = dom_parser2.parse_dom(c, 'li', {'class': 'header'})
        r = [i for i in r if 'title="%s"' % name in i.content]
        r = dom_parser2.parse_dom(r, 'li', {'class': 'hover-tg'})
        r = dom_parser2.parse_dom(r, 'a')
        for i in r:
            addDir(i.content,i.attrs['href'],3,iconimage)
    else:
        r = dom_parser2.parse_dom(c, 'a', {'class': 'sub'})
        addDir('Most Recent','http://ourmatch.net/',3,art+'new.png')
        for i in r:
            addDir(i.attrs['title'],'none',2,art+i.attrs['title'].lower()+'.png')

def getMatches(url):
    c  = client.request(url)
    r = dom_parser2.parse_dom(c, 'div', {'class': 'vidthumb'})
    r = [(dom_parser2.parse_dom(i, 'span', {'class': 'time'}), \
          dom_parser2.parse_dom(i, 'a', req=['href','title']), \
          dom_parser2.parse_dom(i, 'img', req='src')) for i in r if i]
    r = [(re.sub('<.+?>', '', i[0][0].content), i[1][0].attrs['title'], i[1][0].attrs['href'], i[2][0].attrs['src']) for i in r]
    for i in r:
        addDir('%s - %s' % (i[0], i[1]), i[2], 4, i[3])   
    try:
        np = re.findall('''<link\s*rel=['"]next['"]\s*href=['"]([^'"]+)''', c)[0]
        addDir('Next Page -->', np, 3, art+'nextpage.png')
    except: pass

def getStreams(name,url,iconimage):
    link  = client.request(url)
    match = re.compile("{embed:'.+?<source src=(.+?)></video>', lang:'(.+?)', 'type':'(.+?)', quality:'(.+?)', source:'.+?'}").findall(link)
    streamable = re.compile("""{embed:'<iframe.+?src=[\'\"](.+?)(?:\?autoplay.+?)?[\'\"].+?lang:'(.+?)', 'type':'(.+?)', quality:'(.+?)'""").findall(link)
    for url,lang,type,quality in match:
        name = '[B]'+type+'[/B] ['+quality+' | '+lang+']'
        url = url.replace('"','')
        if not url.startswith('http'): url = 'https:' + url
        iconimage = iconimage
        addLink(name,url,1,iconimage)
    for url,lang,type,quality in streamable:
        name = '[B]'+type+'[/B] ['+quality+' | '+lang+']'
        url = url.replace('"','')
        if not url.startswith('http'): url = 'https:' + url
        iconimage = iconimage
        addLink(name,url,1,iconimage)
        
def play(name,url):
    import urlresolver
    if urlresolver.HostedMediaFile(url).valid_url(): 
        url = urlresolver.HostedMediaFile(url).resolve()
    else:
        link  = client.request(url)
        link  = link
        match = re.compile('<source src="(.+?)" type="video/mp4" class="mp4-source"/>').findall(link)
        for url in match:
            name = name
            url  = 'https:'+url
    stream_url = url
    liz = xbmcgui.ListItem(name, path=stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)        
        
def addLink(name,url,mode,iconimage):
    try: client.replaceHTMLCodes(name)
    except: pass
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name} )
    liz.setProperty('fanart_image', kodi.addonfanart)
    liz.setProperty("IsPlayable","true")
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def addDir(name,url,mode,iconimage):
    try: client.replaceHTMLCodes(name)
    except: pass
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name} )
    liz.setProperty('fanart_image', kodi.addonfanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
         
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                            param[splitparams[0]]=splitparams[1]
                            
    return param
        
params=get_params()
url=None
name=None
mode=None
iconimage=None
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

if mode==None or url==None or len(url)<1: main()
elif mode==1: play(name,url)
elif mode==2: main(name, iconimage)
elif mode==3: getMatches(url)
elif mode==4: getStreams(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))