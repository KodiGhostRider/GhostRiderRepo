'''
	Our Match Add-on
	Copyright (C) 2016 123456

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import urllib2
import re
import xbmcplugin
import xbmcgui
import os
import sys
import datetime
import string
import xbmcaddon

dataPath  = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.ourmatch'), '')
addonID   = xbmcaddon.Addon().getAddonInfo('id')
selfAddon = xbmcaddon.Addon(id=addonID)
fanart    = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ourmatch', 'fanart.jpg'))
art       = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ourmatch/resources/art', ''))
nextpage  = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ourmatch/resources/art', 'nextpage.png'))

def main():
	addDir('Most Recent','http://ourmatch.net/',2,art+'new.png')
	addDir('England','url',10,art+'england.png')
	addDir('Germany','url',7,art+'germany.png')
	addDir('Spain','url',5,art+'spain.png')
	addDir('Italy','url',6,art+'italy.png')
	addDir('France','url',8,art+'france.png')
	addDir('UEFA','url',9,art+'europe.png')
	
def getEngland():
	addDir('Premier League','http://ourmatch.net/videos/england/premier-league-highlights/',2,art+'england.png')
	addDir('Championship','http://ourmatch.net/videos/england/championship/',2,art+'england.png')
	addDir('FA Cup','http://ourmatch.net/videos/england/fa-cup-highlights/',2,art+'england.png')
	addDir('League Cup','http://ourmatch.net/videos/england/league-cup-highlights/',2,art+'england.png')
	addDir('Community Shield','http://ourmatch.net/videos/england/community-shield-highlights/',2,art+'england.png')
	
def getSpain():
	addDir('La Liga','http://ourmatch.net/videos/spain/la-liga-highlights/',2,art+'spain.png')
	addDir('Copa del Rey','http://ourmatch.net/videos/spain/copa-del-rey-highlights/',2,art+'spain.png')
	addDir('Super Cup','http://ourmatch.net/videos/spain/supercopa-de-espana-highlights/',2,art+'spain.png')
	
def getItaly():
	addDir('Serie A','http://ourmatch.net/videos/italy/serie-a-highlights/',2,art+'italy.png')
	addDir('Coppa Italia','http://ourmatch.net/videos/italy/coppa-italia-highlights/',2,art+'italy.png')
	addDir('Super Cup','http://ourmatch.net/videos/italy/supercoppa-italiana-highlights/',2,art+'italy.png')

def getGermany():
	addDir('Bundesliga','http://ourmatch.net/videos/germany/bundesliga-highlights/',2,art+'germany.png')
	addDir('DFB Pokal','http://ourmatch.net/videos/germany/dfb-pokal-highlights/',2,art+'germany.png')
	addDir('Supercup','http://ourmatch.net/videos/germany/dfl-supercup-highlights/',2,art+'germany.png')
	
def getFrance():
	addDir('Ligue 1','http://ourmatch.net/videos/france/ligue-1-highlights/',2,art+'france.png')
	addDir('Coupe de la Ligue','http://ourmatch.net/videos/france/coupe-de-la-ligue-highlights/',2,art+'france.png')
	addDir('Coupe de France','http://ourmatch.net/videos/france/coupe-de-france-highlights/',2,art+'france.png')
	addDir('Super Cup','http://ourmatch.net/videos/france/trophee-des-champions-highlights/',2,art+'france.png')

def getUEFA():
	addDir('UEFA Champions League','http://ourmatch.net/videos/europe/uefa-champions-league-highlights/',2,art+'europe.png')
	addDir('UEFA Europa League','http://ourmatch.net/videos/europe/uefa-europa-league-highlights/',2,art+'europe.png')
	addDir('UEFA Super Cup','http://ourmatch.net/videos/europe/uefa-super-cup-highlights/',2,art+'europe.png')
		
def getMatches(url):
	link  = open_url(url)
	link  = link
	match = re.compile('<span class="time"> (.+?)</span>\n                        </div>\n            \n            \n            \n		\n\n	<div class="thumb">\n\n		<a data-id=".+?" title="(.+?)" href="(.+?)">\n\n\n                                			<span class="overlay"></span>\n				<img src="(.+?)" alt=".+?" />').findall(link)
	next  = re.compile('<a class="nextpostslink" rel="next" href="(.+?)">').findall(link)
	for date,name,url,iconimage in match:
		date = date.replace('<br />','').replace('    ','')
		addDir('[B]'+date+':[/B] '+name,url,3,iconimage)
	for url in next:
		addDir('Next Page',url,2,nextpage)
		
def getStreams(url,iconimage):
	link  = open_url(url)
	link  = link
	match = re.compile("{embed:'.+?<source src=(.+?)></video>', lang:'(.+?)', 'type':'(.+?)', quality:'(.+?)', source:'.+?'}").findall(link)
	streamable = re.compile("{embed:'<iframe src=(.+?)?autoplay.+?', lang:'(.+?)', 'type':'(.+?)', quality:'(.+?)', source:'streamable.+?'}").findall(link)
	for url,lang,type,quality in match:
		name = '[B]'+type+'[/B] ['+quality+' | '+lang+']'
		url = url.replace('"','')
		iconimage = iconimage
		addLink(name,url,1,iconimage)
	for url,lang,type,quality in streamable:
		name = '[B]'+type+'[/B] ['+quality+' | '+lang+']'
		url = url.replace('"','')
		iconimage = iconimage
		addLink(name,url,4,iconimage)
		
def getStreamable(name,url):
	link  = open_url(url)
	link  = link
	match = re.compile('<source src="(.+?)" type="video/mp4" class="mp4-source"/>').findall(link)
	for url in match:
		name = name
		url  = 'https:'+url
		play(name,url)
		
def play(name,url):
		stream_url = url
		liz = xbmcgui.ListItem(name, path=stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
		
def open_url(url):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	link=cleanHex(link)
	response.close()
	return link
	
def cleanHex(text):
	def fixup(m):
		text = m.group(0)
		if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
		else: return unichr(int(text[2:-1])).encode('utf-8')
	try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
	except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))
		
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param
		
def addLink(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name} )
		liz.setProperty('fanart_image', fanart)
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name} )
		liz.setProperty('fanart_image', fanart)
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
			  
params=get_params()
url=None
name=None
mode=None
iconimage=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass


print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
		print ""
		main()

elif mode==1: play(name,url)
elif mode==2: getMatches(url)
elif mode==3: getStreams(url,iconimage)
elif mode==4: getStreamable(name,url)
elif mode==5: getSpain()
elif mode==6: getItaly()
elif mode==7: getGermany()
elif mode==8: getFrance()
elif mode==9: getUEFA()
elif mode==10: getEngland()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
