import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,base64,time,urlresolver,liveresolver
from urllib2 import urlopen

addon_id            = 'plugin.video.echocommunityplayer'
AddonTitle          = '[COLOR yellowgreen]ECHO Community Player[/COLOR]'
fanart              = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon                = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
dialog              = xbmcgui.Dialog()
dp                  = xbmcgui.DialogProgress()
F4M                 = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.f4mTester'))
BASEURL             = base64.b64decode(b'aHR0cDovL2VjaG9jb2Rlci5jb20v')
PARENTAL_FILE  = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/' + addon_id , 'controls.txt'))
TERMS          = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'disclaimer.txt'))
I_AGREE        = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/' + addon_id , 'agreed.txt'))
PARENTAL_FOLDER= xbmc.translatePath(os.path.join('special://home/userdata/addon_data/' + addon_id))

def GetMenu():

	if not os.path.exists(I_AGREE): 
		f = open(TERMS,mode='r'); msg = f.read(); f.close()
		TextBoxes("%s" % msg)
		choice = xbmcgui.Dialog().yesno(AddonTitle, '[COLOR white]Do you agree to the terms and conditions of this addon?[/COLOR]','',yeslabel='[COLOR lime]YES[/COLOR]',nolabel='[COLOR red]NO[/COLOR]')
		if choice == 1:
			if not os.path.exists(PARENTAL_FOLDER):
				os.makedirs(PARENTAL_FOLDER)
			open(I_AGREE, 'w')
		else:
			sys.exit(0)

	if not os.path.exists(PARENTAL_FOLDER):
		choice = xbmcgui.Dialog().yesno(AddonTitle, "[COLOR white]We can see that this is your first time using the addon. Would you like to enable the parental controls now?[/COLOR]","" ,yeslabel='[COLOR red]NO[/COLOR]',nolabel='[COLOR lime]YES[/COLOR]')
		if choice == 0:
			PARENTAL_CONTROLS_PIN()
		else:
			os.makedirs(PARENTAL_FOLDER)

	elif os.path.exists(PARENTAL_FILE):
		vq = _get_keyboard( heading="Please Enter Your Password" )
		if ( not vq ): 
			dialog.ok(AddonTitle,"Sorry, no password was entered.")
			sys.exit(0)
		pass_one = vq

		vers = open(PARENTAL_FILE, "r")
		regex = re.compile(r'<password>(.+?)</password>')
		for line in vers:
			file = regex.findall(line)
			for current_pin in file:
				password = base64.b64decode(current_pin)
				if not password == pass_one:
					if not current_pin == pass_one:
						dialog.ok(AddonTitle,"Sorry, the password you entered was incorrect.")
						sys.exit(0)

	addLink('[COLOR yellowgreen]SUBMIT A LINK/LIST [/COLOR][COLOR white](M3U, TS, M3U8, MP4, MKV, MP3 etc)[/COLOR]',BASEURL,3,icon,fanart,'')
	addLink('#########################################################################',BASEURL,999,icon,fanart,'')
	addLink("[COLOR yellowgreen]TWITTER SUPPORT: [/COLOR][COLOR white]@ECHOCODER[/COLOR]","url",999,icon,fanart,'')
	if not os.path.exists(PARENTAL_FILE):
		addDir("[COLOR yellowgreen]PARENTAL CONTROLS - [COLOR red]OFF[/COLOR][/COLOR]","url",11,icon,fanart,'')
	else:
		addDir("[COLOR yellowgreen]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/COLOR]","url",11,icon,fanart,'')

	addLink('#########################################################################',BASEURL,999,icon,fanart,'')
	addDir('[COLOR yellowgreen]VIEW ALL: [/COLOR][COLOR white]M3U LISTS[/COLOR]','m3u',4,icon,fanart,'')
	addDir('[COLOR yellowgreen]VIEW ALL: [/COLOR][COLOR white]DIRECT LINKS[/COLOR]','direct',4,icon,fanart,'')
	addLink('##################LATEST ADDED########################',BASEURL,999,icon,fanart,'')


	service_url = BASEURL + base64.b64decode(b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249cmVhZCZidWlsZD0=') + base64.b64encode('[COLOR orangered][B]List[/B][/COLOR]')
	f = urllib2.urlopen(service_url)
	data = f.read()
	f.close()

	i = 0
	display_list = get_parse(data)
	for item in display_list:
		if i < 10:
			name = item['name']
			url = item['review']
			date = item['date']
			
			title = '[COLOR dodgerblue]' + name + '[/COLOR] - [COLOR white]' + url + '[/COLOR] | [COLOR dodgerblue]' + date + '[/COLOR]' 
			
			addLink(title,url,1,icon,fanart,'')
			i = i + 1
	
	xbmc.executebuiltin('Container.SetViewMode(50)')

def GetContent(name,url,iconimage):

	checker = url

	if url == "m3u":
		addDir('[COLOR yellowgreen]VIEWING ALL M3U LISTS[/COLOR]',BASEURL,4,icon,fanart,'')
	else:
		addDir('[COLOR yellowgreen]VIEWING ALL DIRECT LINKS[/COLOR]',BASEURL,4,icon,fanart,'')
	addLink('#########################################################################',BASEURL,999,icon,fanart,'')

	service_url = BASEURL + base64.b64decode(b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249cmVhZCZidWlsZD0=') + base64.b64encode('[COLOR orangered][B]List[/B][/COLOR]')
	f = urllib2.urlopen(service_url)
	data = f.read()
	f.close()

	display_list = get_parse(data)
	for item in display_list:
		name = item['name']
		url = item['review']
		date = item['date']
		
		title = '[COLOR dodgerblue]' + name + '[/COLOR] - [COLOR white]' + url + '[/COLOR] | [COLOR dodgerblue]' + date + '[/COLOR]' 
		
		if checker == "m3u":
			if "m3u" in url:
				if not "m3u8" in url: 
					addLink(title,url,1,icon,fanart,'')
		else:
			if "m3u8" in url:
				addLink(title,url,1,icon,fanart,'')
			elif not "m3u" in url: 
				addLink(title,url,1,icon,fanart,'')
			
	xbmc.executebuiltin('Container.SetViewMode(50)')

def Find_Out(name,url,iconimage):

	name = name.split('-')[0]
	if 'm3u' in url:
		if not 'm3u8' in url:
			List_M3U8(url)
		else:
			Player(name,url,iconimage)
	else:
		Player(name,url,iconimage)

def List_M3U8(url):

    list = CREATE_M3U_LIST(url)

    for channel in list:
        name = GetEncodeString(channel["display_name"])
        url = GetEncodeString(channel["url"])
        url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
        ext = url.split('.')[-1]
        try:
            ext = ext.split('?')[0]
        except: pass
        try:
            ext = ext.split('%')[0]
        except: pass
        addLink('[COLOR yellowgreen]' + ext.upper() + '[/COLOR] - ' + name ,url, 2, icon, fanart,'')

def CREATE_M3U_LIST(url):

    if not 'http' in url:
        response=open(url).read()
    else:
		try:
			response = open_url(url)
		except: 
			dialog.ok(AddonTitle, "There was an error connecting to the url. Please try another.")
			quit()
    response = response.replace('#AAASTREAM:','#A:')
    response = response.replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name, "url": url}
        li.append(item_data)
    list = []
    for channel in li:
        item_data = {"display_name": channel["display_name"], "url": channel["url"]}
        matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        list.append(item_data)
	
    return list

def Playist_M3U8(name,url,iconimage):

    dp.create(AddonTitle, "Generating M3U Playlist.", "Please wait...")
    dp.update(0)
    list = CREATE_M3U_LIST(url)

    playlist = xbmc.PlayList(1)
    playlist.clear()

    for channel in list:
        name = GetEncodeString(channel["display_name"])
        url = GetEncodeString(channel["url"])
        url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
        if not 'f4m'in url:
            if '.m3u8'in url:
                url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url+'&amp;iconImage='+icon	
                liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": name } )
                playlist.add(url,liz)
            elif '.ts'in url:
                url = url.replace('.ts','.m3u8')
                url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url+'&amp;iconImage='+icon	
                liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": name } )
                playlist.add(url,liz)
            elif '.mpegts'in url:
                url = url.replace('.mpegts','.m3u8')
                url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url+'&amp;iconImage='+icon	
                liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage)
                liz.setInfo( type="Video", infoLabels={ "Title": name } )
                playlist.add(url,liz)

    dp.close()
    xbmc.Player().play(playlist, liz, False)
    #quit()

def CREATE_M3U_PLAYLIST(url):

    if not 'http' in url:
        response=open(url).read()
    else:
        response = open_url(url)
    response = response.replace('#AAASTREAM:','#A:')
    response = response.replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name, "url": url}
        li.append(item_data)
    list = []
    for channel in li:
        item_data = {"display_name": channel["display_name"], "url": channel["url"]}
        matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        list.append(item_data)
	
    return list

def GetEncodeString(str):
	try:
		import chardet
		str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
	except:
		try:
			str = str.encode("utf-8")
		except:
			pass
	return str

def Submit_List():

	build_name = "[COLOR orangered][B]List[/B][/COLOR]"
	review_text =''
	name_text = ''
	review_ip = urlopen('http://ip.42.pl/raw').read()

	try:
		Review_keyboard = xbmc.Keyboard(review_text, 'Enter Your Link/List URL')
		Review_keyboard.doModal()

		if Review_keyboard.isConfirmed():
			review_text = Review_keyboard.getText()
			Review_Name = xbmc.Keyboard(name_text, 'Enter an identifier for the link')
			Review_Name.doModal()
	
		if Review_Name.isConfirmed():
			name_text = Review_Name.getText()
			
		if 	review_text == "":
			dialog.ok(AddonTitle, "[COLOR white]Sorry not a valid entry![/COLOR]", "[COLOR white]Please try again.[/COLOR]", '')
			sys.exit(1)

		if 	name_text == "":
			dialog.ok(AddonTitle, "[COLOR white]Sorry not a valid entry![/COLOR]", "[COLOR white]Please try again.[/COLOR]", '')
			sys.exit(1)

		if not 'http' in review_text:
			dialog.ok(AddonTitle, "[COLOR white]Sorry not a valid entry![/COLOR]", "[COLOR white]Please include http:// or https:// at the start of the URL.[/COLOR]", '')
			sys.exit(1)

		service_url = BASEURL + base64.b64decode(b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249YWRkJnRleHQ9') + base64.b64encode(review_text) + base64.b64decode(b'Jm5hbWU9') + base64.b64encode(name_text) + base64.b64decode(b'JmlwPQ==') + base64.b64encode(review_ip) + base64.b64decode(b'JmJ1aWxkPQ==') + base64.b64encode(build_name)
		body =urllib2.urlopen(service_url).read()
	except: sys.exit(1)

	dialog.ok(AddonTitle, "[COLOR white]Thank you for adding to the list. You have done your bit for the community![/COLOR]")

	xbmc.executebuiltin("Container.Refresh")

def find_single_match(text,pattern):

    result = ""
    try:    
        single = re.findall(pattern,text, flags=re.DOTALL)
        result = single[0]
    except:
        result = ""

    return result

def get_parse(data):

    patron = "<item>(.*?)</item>"
    reviews = re.findall(patron,data,re.DOTALL)

    items = []
    for review in reviews:
        item = {}
        item["name"] = find_single_match(review,"<name>([^<]+)</name>")
        item["date"] = find_single_match(review,"<date>([^<]+)</date>")
        item["review"] = find_single_match(review,"<review>([^<]+)</review>")

        if item["name"]!="":
            items.append(item)

    return items

def PARENTAL_CONTROLS():

	found = 0
	if not os.path.exists(PARENTAL_FILE):
		found = 1
		addLink("[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]","url",999,icon,fanart,'')
		addLink("[COLOR white]Setup Parental Password[/COLOR]","url",12,icon,fanart,'')
	else:
		vers = open(PARENTAL_FILE, "r")
		regex = re.compile(r'<password>(.+?)</password>')
		for line in vers:
			file = regex.findall(line)
			for current_pin in file:
				password = base64.b64decode(current_pin)
				found = 1
				addLink("[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]","url",999,icon,fanart,'')
				addLink("[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str(password) + "[/COLOR]","url",999,icon,fanart,'')
				addLink("[COLOR lime]Change Password[/COLOR]","url",12,icon,fanart,'')
				addLink("[COLOR red]Disable Password[/COLOR]","url",13,icon,fanart,'')

	if found == 0:
		addLink("[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]","url",999,icon,fanart,'')
		addLink("[COLOR white]Setup Parental Password[/COLOR]","url",12,icon,fanart,'')

def PARENTAL_CONTROLS_PIN():

	vq = _get_keyboard( heading="Please Set Password" )
	if ( not vq ):
		dialog.ok(AddonTitle,"Sorry, no password was entered.")
		sys.exit(0)
	pass_one = vq

	vq = _get_keyboard( heading="Please Confirm Your Password" )
	if ( not vq ):
		dialog.ok(AddonTitle,"Sorry, no password was entered.")
		sys.exit(0)
	pass_two = vq
		
	if not os.path.exists(PARENTAL_FILE):
		if not os.path.exists(PARENTAL_FOLDER):
			os.makedirs(PARENTAL_FOLDER)
		open(PARENTAL_FILE, 'w')

		if pass_one == pass_two:
			writeme = base64.b64encode(pass_one)
			f = open(PARENTAL_FILE,'w')
			f.write('<password>'+str(writeme)+'</password>')
			f.close()
			dialog.ok(AddonTitle,'Your password has been set and parental controls have been enabled.')
			xbmc.executebuiltin("Container.Refresh")
		else:
			dialog.ok(AddonTitle,'The passwords do not match, please try again.')
			sys.exit(0)
	else:
		os.remove(PARENTAL_FILE)
		
		if pass_one == pass_two:
			writeme = base64.b64encode(pass_one)
			f = open(PARENTAL_FILE,'w')
			f.write('<password>'+str(writeme)+'</password>')
			f.close()
			dialog.ok(AddonTitle,'Your password has been set and parental controls have been enabled.')
			xbmc.executebuiltin("Container.Refresh")
		else:
			dialog.ok(AddonTitle,'The passwords do not match, please try again.')
			sys.exit(0)

def PARENTAL_CONTROLS_OFF():

	try:
		os.remove(PARENTAL_FILE)
		dialog.ok(AddonTitle,'Parental controls have been disabled.')
		xbmc.executebuiltin("Container.Refresh")
	except:
		dialog.ok(AddonTitle,'There was an error disabling the parental controls.')
		xbmc.executebuiltin("Container.Refresh")

def TextBoxes(announce):
	class TextBox():
		WINDOW=10147
		CONTROL_LABEL=1
		CONTROL_TEXTBOX=5
		def __init__(self,*args,**kwargs):
			xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
			self.win=xbmcgui.Window(self.WINDOW) # get window
			xbmc.sleep(500) # give window time to initialize
			self.setControls()
		def setControls(self):
			self.win.getControl(self.CONTROL_LABEL).setLabel('ECHO Community Player') # set heading
			try: f=open(announce); text=f.read()
			except: text=announce
			self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
			return
	TextBox()
	while xbmc.getCondVisibility('Window.IsVisible(10147)'):
		time.sleep(.5)

def _get_keyboard( default="", heading="", hidden=False ):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard( default, heading, hidden )
    keyboard.doModal()
    if ( keyboard.isConfirmed() ):
        return unicode( keyboard.getText(), "utf-8" )
    return default

def Player(name,url,iconimage):

	dp.create(AddonTitle, "Opening.......", "Please Wait...")

	if not 'f4m'in url:
		if '.ts'in url:
			url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name='+name+'&amp;url='+url+'&amp;iconImage='+icon	
		elif '.mpegts'in url:
			url = url.replace('.mpegts','.m3u8')
			url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url+'&amp;iconImage='+icon	

	if "plugin://" in url:
		if not os.path.exists(F4M):
			dialog.ok('[COLOR red]F4M TESTER NOT INSTALLED![/COLOR]', "This link requires F4M Tester be installed. Please install F4M from the Shani Repo at http://fusion.tvaddons.ag")
			quit()

	if urlresolver.HostedMediaFile(url).valid_url(): 
		stream_url = urlresolver.HostedMediaFile(url).resolve()
		liz = xbmcgui.ListItem(url,iconImage=icon, thumbnailImage=icon)
		liz.setPath(stream_url)
		dp.close()
		xbmc.Player ().play(stream_url, liz, False)
	elif liveresolver.isValid(url)==True: 
		stream_url=liveresolver.resolve(url)
		liz = xbmcgui.ListItem(url,iconImage=icon, thumbnailImage=icon)
		liz.setPath(stream_url)
		dp.close()
		xbmc.Player ().play(stream_url, liz, False)
	else:
		if 'http' in url:
			url = url + '|User-Agent=Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30'
		liz = xbmcgui.ListItem(url, iconImage=icon, thumbnailImage=icon)
		dp.close()
		xbmc.Player ().play(url, liz, False)

def open_url(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def addLink(name, url, mode, iconimage, fanart, description=''):

	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addDir(name,url,mode,iconimage,fanart,description=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanart=urllib.unquote_plus(params["fanart"])
except: pass
 
if mode==None or url==None or len(url)<1: GetMenu()
elif mode==1:Find_Out(name,url,iconimage)
elif mode==2:Player(name,url,iconimage)
elif mode==3:Submit_List()
elif mode==4:GetContent(name,url,iconimage)
elif mode==11: PARENTAL_CONTROLS()
elif mode==12: PARENTAL_CONTROLS_PIN()
elif mode==13: PARENTAL_CONTROLS_OFF()
elif mode==50: Playist_M3U8(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))