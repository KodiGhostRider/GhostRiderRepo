# -*- coding: utf-8 -*-

import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys, json
import urllib, zipfile
import reqwest

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
ADDON=xbmcaddon.Addon(id='plugin.program.senyorwizard')
addon_id='plugin.program.senyorwizard'
VERSION = "2.1.4"
PATH = "senyor wizard"            
xbmc.executeJSONRPC(jsonSetFont)
 
reqwest.requests()
reqwest.requestsen() 
 
 
def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True
 
def CATEGORIES():
    addDir('קודי בסיסי מוגדר','קודי בסיסי מוגדר',4,'http://i141.photobucket.com/albums/r48/kobiko3030/small_zpsl9qtelze.png','http://i141.photobucket.com/albums/r48/kobiko3030/big_zps0kufwcpv.png')
    addDir('פדרנס בילד (מומלץ)','פדרנס בילד',2,'http://i141.photobucket.com/albums/r48/kobiko3030/1_zpssphfv1gm.png','http://i141.photobucket.com/albums/r48/kobiko3030/7_zpsesvoxbx7.png')
    addDir('פנומנל בילד','פנומנל בילד',3,'http://i141.photobucket.com/albums/r48/kobiko3030/small_zpsknkdope7.jpg','http://i141.photobucket.com/albums/r48/kobiko3030/big_zpsm83b2orl.jpg')
    addDir('סינמה בילד','סינמה בילד',5,'http://i141.photobucket.com/albums/r48/kobiko3030/1_zpstj6qbvle.png','http://i141.photobucket.com/albums/r48/kobiko3030/1_zps8kesupgo.png')

	
def metasearch(url):
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok  		

def featherencebuild():	
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyorwizard/resources/img/kill.py)')

def phenomenalbuild():	
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyorwizard/resources/img/killph.py)')	
	
def basicbuild():	
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyorwizard/resources/img/killbasic.py)')	
	
def cinemabuild():	
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyorwizard/resources/img/killcin.py)')	
			
		
def addDir(name,url,mode,iconimage,fanart):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def kodisenyor():
	if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.kodisenyor')):
		return
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/newwizard/addons/repository.kodi-senyor.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
	update()	
	try:
		os.remove(packageFile)	               		
	except:
		pass
		
	
def update():
    if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.kodisenyor')):		
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")				
		
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None



try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
		kodisenyor()
		CATEGORIES()
       
elif mode==1:
        metasearch(url)
		
elif mode==2:
        featherencebuild()

elif mode==3:
        phenomenalbuild()

elif mode==4:
        basicbuild()

elif mode==5:
        cinemabuild()		
        
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))

