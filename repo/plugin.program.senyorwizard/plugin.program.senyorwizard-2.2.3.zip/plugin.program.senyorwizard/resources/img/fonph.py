# -*- coding: utf-8 -*-
import json
import xbmc, xbmcgui, xbmcaddon
import time
dialog = xbmcgui.Dialog()


jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.thewiz"},"id":1}'
jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.thewiz"},"id":1}'
jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.phenomenal"}, "id":1}'

xbmc.executeJSONRPC(jsonSetsub)
xbmc.executeJSONRPC(jsonSetFont)
xbmc.executeJSONRPC(jsonSetqewr)
xbmc.executeJSONRPC(jsonSetlan)
xbmc.executeJSONRPC(jsonSettorec)
xbmc.executeJSONRPC(jsonSettorectv)
xbmc.executeJSONRPC(jsonSethe)
xbmc.executeJSONRPC(jsonSethebsub)
xbmc.executebuiltin('XBMC.RefreshRSS')        
dialog.ok('senyor wizard ','תהליך ההתקנה עומד להסתיים','לחצו אישור ותתבקשו להחליף סקין','החליפו סקין לסיום ההתקנה')
xbmc.executeJSONRPC(jsonSetskin)
#time.sleep(15)
#xbmc.executebuiltin('XBMC.ReloadSkin()') 
time.sleep(30)
xbmc.executebuiltin('UpdateLibrary(video)') 



