# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True

def cinemakreptonyz():

	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/addons/xonfluence-kreptonyz/skin.xonfluence.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isrg.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass				

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")
	
def cinemakreptonyzkrypton():

	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/addons/xonfluence-kreptonyz/skin.xonfluencekrypton/skin.xonfluence.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isrg.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass				

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")	
	
def cinemakryptonuserdata():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/cinema_userdata/cinema17_userdata/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	
	
def pvropenelec():

	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/pvr/openelec/pvr.iptvsimple.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass				

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")

def pvrolibraelec():

	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/pvr/libraelec/pvr.iptvsimple.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
	packageFile = os.path.join(addonsDir, 'packages', 'isrg.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass				

	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos")		
	
def photos():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/newwizard/photos.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def isreliveuser():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/userdata_general/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			
			
def pheomenalphotos():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/media/phenomenal_media/skinphotos.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			
			


def feahtherenceuserdata():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/featherence_userdata/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def lastset():
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'pvr.iptvsimple')
   if '"enabled":true' in query:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s","enabled":false}}' % 'pvr.iptvsimple')
   else:
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"%s", "enabled":true}}' % 'pvr.iptvsimple')			
			
		
def feahtherencemedia():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/media/featherence_media/media.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def wizwall():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/wiz_wall_data/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			

def cinema_userdata():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/cinema_userdata/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass				
		
def cinema_photos():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/media/cinema_media/photos.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
		
def addondata():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/newwizard/addondata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrc.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
					

def basicaddondata():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/basic_kodi/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass
		
def Exodus_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/addons_auto_settings/exodus_settings.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	
def Salts_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/salts_auto-settings/salts_auto-settings.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	
def Meta_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/metatools/metatools-1.0.0.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			

def Specto_Settings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/addons_auto_settings/specto_settings.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
def PvrSettings():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/pvranarchitv.senyortools/pvranarchitv.senyortools.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			

def heblan():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/newwizard/gui/guiheb/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 	
	
def englishlan():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/transletion_cinema_build/english_translation.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 

def phenomenaluserdata():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/wizard/userdata/phenomenal_userdata/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
	
def basicbuild():
		
	url = "https://dl.orangedox.com/bmV8RKifXmkLfWU9vi?dl=1"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	
		
def basickryptonbuild():
		
	url = "https://dl.orangedox.com/tUbgGU9cnZWntHLbdF?dl=1"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			

def phenomenalbuid():
		
	url = "https://dl.orangedox.com/GMBONbIacbGwvFLdlC?dl=1"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def featherencebuild():
		
	url = "https://dl.orangedox.com/Q9kf4WXY6zFAnhuC9H?dl=1"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def cinemabuild():
		
	url = "https://dl.orangedox.com/kSGaqCvQQZRj4IFSsx?dl=1"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	

def cinemabuildkrypton():
		
	url = "https://dl.orangedox.com/CEuwrEnd5GWSuURguA?dl=1"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isrb.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass			
	
def rulan():
		
	url = "https://github.com/kobiko3030/senyor-repo/blob/master/addons_senyor_tools/transletion_cinema_build/rutranslation.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isr.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass		
			
	xbmc.executebuiltin("UpdateLocalAddons")
	xbmc.executebuiltin("UpdateAddonRepos") 	