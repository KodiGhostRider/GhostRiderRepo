service.subtitles.subcenter.org
==================

subcenter subtitle service for KODI. 
subcenter subtitles plugin
