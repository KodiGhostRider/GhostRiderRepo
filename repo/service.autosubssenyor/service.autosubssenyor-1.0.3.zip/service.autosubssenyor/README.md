service.autosubs
===============

Auto trigger XBMC Subtitle download if no subtitle (language) is found for a Movie/TV Show.<br>

Configuration options:
- Exclude media paths
- Exclude certain words
- Only trigger for specific language
