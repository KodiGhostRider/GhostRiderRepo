# plugin.program.simple.favourites

Simple Favourites
