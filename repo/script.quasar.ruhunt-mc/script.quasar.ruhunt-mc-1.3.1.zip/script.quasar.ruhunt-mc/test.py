# coding: utf-8
__author__ = 'mancuniancol'

data = '''

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Марсианин бесплатно скачать - 88 торрентов</title>
<link rel="stylesheet" type="text/css" href="/960_main_style.css" />
<link rel="alternate" type="application/rss+xml" title="Ruhunt - Марсианин" href="http://ruhunt.org/feed?q=%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD" />
<link rel="canonical" href="http://ruhunt.org/search?q=%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD&tag=video" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
</head>
<body>
<div id="appbar" style="font: 12px Verdana, Arial, Helvetica, sans-serif;text-align:center;width:auto;border:0;background:#FFFBBB;box-shadow:0 0 8px #CCCCCC;padding:15px 11px 15px 11px;margin:0px 0px 26px 0px"><a href="/ruhunt.btsearch">Добавить поиск в &#x03BC;Torrent</a><script type="text/javascript">if (window.external && ("AddSearchProvider" in window.external)) document.write(' &bull; <a href="javascript:window.external.AddSearchProvider(\'http://ruhunt.org/opensearch.xml\');">Поисковой плагин для браузера</a>');</script><span id="bmc" bmctext="Добавить в избранное" bmctitle="! Торрент поисковик - Ruhunt.org" bmcurl="http://ruhunt.org/"></span> <input type="button" value=" x " onclick="document.getElementById('appbar').style.display='none';var cdate=new Date();cdate.setTime(cdate.getTime()+1000*60*60*24*7);document.cookie='appbar=off;expires='+cdate.toGMTString()+';path=/;';" style="width:24px;height:24px;display:inline-block;float:right;margin-top:-3px;cursor:pointer;border:1px solid #CCCCCC;"></div><a name='top'></a>
<div class='container_12 clearfix'><div class='grid_12 rounded_bottom sepH_c tac' style='padding:15px 0px 15px;background:#EEE;'><a href='favorite'>Избранное</a> &bull; <a href='top'>ТОП</a> &bull; <a href='category'>Категории</a> &bull; <a href='profile'>Профиль</a></div><div class="grid_12 rounded sepH_c" style="padding:15px 0px 15px;background:#f6ffe9;">
	<form action="http://ruhunt.org/search" method="get" name="f">
	<div class="grid_10">
		<input type="text" maxlength="120" name="q" id='search' style='width:100%;' autocomplete="off" value="Марсианин" />
		<input type='hidden' name='i' value='s' />
	</div>
	<div class="grid_1">
		<button class="myButton">Поиск</button>
	</div>
	</form>
</div>
<div id='load'><div class='rounded_top grid_12' style='padding:8px 0 8px 0;background:#EEE;'><div class='grid_5'><h1>1&#8212;25 из 88</h1></div>
<div class="tar" style="padding:5px 3px">
<span class="sepV_a">
<select name='tag' id='tag' style='width:120px' size='1' onchange='disp_confirm(this)'><option value='all' >Категории</option><option value='video' selected='selected'>Видео ( 88 )</option><option value='audio' >Музыка ( 1 )</option><option value='other' >Другое ( 5 )</option></select>&nbsp;&nbsp;<select name='tracker' id='tracker' style='width:160px' size='1' onchange='disp_confirm(this)'><option value='0' selected='selected'>Трекеры</option><option value='11' >bigfangroup.org ( 19 )</option><option value='6' >free-torrents.org ( 3 )</option><option value='7' >opensharing.org ( 1 )</option><option value='1' >rutor.org ( 64 )</option><option value='10' >torrentino.com ( 1 )</option></select>&nbsp;&nbsp;<select name='sort' id='sort' style='width:140px' size='1' onchange='disp_confirm(this)'><option value='date_desc' >&#9660; Время</option><option value='date_asc' >&#9650; Время</option><option value='size_desc' >&#9660; Размер</option><option value='size_asc' >&#9650; Размер</option><option value='peers_desc' selected='selected'>&#9660; Пиры</option><option value='peers_asc' >&#9650; Пиры</option></select>&nbsp;&nbsp;<a href='http://ruhunt.org/feed?q=%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD' class='sepV_a'><img src='/rss.png' alt='Ruhunt - Марсианин' border='0' align='absmiddle' /></a>
<a href='http://ruhunt.org/favorite?tag=1&q=%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD' title='Добавить в избранное'><img src='/favorite.png' alt='Добавить в избранное' border='0' align='absmiddle' /></a>
</span>
</div>
</div>
<div class='grid_12'><table width='100%' border='0' cellspacing='0' cellpadding='8' id='torrents'><tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:6771f8ebccc837b1320088a90e402e34ba4d0a69&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%28%D0%A0%D0%B8%D0%B4%D0%BB%D0%B8+%D0%A1%D0%BA%D0%BE%D1%82%D1%82%29+%5B2015+%D0%B3.%2C+%D1%84%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0%2C+%D0%BF%D1%80%D0%B8%D0%BA%D0%BB%D1%8E%D1%87%D0%B5%D0%BD%D0%B8%D1%8F%2C+CAMRip%5D&tr.1=http://retracker.local/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/6771f8ebccc837b1320088a90e402e34ba4d0a69' title="Марсианин / The Martian (Ридли Скотт) [2015 г., фантастика, приключения, CAMRip]"><b>Марсианин</b> / The Martian (Ридли Скотт) [2015 г., фантастика, приключения, CAMRip]</a><br /><span class='gray'>Кинематограф » Новинки » LowQuality Rips</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 месяца назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >1.37 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>10463</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>1402</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:2a66dd9bc668b02a8c7366fa786284cae56983d3&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+HDRip+%D0%BE%D1%82+Scarabey+%7C+iTunes&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/2a66dd9bc668b02a8c7366fa786284cae56983d3' title="Марсианин / The Martian (2015) HDRip от Scarabey | iTunes"><b>Марсианин</b> / The Martian (2015) HDRip от Scarabey | iTunes</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >1 месяц назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >1.45 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>2633</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>547</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:80aebb87d7f2718763774cbdea093db63db5fdfd&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+HDRip+%D0%BE%D1%82+Scarabey+%7C+%D0%A7%D0%B8%D1%81%D1%82%D1%8B%D0%B9+%D0%B7%D0%B2%D1%83%D0%BA&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/80aebb87d7f2718763774cbdea093db63db5fdfd' title="Марсианин / The Martian (2015) HDRip от Scarabey | Чистый звук"><b>Марсианин</b> / The Martian (2015) HDRip от Scarabey | Чистый звук</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >1 месяц назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >1.45 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>1755</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>210</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:511d3242b96123467a004f52fcad7f3688493ab0&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+720p+%7C+60+fps&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/511d3242b96123467a004f52fcad7f3688493ab0' title="Марсианин / The Martian (2015) BDRip 720p | 60 fps"><b>Марсианин</b> / The Martian (2015) BDRip 720p | 60 fps</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >3 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >5.98 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>866</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>799</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:645ff285f5632fa45c8767e251b599de897b6051&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+HDRip+%D0%BE%D1%82+Scarabey+%7C+iTunes&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/645ff285f5632fa45c8767e251b599de897b6051' title="Марсианин / The Martian (2015) HDRip от Scarabey | iTunes"><b>Марсианин</b> / The Martian (2015) HDRip от Scarabey | iTunes</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >1 месяц назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.18 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>1296</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>291</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:51b9cbe1258431db5be723197d97a41367a10ca6&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+TS&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/51b9cbe1258431db5be723197d97a41367a10ca6' title="Марсианин / The Martian (2015) TS"><b>Марсианин</b> / The Martian (2015) TS</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >2 месяца назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >1.37 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>1303</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>58</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:324af70acc6d284344efde79db892246eb515106&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+WEBRip+1080p+%7C+%D0%A2%D1%80%D0%B5%D0%B9%D0%BB%D0%B5%D1%80&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/324af70acc6d284344efde79db892246eb515106' title="Марсианин / The Martian (2015) WEBRip 1080p | Трейлер"><b>Марсианин</b> / The Martian (2015) WEBRip 1080p | Трейлер</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >7 месяцев назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >68 MB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>843</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>289</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:bd337f4446b1d0152a053119ccad898296abc6ca&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+TS&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/bd337f4446b1d0152a053119ccad898296abc6ca' title="Марсианин / The Martian (2015) TS"><b>Марсианин</b> / The Martian (2015) TS</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >2 месяца назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.06 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>1056</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>25</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:f34215e8317fccf729e7cc7b22c64bcd5302b2d4&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+HDRip+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/f34215e8317fccf729e7cc7b22c64bcd5302b2d4' title="Марсианин / The Martian (2015) HDRip | Лицензия"><b>Марсианин</b> / The Martian (2015) HDRip | Лицензия</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.18 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>532</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>318</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:ff4fd10a95a959c1f07d744e31c785a966b17c40&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+4K+DCPRip+%7C+%D0%A2%D1%80%D0%B5%D0%B9%D0%BB%D0%B5%D1%80&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/ff4fd10a95a959c1f07d744e31c785a966b17c40' title="Марсианин / The Martian (2015) 4K DCPRip | Трейлер"><b>Марсианин</b> / The Martian (2015) 4K DCPRip | Трейлер</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >7 месяцев назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >1.09 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>66</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>657</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:96e2f07fe199b8608f69396c51d42e1dd1eb6ee5&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+1080p+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/96e2f07fe199b8608f69396c51d42e1dd1eb6ee5' title="Марсианин / The Martian (2015) BDRip 1080p | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip 1080p | Лицензия</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >17.3 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>4</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>571</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:94311dcf97565e7bfe8363f6c491242850469013&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+720p+%D0%BE%D1%82+Scarabey+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/94311dcf97565e7bfe8363f6c491242850469013' title="Марсианин / The Martian (2015) BDRip 720p от Scarabey | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip 720p от Scarabey | Лицензия</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >5.23 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>352</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>139</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:60a5f25fa6ce1e78ab0298ca96cc645abf9b8215&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+%7C+D+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/60a5f25fa6ce1e78ab0298ca96cc645abf9b8215' title="Марсианин / The Martian (2015) BDRip | D | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip | D | Лицензия</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.19 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>375</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>82</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:1802c2774c55bfb847f00045d110f4c620be056f&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+HDRip+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/1802c2774c55bfb847f00045d110f4c620be056f' title="Марсианин / The Martian (2015) HDRip | Лицензия"><b>Марсианин</b> / The Martian (2015) HDRip | Лицензия</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >1.47 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>273</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>167</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:b45ee43d65bf2f9d865fb4bd5794612f03367cb1&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/b45ee43d65bf2f9d865fb4bd5794612f03367cb1' title="Марсианин / The Martian (2015) BDRip | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip | Лицензия</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.9 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>208</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>166</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:f595e65d6f85c23c573939d1a0bb77147ae03507&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+1080p+%7C+3D+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/f595e65d6f85c23c573939d1a0bb77147ae03507' title="Марсианин / The Martian (2015) BDRip 1080p | 3D | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip 1080p | 3D | Лицензия</a><br /><span class='gray'>3 D</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >14.02 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>133</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>236</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:0a0bf5f9bcad3493438edb7c9ef6bcbac7b1f6f9&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip-AVC+%D0%BE%D1%82+New-Team+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/0a0bf5f9bcad3493438edb7c9ef6bcbac7b1f6f9' title="Марсианин / The Martian (2015) BDRip-AVC от New-Team | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip-AVC от New-Team | Лицензия</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.91 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>301</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>25</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:c9f702c120655ece562e546af6851607cd0e17e8&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+HDRip+%D0%BE%D1%82+Scarabey+%7C+%D0%A7%D0%B8%D1%81%D1%82%D1%8B%D0%B9+%D0%B7%D0%B2%D1%83%D0%BA&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/c9f702c120655ece562e546af6851607cd0e17e8' title="Марсианин / The Martian (2015) HDRip от Scarabey | Чистый звук"><b>Марсианин</b> / The Martian (2015) HDRip от Scarabey | Чистый звук</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >1 месяц назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >799 MB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>284</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>30</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:59ccc16cc02733508e2fb6aff179c4cbd285a4d3&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip-AVC+%D0%BE%D1%82+HELLYWOOD+%7C+iTunes&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/59ccc16cc02733508e2fb6aff179c4cbd285a4d3' title="Марсианин / The Martian (2015) BDRip-AVC от HELLYWOOD | iTunes"><b>Марсианин</b> / The Martian (2015) BDRip-AVC от HELLYWOOD | iTunes</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >3 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >1.65 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>298</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>14</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:a629e4c2dcd789d438b36b6799e3121a02e64b8e&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+HDRip+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/a629e4c2dcd789d438b36b6799e3121a02e64b8e' title="Марсианин / The Martian (2015) HDRip | Лицензия"><b>Марсианин</b> / The Martian (2015) HDRip | Лицензия</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >800 MB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>248</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>39</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:b67a2fb4032a350f329ea3c4c961c39e11797a63&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+%D0%BE%D1%82+HQCLUB+%7C+D+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/b67a2fb4032a350f329ea3c4c961c39e11797a63' title="Марсианин / The Martian (2015) BDRip от HQCLUB | D | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip от HQCLUB | D | Лицензия</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >3 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.18 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>113</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>73</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:efd499b31922e6e823fde4d4a80ad66ce03cea6d&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+%D0%BE%D1%82+HQ-ViDEO+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/efd499b31922e6e823fde4d4a80ad66ce03cea6d' title="Марсианин / The Martian (2015) BDRip от HQ-ViDEO | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip от HQ-ViDEO | Лицензия</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >2.91 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>132</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>23</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:e7731134c4ab107ab04c22cc85adbd455e81dace&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+1080p+%7C+3D-Video+%7C+HSBS+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/e7731134c4ab107ab04c22cc85adbd455e81dace' title="Марсианин / The Martian (2015) BDRip 1080p | 3D-Video | HSBS | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip 1080p | 3D-Video | HSBS | Лицензия</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >11.6 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>93</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>39</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:00918b480bda87f1c5e1ce1f84cb2f3cf470067f&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+TS&tr.1=http://retracker.local/announce&tr.2=udp://bt.rutor.org:2710&tr.3=udp://tracker.openbittorrent.com:80/announce&tr.4=udp://tracker.publicbt.com:80/announce&tr.5=http://announce.opensharing.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/00918b480bda87f1c5e1ce1f84cb2f3cf470067f' title="Марсианин / The Martian (2015) TS"><b>Марсианин</b> / The Martian (2015) TS</a><br /><span class='gray'>Зарубежные фильмы</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >2 месяца назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >706 MB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>108</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>6</span></td>
</tr>
<tr>
<td class='small inner'><a href="magnet:?xt=urn:btih:cc24bd68d1c27261c9a353064883f050f8ea73d3&dn=Ruhunt.org_%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD+%2F+The+Martian+%282015%29+BDRip+720p+%7C+%D0%9B%D0%B8%D1%86%D0%B5%D0%BD%D0%B7%D0%B8%D1%8F&tr.1=http://retracker.local/announce&tr.2=http://tracker.ipv6tracker.org:80/announce&tr.3=udp://bt.rutor.org:2710&tr.4=http://pubt.net:2710/announce&tr.5=http://bt.rutor.org:2710/announce" title='Скачать через magnet-ссылку'><img src='/magnet.png' border='0'></a></td><td class='inner' nowrap='nowrap'><span class='n'><a href='http://ruhunt.org/cc24bd68d1c27261c9a353064883f050f8ea73d3' title="Марсианин / The Martian (2015) BDRip 720p | Лицензия"><b>Марсианин</b> / The Martian (2015) BDRip 720p | Лицензия</a><br /><span class='gray'>Фантастика</span></span></td>
<td width='95px' nowrap='nowrap' class='small inner' >4 недели назад</td>
<td width='55px' align='right' nowrap='nowrap' class='small inner' >9.34 GB</td>
<td width='35px' align='right' nowrap='nowrap' class='small inner'><span class='seeders' title='Раздают'>24</span></td>
<td width='35px' align='right' nowrap='nowrap' class='small' ><span class='leechers' title='Качают'>88</span></td>
</tr>
</table>
</div>
<div class='rounded_bottom grid_12 sepH_c' style='padding:8px 0 8px 0;background:#EEE;'><div class='navigation tar' style='margin-bottom:10px; margin-top:10px;padding-right:10px'>&nbsp;<a href='http://ruhunt.org/search?q=%D0%9C%D0%B0%D1%80%D1%81%D0%B8%D0%B0%D0%BD%D0%B8%D0%BD&tag=video&page=2'>Следующая</a></div></div></div><div style="background:#F0F0F0;" class="grid_12 rounded sepH_c"><div style="margin:8px;padding:8px"><span class="small">Последние запросы: <a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BC%D0%B0%D0%B3%D0%BE%D0%BC%D0%B0%D0%B5%D0%B2'>магомаев</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D1%81%D0%B5%D1%80%D0%B8%D0%B0%D0%BB'>сериал</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=diablo+3'>diablo 3</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%94%D0%B5%D0%B2%D1%83%D1%88%D0%BA%D0%B0+%D0%BA%D0%BE%D1%82%D0%BE%D1%80%D0%B0%D1%8F+%D0%B8%D0%B3%D1%80%D0%B0%D0%BB%D0%B0+%D1%81+%D0%BE%D0%B3%D0%BD%D0%B5%D0%BC'>Девушка которая играла с огнем</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BB%D0%BE%D0%B2%D1%83%D1%88%D0%BA%D0%B0'>ловушка</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BC%D0%B8%D1%85%D0%B0%D0%B9%D0%BB%D0%BE%D0%B2'>михайлов</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D1%84%D0%B8%D0%BB%D1%8C%D0%BC'>фильм</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%B4%D0%B5%D0%BD%D0%B5%D0%B6%D0%BD%D1%8B%D0%B9+%D0%BF%D0%BE%D1%82%D0%BE%D0%BA'>денежный поток</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4%D1%87%D0%B8%D0%BA+%D1%81+%D1%81%D0%BE%D0%B1%D0%B0%D1%87%D1%8C%D0%B5%D0%B3%D0%BE'>переводчик с собачьего</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BD%D0%BE%D0%B2%D1%8B%D0%B5+%D1%84%D0%B8%D0%BB%D1%8C%D0%BC%D1%8B'>новые фильмы</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=Adobe+Photoshop'>Adobe Photoshop</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=nokia'>nokia</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BF%D0%BE%D0%B8%D1%81%D0%BA+%D0%BF%D1%80%D0%B5%D0%B4%D0%BC%D0%B5%D1%82%D0%BE%D0%B2'>поиск предметов</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%93%D0%BB%D0%B0%D0%B4%D0%B8%D0%B0%D1%82%D0%BE%D1%80'>Гладиатор</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=spartacus'>spartacus</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%B8%D0%B3%D1%80%D0%B0+%D1%82%D0%B5%D0%BD%D0%B5%D0%B9'>игра теней</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=mp3+pop'>mp3 pop</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%9E%D1%82%D0%B5%D1%86+%D1%81%D0%BE%D0%BB%D0%B4%D0%B0%D1%82%D0%B0'>Отец солдата</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%91%D0%BE%D0%BB%D0%B5%D0%B7%D0%BD%D0%B8'>Болезни</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=PORTAL+2'>PORTAL 2</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BD%D1%8F%D0%BD%D1%8F'>няня</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%BA%D0%BE%D0%BC%D0%B5%D0%B4%D0%B8%D1%8F'>комедия</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%9F%D1%80%D0%B8%D0%B7%D1%80%D0%B0%D0%BA+%D0%BF%D1%80%D0%B8%D0%B2%D0%B8%D0%B4%D0%B5%D0%BD%D0%B8%D0%B5'>Призрак привидение</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%B3%D0%B0%D1%80%D1%80%D0%B8+%D0%BF%D0%BE%D1%82%D1%82%D0%B5%D1%80+%D0%B8+%D1%82%D0%B0%D0%B9%D0%BD%D0%B0%D1%8F+%D0%BA%D0%BE%D0%BC%D0%BD%D0%B0%D1%82%D0%B0'>гарри поттер и тайная комната</a> &bull;&nbsp;<a class='small' style='color:#666;' href='http://ruhunt.org/search?q=%D0%9E%D1%80%D0%B4%D0%B0'>Орда</a></span></div></div>
<div class='grid_12 tac sepH_c'><a href='#top'>&#9650; Наверх &#9650;</a></div><br /></div><div class='smaller tac sepH_c'>
<a href='http://ruhunt.org/'>Главная</a> &bull; <a href='sitemap'>Карта Сайта</a> &bull; <a href='contact'>Связь</a> &bull; <a href='/ruhunt.btsearch'>&#x03BC;Torrent плагин</a> &bull; <a href="javascript:window.external.AddSearchProvider('http://ruhunt.org/opensearch.xml');">Поиск для браузера</a>
<br /><br />Ruhunt.org &copy; 2012<br /><br />
</div>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js"></script>
<script type="text/javascript" src="/add_bookmark.js"></script>
<script type="text/javascript" src="/jquery.autocomplete.js"></script>
<script type="text/javascript">
<!--
function ab(e){var input=document.createElement("input");input.setAttribute("type","hidden");input.setAttribute("name","ab");input.setAttribute("value","skip");e.appendChild(input);return true;}$(document).ready(function(){tr_click();$(document).on("mouseover","td",function(event){if($(this).find("a").length){if($(this).find("a").attr("target")!="_blank"){$(this).css("cursor","pointer");}return false;}});});function tr_click(){$("td").click(function(){if($(this).find("a").length){if($(this).find("a").attr("target")!="_blank"){window.location=$(this).find("a").attr("href");}return false;}});}function disp_confirm(e){$.get(location.href,"load=1&tag="+$("#tag").val()+"&sort="+$("#sort").val()+"&tracker="+$("#tracker").val(),function(data){$("#load").html(data);if($("#tracker").val()=="all"){tr_click();}});}document.f.q.focus();$(function(){$('#search').hover(function() {if($(this).is(':focus')){}else{var text=$(this).val();$(this).focus();$(this).val('');$(this).val(text);}});$('#search').autocomplete({serviceUrl:'/suggest?i=s',minChars:3,onSelect: function(value, data){ $(this).parents('form').submit(); }});});new Image().src = "//counter.yadro.ru/hit?r" + escape(document.referrer) + ((typeof(screen)=="undefined")?"" : ";s"+screen.width+"*"+screen.height+"*" + (screen.colorDepth?screen.colorDepth:screen.pixelDepth)) + ";u"+escape(document.URL) + ";h"+escape(document.title.substring(0,80)) + ";" +Math.random();
-->
</script>
</body>
</html>
'''

from bs4 import BeautifulSoup

soup = BeautifulSoup(data, 'html5lib')
links = soup.find("table", id="torrents").tbody.findAll('tr')

for link in links:
    columns = link.findAll('td')
    print len(columns)
    print columns[0]
    print columns[1]
    print columns[2]
    print columns[1].text  # name
    print columns[0].a["href"]  # magnet
    print columns[3].text  # size
    print columns[4].text  # seed
    print columns[5].text  # leech
    print "************************"