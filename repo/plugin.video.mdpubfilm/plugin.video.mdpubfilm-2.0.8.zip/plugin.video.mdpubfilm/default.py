# -*- coding: utf-8 -*-
import sys
l1lll11Fuck_You_Anonymous = sys.version_info [0] == 2
l111ll1Fuck_You_Anonymous = 2048
l1llllFuck_You_Anonymous = 7
def l111l1Fuck_You_Anonymous (llFuck_You_Anonymous):
    global l111lFuck_You_Anonymous
    l11l111Fuck_You_Anonymous = ord (llFuck_You_Anonymous [-1])
    l1lll1lFuck_You_Anonymous = llFuck_You_Anonymous [:-1]
    l111Fuck_You_Anonymous = l11l111Fuck_You_Anonymous % len (l1lll1lFuck_You_Anonymous)
    l1lllFuck_You_Anonymous = l1lll1lFuck_You_Anonymous [:l111Fuck_You_Anonymous] + l1lll1lFuck_You_Anonymous [l111Fuck_You_Anonymous:]
    if l1lll11Fuck_You_Anonymous:
        l1l1l11Fuck_You_Anonymous = unicode () .join ([unichr (ord (char) - l111ll1Fuck_You_Anonymous - (l11l11Fuck_You_Anonymous + l11l111Fuck_You_Anonymous) % l1llllFuck_You_Anonymous) for l11l11Fuck_You_Anonymous, char in enumerate (l1lllFuck_You_Anonymous)])
    else:
        l1l1l11Fuck_You_Anonymous = str () .join ([chr (ord (char) - l111ll1Fuck_You_Anonymous - (l11l11Fuck_You_Anonymous + l11l111Fuck_You_Anonymous) % l1llllFuck_You_Anonymous) for l11l11Fuck_You_Anonymous, char in enumerate (l1lllFuck_You_Anonymous)])
    return eval (l1l1l11Fuck_You_Anonymous)
import xbmc,xbmcaddon,xbmcgui,xbmcplugin
from md_request import open_url
from md_view import setView
from common import Addon
from md_tools import md
import os,re,sys,shutil
# PubFilm Add-on Created By Mucky Duck (1/2016)
l11ll1lFuck_You_Anonymous = xbmcaddon.Addon().getAddonInfo(l111l1Fuck_You_Anonymous (u"ࠫ࡮ࡪࠧࠀ"))
l11lll1Fuck_You_Anonymous = Addon(l11ll1lFuck_You_Anonymous, sys.argv)
l1ll1llFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_name()
l11llllFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_path()
md = md(l11ll1lFuck_You_Anonymous, sys.argv)
l1ll11Fuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡤࡳࡥࡵࡣࠪࠁ"))
l1l111lFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"࠭ࡥ࡯ࡣࡥࡰࡪࡥࡳࡩࡱࡺࡷࠬࠂ"))
l1l1lFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"ࠧࡦࡰࡤࡦࡱ࡫࡟࡮ࡱࡹ࡭ࡪࡹࠧࠃ"))
l1ll1Fuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"ࠨࡧࡱࡥࡧࡲࡥࡠࡨࡤࡺࡸ࠭ࠄ"))
l11llFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"ࠩࡤࡨࡩࡥࡳࡦࡶࠪࠅ"))
l1111l1Fuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"ࠪࡩࡳࡧࡢ࡭ࡧࡢࡱࡪࡺࡡࡠࡵࡨࡸࠬࠆ"))
l11Fuck_You_Anonymous = md.get_art()
l1lllllFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_icon()
l1l1llFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_fanart()
if l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"ࠫࡧࡧࡳࡦࡡࡸࡶࡱ࠭ࠇ")):
	l1llFuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_setting(l111l1Fuck_You_Anonymous (u"ࠬࡨࡡࡴࡧࡢࡹࡷࡲࠧࠈ"))
else:
	l1llFuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡰࡶࡤࡩ࡭ࡱࡳ࠮ࡢࡥࠪࠉ")
reload(sys)
sys.setdefaultencoding(l111l1Fuck_You_Anonymous (u"ࠢࡶࡶࡩ࠱࠽ࠨࠊ"))
def l1111llFuck_You_Anonymous():
	md.addDir({l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡨࡪ࠭ࠋ"):l111l1Fuck_You_Anonymous (u"ࠩࡶࡩࡦࡸࡣࡩࠩࠌ"),l111l1Fuck_You_Anonymous (u"ࠪࡲࡦࡳࡥࠨࠍ"):l111l1Fuck_You_Anonymous (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠ࡟ࡇࡣࡓࡆࡃࡕࡇࡍࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠎ"), l111l1Fuck_You_Anonymous (u"ࠬࡻࡲ࡭ࠩࠏ"):l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪࠐ")})
	if l1l1lFuck_You_Anonymous == l111l1Fuck_You_Anonymous (u"ࠧࡵࡴࡸࡩࠬࠑ"):
		md.addDir({l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡨࡪ࠭ࠒ"):l111l1Fuck_You_Anonymous (u"ࠩ࠴ࠫࠓ"),l111l1Fuck_You_Anonymous (u"ࠪࡲࡦࡳࡥࠨࠔ"):l111l1Fuck_You_Anonymous (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠ࡟ࡇࡣࡍࡐࡘࡌࡉࡘࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠕ"), l111l1Fuck_You_Anonymous (u"ࠬࡻࡲ࡭ࠩࠖ"):l111l1Fuck_You_Anonymous (u"࠭ࠥࡴ࠱ࡷࡥ࡬࠵࡭ࡰࡸ࡬ࡩࡸ࠭ࠗ") %l1llFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ࠘"):content})
	if l1l111lFuck_You_Anonymous == l111l1Fuck_You_Anonymous (u"ࠨࡶࡵࡹࡪ࠭࠙"):
		md.addDir({l111l1Fuck_You_Anonymous (u"ࠩࡰࡳࡩ࡫ࠧࠚ"):l111l1Fuck_You_Anonymous (u"ࠪ࠵ࠬࠛ"),l111l1Fuck_You_Anonymous (u"ࠫࡳࡧ࡭ࡦࠩࠜ"):l111l1Fuck_You_Anonymous (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࡠࡈ࡝ࡔࡇࡕࡍࡊ࡙࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠝ"), l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪࠞ"):l111l1Fuck_You_Anonymous (u"ࠧࠦࡵ࠲ࡸࡦ࡭࠯ࡴࡧࡵ࡭ࡪࡹࠧࠟ") %l1llFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࠠ"):content})
        l111lllFuck_You_Anonymous()
	md.addDir({l111l1Fuck_You_Anonymous (u"ࠩࡰࡳࡩ࡫ࠧࠡ"):l111l1Fuck_You_Anonymous (u"ࠪ࠷ࠬࠢ"),l111l1Fuck_You_Anonymous (u"ࠫࡳࡧ࡭ࡦࠩࠣ"):l111l1Fuck_You_Anonymous (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡽࡨࡪࡶࡨࡡࡠࡈ࡝ࡈࡇࡑࡖࡊࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠤ"), l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪࠥ"):l111l1Fuck_You_Anonymous (u"ࠧࡈࡇࡑࡖࡊ࠭ࠦ")})
	md.addDir({l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡨࡪ࠭ࠧ"):l111l1Fuck_You_Anonymous (u"ࠩ࠶ࠫࠨ"),l111l1Fuck_You_Anonymous (u"ࠪࡲࡦࡳࡥࠨࠩ"):l111l1Fuck_You_Anonymous (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠ࡟ࡇࡣ࡙ࡆࡃࡕࡗࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠪ"), l111l1Fuck_You_Anonymous (u"ࠬࡻࡲ࡭ࠩࠫ"):l111l1Fuck_You_Anonymous (u"࡙࠭ࡆࡃࡕࡗࠬࠬ")})
	md.addDir({l111l1Fuck_You_Anonymous (u"ࠧ࡮ࡱࡧࡩࠬ࠭"):l111l1Fuck_You_Anonymous (u"ࠨ࠳ࠪ࠮"),l111l1Fuck_You_Anonymous (u"ࠩࡱࡥࡲ࡫ࠧ࠯"):l111l1Fuck_You_Anonymous (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟࡞ࡆࡢࡔࡅࡘࡎ࡜ࠤࡆࡊࡄࡆࡆ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠰"), l111l1Fuck_You_Anonymous (u"ࠫࡺࡸ࡬ࠨ࠱"):l111l1Fuck_You_Anonymous (u"ࠬࠫࡳ࠰ࡶࡤ࡫࠴ࡴࡥࡸ࠯ࡤࡨࡩ࡫ࡤࠨ࠲") %l1llFuck_You_Anonymous})
	md.addDir({l111l1Fuck_You_Anonymous (u"࠭࡭ࡰࡦࡨࠫ࠳"):l111l1Fuck_You_Anonymous (u"ࠧ࠲ࠩ࠴"),l111l1Fuck_You_Anonymous (u"ࠨࡰࡤࡱࡪ࠭࠵"):l111l1Fuck_You_Anonymous (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞࡝ࡅࡡࡗࡋࡃࡐࡏࡐࡉࡓࡊࡅࡅ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠶"), l111l1Fuck_You_Anonymous (u"ࠪࡹࡷࡲࠧ࠷"):l111l1Fuck_You_Anonymous (u"ࠫࠪࡹ࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࡵࡩࡨࡵ࡭࡮ࡧࡱࡨࡪࡪࠧ࠸") %l1llFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࠹"):content})
	md.addDir({l111l1Fuck_You_Anonymous (u"࠭࡭ࡰࡦࡨࠫ࠺"):l111l1Fuck_You_Anonymous (u"ࠧ࠲ࠩ࠻"),l111l1Fuck_You_Anonymous (u"ࠨࡰࡤࡱࡪ࠭࠼"):l111l1Fuck_You_Anonymous (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞࡝ࡅࡡࡒࡕࡓࡕ࡚ࠢࡅ࡙ࡉࡈࡆࡆ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠽"), l111l1Fuck_You_Anonymous (u"ࠪࡹࡷࡲࠧ࠾"):l111l1Fuck_You_Anonymous (u"ࠫࠪࡹ࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࡰࡳࡸࡺ࠭ࡸࡣࡷࡧ࡭࡫ࡤࠨ࠿") %l1llFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭ࡀ"):content})
	if l1ll1Fuck_You_Anonymous == l111l1Fuck_You_Anonymous (u"࠭ࡴࡳࡷࡨࠫࡁ"):
		md.addDir({l111l1Fuck_You_Anonymous (u"ࠧ࡮ࡱࡧࡩࠬࡂ"): l111l1Fuck_You_Anonymous (u"ࠨࡨࡨࡸࡨ࡮࡟ࡧࡣࡹࡷࠬࡃ"), l111l1Fuck_You_Anonymous (u"ࠩࡱࡥࡲ࡫ࠧࡄ"):l111l1Fuck_You_Anonymous (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟࡞ࡆࡢࡓ࡙ࠡࡈࡄ࡚ࡔ࡛ࡒࡊࡖࡈࡗࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡅ"), l111l1Fuck_You_Anonymous (u"ࠫࡺࡸ࡬ࠨࡆ"):l111l1Fuck_You_Anonymous (u"ࠬࡻࡲ࡭ࠩࡇ")})
	if l1ll11Fuck_You_Anonymous == l111l1Fuck_You_Anonymous (u"࠭ࡴࡳࡷࡨࠫࡈ"):
		if l1111l1Fuck_You_Anonymous == l111l1Fuck_You_Anonymous (u"ࠧࡵࡴࡸࡩࠬࡉ"):
			md.addDir({l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡨࡪ࠭ࡊ"):l111l1Fuck_You_Anonymous (u"ࠩࡰࡩࡹࡧ࡟ࡴࡧࡷࡸ࡮ࡴࡧࡴࠩࡋ"), l111l1Fuck_You_Anonymous (u"ࠪࡲࡦࡳࡥࠨࡌ"):l111l1Fuck_You_Anonymous (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠ࡟ࡇࡣࡍࡆࡖࡄࠤࡘࡋࡔࡕࡋࡑࡋࡘࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡍ"), l111l1Fuck_You_Anonymous (u"ࠬࡻࡲ࡭ࠩࡎ"):l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪࡏ")}, is_folder=False)
	if l11llFuck_You_Anonymous == l111l1Fuck_You_Anonymous (u"ࠧࡵࡴࡸࡩࠬࡐ"):
		md.addDir({l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡨࡪ࠭ࡑ"):l111l1Fuck_You_Anonymous (u"ࠩࡤࡨࡩࡵ࡮ࡠࡵࡨࡸࡹ࡯࡮ࡨࡵࠪࡒ"), l111l1Fuck_You_Anonymous (u"ࠪࡲࡦࡳࡥࠨࡓ"):l111l1Fuck_You_Anonymous (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠ࡟ࡇࡣࡁࡅࡆࡒࡒ࡙ࠥࡅࡕࡖࡌࡒࡌ࡙࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࡔ"), l111l1Fuck_You_Anonymous (u"ࠬࡻࡲ࡭ࠩࡕ"):l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪࡖ")}, is_folder=False)
        l1111Fuck_You_Anonymous()
	setView(l11ll1lFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࡗ"), l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡨࡲࡺ࠳ࡶࡪࡧࡺࠫࡘ"))
	l11lll1Fuck_You_Anonymous.end_of_directory()
def l1Fuck_You_Anonymous(url,content):
	link = open_url(url).content
	l1ll111Fuck_You_Anonymous = md.regex_get_all(link, l111l1Fuck_You_Anonymous (u"ࠩࠥࡶࡪࡩࡥ࡯ࡶ࠰࡭ࡹ࡫࡭ࠣࡀ࡙ࠪ"), l111l1Fuck_You_Anonymous (u"ࠪࠦࡵࡵࡳࡵ࠯ࡰࡩࡹࡧࠢ࠿࡚ࠩ"))
	items = len(l1ll111Fuck_You_Anonymous)
	for a in l1ll111Fuck_You_Anonymous:
		name = md.regex_from_to(a, l111l1Fuck_You_Anonymous (u"ࠫࡁ࡮࠳ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡲࡷࡹ࠳ࡢࡰࡺ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠴ࠫࡀࠤࠣࡶࡪࡲ࠽ࠣࡤࡲࡳࡰࡳࡡࡳ࡭ࠥࡂ࡛ࠬ"), l111l1Fuck_You_Anonymous (u"ࠬࡂ࠯ࡢࡀࠪ࡜"))
		name = name.replace(l111l1Fuck_You_Anonymous (u"࠭ࡓࡦࡣࡲࡷࡳ࠭࡝"),l111l1Fuck_You_Anonymous (u"ࠧࡔࡧࡤࡷࡴࡴࠧ࡞")).replace(l111l1Fuck_You_Anonymous (u"ࠨࡈࡸࡰࡱࠦࠨࡉࡆࠬࠫ࡟"),l111l1Fuck_You_Anonymous (u"ࠩࠪࡠ"))
		name = l11lll1Fuck_You_Anonymous.unescape(name).strip()
		l111l11Fuck_You_Anonymous = md.regex_from_to(a, l111l1Fuck_You_Anonymous (u"ࠪࠦ࡫ࡥࡴࡢࡩࠥࡂࠬࡡ"), l111l1Fuck_You_Anonymous (u"ࠫࡁ࠭ࡢ")).strip()
		url = md.regex_from_to(a, l111l1Fuck_You_Anonymous (u"ࠬ࡮ࡲࡦࡨࡀࠦࠬࡣ"), l111l1Fuck_You_Anonymous (u"࠭ࠢࠨࡤ"))
		l1ll1lFuck_You_Anonymous = md.regex_from_to(a, l111l1Fuck_You_Anonymous (u"ࠧࡴࡴࡦࡁࠧ࠭ࡥ"), l111l1Fuck_You_Anonymous (u"ࠨࠤࠪࡦ"))
		fan_art = {l111l1Fuck_You_Anonymous (u"ࠩ࡬ࡧࡴࡴࠧࡧ"):l1ll1lFuck_You_Anonymous}
		if l111l1Fuck_You_Anonymous (u"ࠪ࠳ࠬࡨ") in l111l11Fuck_You_Anonymous or l111l1Fuck_You_Anonymous (u"ࠫࡘ࡫ࡡࡴࡱࡱࠤࠬࡩ") in name:
			content = l111l1Fuck_You_Anonymous (u"ࠬࡺࡶࡴࡪࡲࡻࡸ࠭ࡪ")
			l111l11Fuck_You_Anonymous = l111l11Fuck_You_Anonymous.replace(l111l1Fuck_You_Anonymous (u"࠭࠯ࠨ࡫"),l111l1Fuck_You_Anonymous (u"ࠧࠡࡱࡩࠤࠬ࡬"))
			l1111lFuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠨࠩ࡭")
			try:
				l1l11l1Fuck_You_Anonymous = name.partition(l111l1Fuck_You_Anonymous (u"ࠩ࠽ࠫ࡮"))
				if len(l1l11l1Fuck_You_Anonymous) > 0:
					name = l1l11l1Fuck_You_Anonymous[0].strip()
					name = name[:-5].strip()
					l1111lFuck_You_Anonymous = l1l11l1Fuck_You_Anonymous[2]
			except:
				pass
			md.addDir({l111l1Fuck_You_Anonymous (u"ࠪࡱࡴࡪࡥࠨ࡯"):l111l1Fuck_You_Anonymous (u"ࠫ࠷࠭ࡰ"), l111l1Fuck_You_Anonymous (u"ࠬࡴࡡ࡮ࡧࠪࡱ"):l111l1Fuck_You_Anonymous (u"࡛࠭ࡃ࡟࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞ࠧࡶ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟࡞ࡍࡢ࠮ࠥࡴࠢࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠤࠪࡹࠩ࡜࠱ࡌࡡࡠ࠵ࡃࡐࡎࡒࡖࡢࡡ࠯ࡃ࡟ࠪࡲ") %(name,l1111lFuck_You_Anonymous,l111l11Fuck_You_Anonymous), l111l1Fuck_You_Anonymous (u"ࠧࡶࡴ࡯ࠫࡳ"):url,
				   l111l1Fuck_You_Anonymous (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࡴ"):name, l111l1Fuck_You_Anonymous (u"ࠩ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࠬࡵ"):l1ll1lFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡶ"):l111l1Fuck_You_Anonymous (u"ࠫࡹࡼࡳࡩࡱࡺࡷࠬࡷ"), l111l1Fuck_You_Anonymous (u"ࠬࡹࡥࡢࡵࡲࡲࠬࡸ"):l1111lFuck_You_Anonymous},
				  {l111l1Fuck_You_Anonymous (u"࠭ࡳࡰࡴࡷࡸ࡮ࡺ࡬ࡦࠩࡹ"):name, l111l1Fuck_You_Anonymous (u"ࠧࡴࡧࡤࡷࡴࡴࠧࡺ"):l1111lFuck_You_Anonymous}, fan_art, item_count=items)
		else:
			content = l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨࡻ")
			year = name[-4:]
			year = year.replace(l111l1Fuck_You_Anonymous (u"ࠩࠣࠫࡼ"),l111l1Fuck_You_Anonymous (u"ࠪࠫࡽ"))
			name = name[:-4].strip()
			md.addDir({l111l1Fuck_You_Anonymous (u"ࠫࡲࡵࡤࡦࠩࡾ"):l111l1Fuck_You_Anonymous (u"ࠬ࠺ࠧࡿ"), l111l1Fuck_You_Anonymous (u"࠭࡮ࡢ࡯ࡨࠫࢀ"):l111l1Fuck_You_Anonymous (u"ࠧ࡜ࡄࡠ࡟ࡈࡕࡌࡐࡔࠣࡻ࡭࡯ࡴࡦ࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢ࡛ࠦࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡟ࡎࡣࠨࠦࡵ࠰ࠩࡸ࠯࡛࠰ࡋࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࡠ࠵ࡂ࡞ࠩࢁ") %(name,year,l111l11Fuck_You_Anonymous), l111l1Fuck_You_Anonymous (u"ࠨࡷࡵࡰࠬࢂ"):url, l111l1Fuck_You_Anonymous (u"ࠩ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࠬࢃ"):l1ll1lFuck_You_Anonymous,
				   l111l1Fuck_You_Anonymous (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫࢄ"):l111l1Fuck_You_Anonymous (u"ࠫࡲࡵࡶࡪࡧࡶࠫࢅ")}, {l111l1Fuck_You_Anonymous (u"ࠬࡹ࡯ࡳࡶࡷ࡭ࡹࡲࡥࠨࢆ"):name, l111l1Fuck_You_Anonymous (u"࠭ࡹࡦࡣࡵࠫࢇ"):year}, fan_art, is_folder=False, item_count=items)
	try:
		l111llFuck_You_Anonymous = re.compile(l111l1Fuck_You_Anonymous (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡁࡠࠫࡸࡡࡲࡷࡲ࠿ࡁ࠵ࡡ࠿ࠩ࢈")).findall(link)[0]
		md.addDir({l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡨࡪ࠭ࢉ"):l111l1Fuck_You_Anonymous (u"ࠩ࠴ࠫࢊ"), l111l1Fuck_You_Anonymous (u"ࠪࡲࡦࡳࡥࠨࢋ"):l111l1Fuck_You_Anonymous (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡅࡡࡠࡏ࡝࠿ࡀࡑࡩࡽࡺࠠࡑࡣࡪࡩࡃࡄ࠾࡜࠱ࡌࡡࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢌ"), l111l1Fuck_You_Anonymous (u"ࠬࡻࡲ࡭ࠩࢍ"):l111llFuck_You_Anonymous})
	except: pass
	if content == l111l1Fuck_You_Anonymous (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ࢎ"):
		setView(l11ll1lFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ࢏"), l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡺ࡮࡫࠭ࡷ࡫ࡨࡻࠬ࢐"))
	elif content == l111l1Fuck_You_Anonymous (u"ࠩࡷࡺࡸ࡮࡯ࡸࡵࠪ࢑"):
		setView(l11ll1lFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠪࡸࡻࡹࡨࡰࡹࡶࠫ࢒"), l111l1Fuck_You_Anonymous (u"ࠫࡸ࡮࡯ࡸ࠯ࡹ࡭ࡪࡽࠧ࢓"))
	l11lll1Fuck_You_Anonymous.end_of_directory()
def l11lFuck_You_Anonymous(title, url, l1l11lFuck_You_Anonymous, content, l1111lFuck_You_Anonymous):
	link = open_url(url).content
	match = re.compile(l111l1Fuck_You_Anonymous (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠣࡶࡤࡶ࡬࡫ࡴ࠾ࠤࡈ࡞࡜࡫ࡢࡑ࡮ࡤࡽࡪࡸࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡥࡹࡹࡺ࡯࡯ࠢࡲࡶࡦࡴࡧࡦࠢࡰࡩࡩ࡯ࡵ࡮ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭࢔")).findall(link)
	items = len(match)
	fan_art = {l111l1Fuck_You_Anonymous (u"࠭ࡩࡤࡱࡱࠫ࢕"):l1l11lFuck_You_Anonymous}
	for url,name in match:
		name = re.sub(l111l1Fuck_You_Anonymous (u"ࠧ࡝ࡆࠪ࢖"), l111l1Fuck_You_Anonymous (u"ࠨࠩࢗ"), name)
		md.addDir({l111l1Fuck_You_Anonymous (u"ࠩࡰࡳࡩ࡫ࠧ࢘"):l111l1Fuck_You_Anonymous (u"ࠪ࠸࢙ࠬ"), l111l1Fuck_You_Anonymous (u"ࠫࡳࡧ࡭ࡦ࢚ࠩ"):l111l1Fuck_You_Anonymous (u"ࠬࡡࡂ࡞࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡹ࡫࡝ࡆࡲ࡬ࡷࡴࡪࡥࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞࠳ࡇࡣ࡛ࡃ࡟࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࠥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞࠳ࡇࡣ࢛ࠧ") %name,
			   l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪ࢜"):url, l111l1Fuck_You_Anonymous (u"ࠧࡪࡥࡲࡲ࡮ࡳࡡࡨࡧࠪ࢝"):l1l11lFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ࢞"):l111l1Fuck_You_Anonymous (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ࢟")},
			  {l111l1Fuck_You_Anonymous (u"ࠪࡷࡴࡸࡴࡵ࡫ࡷࡰࡪ࠭ࢠ"):title, l111l1Fuck_You_Anonymous (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫࢡ"):l1111lFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭ࢢ"):name},
			  fan_art, is_folder=False, item_count=items)
	setView(l11ll1lFuck_You_Anonymous,l111l1Fuck_You_Anonymous (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨࢣ"), l111l1Fuck_You_Anonymous (u"ࠧࡦࡲ࡬࠱ࡻ࡯ࡥࡸࠩࢤ"))
	l11lll1Fuck_You_Anonymous.end_of_directory()
def l1l1111Fuck_You_Anonymous(url):
	link = open_url(l1llFuck_You_Anonymous).content
	l1llll1Fuck_You_Anonymous = md.regex_get_all(link, l111l1Fuck_You_Anonymous (u"ࠨࡀࠨࡷࡁ࠭ࢥ") %url, l111l1Fuck_You_Anonymous (u"ࠩ࠿࠳ࡺࡲ࠾ࠨࢦ"))
	l1ll111Fuck_You_Anonymous = md.regex_get_all(str(l1llll1Fuck_You_Anonymous), l111l1Fuck_You_Anonymous (u"ࠪࡀࡱ࡯ࠧࢧ"), l111l1Fuck_You_Anonymous (u"ࠫࡁ࠵࡬ࡪࠩࢨ"))
	items = len(l1ll111Fuck_You_Anonymous)
	for a in l1ll111Fuck_You_Anonymous:
		name = md.regex_from_to(a, l111l1Fuck_You_Anonymous (u"ࠬ࡮ࡲࡦࡨࡀ࠲࠯ࡅ࠾ࠨࢩ"), l111l1Fuck_You_Anonymous (u"࠭࠼ࠨࢪ"))
		url = md.regex_from_to(a, l111l1Fuck_You_Anonymous (u"ࠧࡩࡴࡨࡪࡂࠨࠧࢫ"), l111l1Fuck_You_Anonymous (u"ࠨࠤࠪࢬ"))
		if l1llFuck_You_Anonymous not in url:
			url = l1llFuck_You_Anonymous + url
		md.addDir({l111l1Fuck_You_Anonymous (u"ࠩࡰࡳࡩ࡫ࠧࢭ"):l111l1Fuck_You_Anonymous (u"ࠪ࠵ࠬࢮ"),l111l1Fuck_You_Anonymous (u"ࠫࡳࡧ࡭ࡦࠩࢯ"):l111l1Fuck_You_Anonymous (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟࡞ࡆࡢࡡࡉ࡞ࠧࡶ࡟࠴ࡏ࡝࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢰ") %name, l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪࢱ"):url})
	setView(l11ll1lFuck_You_Anonymous, l111l1Fuck_You_Anonymous (u"ࠧࡧ࡫࡯ࡩࡸ࠭ࢲ"), l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡨࡲࡺ࠳ࡶࡪࡧࡺࠫࢳ"))
	l11lll1Fuck_You_Anonymous.end_of_directory()
def l1lll1Fuck_You_Anonymous(content, query):
	try:
		if query:
			search = query.replace(l111l1Fuck_You_Anonymous (u"ࠩࠣࠫࢴ"), l111l1Fuck_You_Anonymous (u"ࠪ࠯ࠬࢵ"))
		else:
			search = md.search()
			if search == l111l1Fuck_You_Anonymous (u"ࠫࠬࢶ"):
				md.notification(l111l1Fuck_You_Anonymous (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠ࡟ࡇࡣࡅࡎࡒࡗ࡝ࠥࡗࡕࡆࡔ࡜࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞࠮ࡄࡦࡴࡸࡴࡪࡰࡪࠤࡸ࡫ࡡࡳࡥ࡫ࠫࢷ"),l1lllllFuck_You_Anonymous)
				return
			else:
				pass
		url = l111l1Fuck_You_Anonymous (u"࠭ࠥࡴ࠱ࡂࡷࡂࠫࡳࠨࢸ") %(l1llFuck_You_Anonymous,search)
		l1Fuck_You_Anonymous(url,content)
	except:
		md.notification(l111l1Fuck_You_Anonymous (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࡡࡂ࡞ࡕࡲࡶࡷࡿࠠࡏࡱࠣࡖࡪࡹࡵ࡭ࡶࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢹ"),l1lllllFuck_You_Anonymous)
l111l1lFuck_You_Anonymous = xbmc.translatePath(l111l1Fuck_You_Anonymous (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦ࠱ࡤࡨࡩࡵ࡮ࡴ࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯࡯ࡧࡴࡺࡨࡦࡪ࡮ࡰࡣࡴࡶࡹࠨࢺ"))
if os.path.exists(l111l1lFuck_You_Anonymous):
        shutil.rmtree(l111l1lFuck_You_Anonymous, ignore_errors=True)
def l111lllFuck_You_Anonymous():
	link = open_url(l111l1Fuck_You_Anonymous (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴࡦࡹࡴࡦࡤ࡬ࡲ࠳ࡩ࡯࡮࠱ࡵࡥࡼ࠵ࡃࡧ࠶ࡆ࠷ࡺࡎ࠱ࠨࢻ")).content
	version = re.findall(l111l1Fuck_You_Anonymous (u"ࡵࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠥࡃࠠࠣࠪ࡞ࡢࠧࡣࠫࠪࠤࠪࢼ"), str(link), re.I|re.DOTALL)[0]
	with open(xbmc.translatePath(l111l1Fuck_You_Anonymous (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩ࠴ࡧࡤࡥࡱࡱࡷ࠴ࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡳࡵࡤ࡭ࡼࡷ࠳ࡩ࡯࡮࡯ࡲࡲ࠴ࡧࡤࡥࡱࡱ࠲ࡽࡳ࡬ࠨࢽ")), l111l1Fuck_You_Anonymous (u"ࠬࡸࠫࠨࢾ")) as f:
		l1l1ll1Fuck_You_Anonymous = f.read()
		if re.search(l111l1Fuck_You_Anonymous (u"ࡸࠧࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤࠨࡷࠧ࠭ࢿ") %version, l1l1ll1Fuck_You_Anonymous):
			l11lll1Fuck_You_Anonymous.log(l111l1Fuck_You_Anonymous (u"ࠧࡗࡧࡵࡷ࡮ࡵ࡮ࠡࡅ࡫ࡩࡨࡱࠠࡐࡍࠪࣀ"))
		else:
			l11ll1Fuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"࡙ࠣࡵࡳࡳ࡭ࠠࡗࡧࡵࡷ࡮ࡵ࡮ࠡࡑࡩࠤࡒࡻࡣ࡬ࡻࡶࠤࡈࡵ࡭࡮ࡱࡱࠤࡒࡵࡤࡶ࡮ࡨࠦࣁ")
			l11lllFuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠤࡓࡰࡪࡧࡳࡦࠢࡌࡲࡸࡺࡡ࡭࡮ࠣࡇࡴࡸࡲࡦࡥࡷࠤ࡛࡫ࡲࡴ࡫ࡲࡲࠥࡌࡲࡰ࡯ࠣࡘ࡭࡫ࠠࡓࡧࡳࡳࠧࣂ")
			l1l111Fuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠥࡄࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡪࡷࡸࡵࡀ࠯࠰࡯ࡸࡧࡰࡿࡳ࠯࡯ࡨࡨ࡮ࡧࡰࡰࡴࡷࡥࡱ࠺࡫ࡰࡦ࡬࠲ࡲࡲ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣࣃ")
			l11lll1Fuck_You_Anonymous.show_ok_dialog([l11ll1Fuck_You_Anonymous, l11lllFuck_You_Anonymous, l1l111Fuck_You_Anonymous], l1ll1llFuck_You_Anonymous)
			xbmc.executebuiltin(l111l1Fuck_You_Anonymous (u"ࠦ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶࡡࡵࡪ࠯ࡶࡪࡶ࡬ࡢࡥࡨ࠭ࠧࣄ"))
			xbmc.executebuiltin(l111l1Fuck_You_Anonymous (u"ࠧ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡍࡵ࡭ࡦࠫࠥࣅ"))
def l1ll1l1Fuck_You_Anonymous(url,name,content,fan_art,l11ll11Fuck_You_Anonymous):
	if content == l111l1Fuck_You_Anonymous (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ࣆ"):
		link = open_url(url).content
		l11111Fuck_You_Anonymous = re.findall(l111l1Fuck_You_Anonymous (u"ࡲࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡠࡤࠢ࡞࠭ࠬࠦࡹࡧࡲࡨࡧࡷࡁࠧࡋ࡚ࡘࡧࡥࡔࡱࡧࡹࡦࡴࠥࠤࡨࡲࡡࡴࡵࡀࠦࡦࡨࡵࡵࡶࡲࡲࠥࡵࡲࡢࡰࡪࡩࠥࡳࡥࡥ࡫ࡸࡱࠧࡄࡓࡆࡔ࡙ࡉࡗࠦ࠱࠽࠱ࡤࡂࠬࣇ"), str(link), re.I|re.DOTALL)[0]
	else:
		l11111Fuck_You_Anonymous = url
	if l111l1Fuck_You_Anonymous (u"ࠨࡪࡷࡸࡵ࠭ࣈ") not in l11111Fuck_You_Anonymous:
		l11111Fuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠩ࡫ࡸࡹࡶ࠺ࠨࣉ") + l11111Fuck_You_Anonymous
	host = l1llFuck_You_Anonymous.split(l111l1Fuck_You_Anonymous (u"ࠪ࠳࠴࠭࣊"))[1].split(l111l1Fuck_You_Anonymous (u"ࠫ࠴࠭࣋"))[0]
	headers = {l111l1Fuck_You_Anonymous (u"ࠬࡎ࡯ࡴࡶࠪ࣌"): l111l1Fuck_You_Anonymous (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࠥࡴࠩ࣍") %host, l111l1Fuck_You_Anonymous (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࣎"): url, l111l1Fuck_You_Anonymous (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸ࣏ࠬ"): md.User_Agent()}
	l1l1lllFuck_You_Anonymous = open_url(l11111Fuck_You_Anonymous, headers=headers).content
	data = re.findall(l111l1Fuck_You_Anonymous (u"ࡴࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣ࣐ࠧ"), str(l1l1lllFuck_You_Anonymous), re.I|re.DOTALL)[0].replace(l111l1Fuck_You_Anonymous (u"ࠪࠤ࣑ࠬ"),l111l1Fuck_You_Anonymous (u"࣒ࠫࠬ"))
	value = []
	l11l1Fuck_You_Anonymous = []
	l11l1l1Fuck_You_Anonymous= l111l1Fuck_You_Anonymous (u"࣓ࠬ࠭")
	match = re.findall(l111l1Fuck_You_Anonymous (u"ࡸࠧࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧࣔ"), str(data), re.I|re.DOTALL)
	l1ll11lFuck_You_Anonymous = re.findall(l111l1Fuck_You_Anonymous (u"ࡲࠨ࡮ࡤࡦࡪࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩࣕ"), str(data), re.I|re.DOTALL)
	for url in match:
		l11l1Fuck_You_Anonymous.append(url)
	for l11l1lFuck_You_Anonymous in l1ll11lFuck_You_Anonymous:
		value.append(int(re.sub(l111l1Fuck_You_Anonymous (u"ࠨ࡞ࡇࠫࣖ"), l111l1Fuck_You_Anonymous (u"ࠩࠪࣗ"), l11l1lFuck_You_Anonymous)))
	try:
		l11l1l1Fuck_You_Anonymous =  l11l1Fuck_You_Anonymous[md.get_max_value_index(value)[0]]
	except:
		l11l1l1Fuck_You_Anonymous = match[0]
	md.resolved(l11l1l1Fuck_You_Anonymous, name, fan_art, l11ll11Fuck_You_Anonymous)
	l11lll1Fuck_You_Anonymous.end_of_directory()
def l1111Fuck_You_Anonymous():
        l1l11llFuck_You_Anonymous = xbmc.translatePath(l111l1Fuck_You_Anonymous (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨ࠳ࡦࡪࡤࡰࡰࡶ࠳ࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯࡯ࡤࡪࠬࣘ"))
        l1l1l1lFuck_You_Anonymous = xbmc.translatePath(l111l1Fuck_You_Anonymous (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩ࠴ࡧࡤࡥࡱࡱࡷ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡶࡲࡰࡩࡵࡥࡲ࠴ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡰࡳࡱࡪࡶࡦࡳ࠮࡮ࡣࡩࡻ࡮ࢀࡡࡳࡦࠪࣙ"))
        l11l11lFuck_You_Anonymous = xbmc.translatePath(l111l1Fuck_You_Anonymous (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠵ࡡࡥࡦࡲࡲࡸ࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡱࡲࡢࡶࡲࡷࠬࣚ"))
        if os.path.exists(l1l11llFuck_You_Anonymous):
                l11ll1Fuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"࡙࠭ࡰࡷࠣࡌࡦࡼࡥࠡࡋࡱࡷࡹࡧ࡬࡭ࡧࡧࠤࡋࡸ࡯࡮ࠢࡄࡲࠬࣛ")
                l11lllFuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠧࡖࡰࡲࡪ࡫࡯ࡣࡪࡣ࡯ࠤࡘࡵࡵࡳࡥࡨࠤࠫࠦࡗࡪ࡮࡯ࠤࡓࡵࡷࠡࡆࡨࡰࡪࡺࡥࠡࡒ࡯ࡩࡦࡹࡥࠨࣜ")
                l1l111Fuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࠢࡃ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡩࡶࡷࡴ࠿࠵࠯࡮ࡷࡦ࡯ࡾࡹ࠮࡮ࡧࡧ࡭ࡦࡶ࡯ࡳࡶࡤࡰ࠹ࡱ࡯ࡥ࡫࠱ࡱࡱࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࣝ")
                l1lFuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠩࡕࡩࡲࡵࡶࡦࡦࠣࡅࡳࡵ࡮ࡺ࡯ࡲࡹࡸࠦࡒࡦࡲࡲࠤࡆࡴࡤࠡࡃࡧࡨࡴࡴࡳࠨࣞ")
                l1l1l1Fuck_You_Anonymous = l111l1Fuck_You_Anonymous (u"ࠪࡗࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠢࡓࡰࡪࡧࡳࡦࠢࡇࡳࡳࡺࠠࡔࡷࡳࡴࡴࡸࡴࠡࡋࡧ࡭ࡴࡺࡳࠨࣟ")
                l11lll1Fuck_You_Anonymous.show_ok_dialog([l11ll1Fuck_You_Anonymous, l11lllFuck_You_Anonymous, l1l111Fuck_You_Anonymous], l1ll1llFuck_You_Anonymous)
                l1l1Fuck_You_Anonymous = l11lll1Fuck_You_Anonymous.get_path()
                shutil.rmtree(l1l1Fuck_You_Anonymous, ignore_errors=True)
                shutil.rmtree(l1l11llFuck_You_Anonymous, ignore_errors=True)
                shutil.rmtree(l1l1l1lFuck_You_Anonymous, ignore_errors=True)
                shutil.rmtree(l11l11lFuck_You_Anonymous, ignore_errors=True)
                l11lll1Fuck_You_Anonymous.log(l111l1Fuck_You_Anonymous (u"ࠫࡂࡃ࠽ࡅࡇࡏࡉ࡙ࡏࡎࡈ࠿ࡀࡁࡆࡔࡏࡏ࡛ࡐࡓ࡚࡙࠽࠾࠿ࡄࡈࡉࡕࡎࡔ࠿ࡀࡁ࠰ࡃ࠽࠾ࡔࡈࡔࡔࡃ࠽࠾ࠩ࣠"))
                l11lll1Fuck_You_Anonymous.show_ok_dialog([l1lFuck_You_Anonymous, l1l1l1Fuck_You_Anonymous], l1ll1llFuck_You_Anonymous)
                time.sleep(2)
                os._exit(0)
md.check_source()
mode = md.args[l111l1Fuck_You_Anonymous (u"ࠬࡳ࡯ࡥࡧࠪ࣡")]
url = md.args.get(l111l1Fuck_You_Anonymous (u"࠭ࡵࡳ࡮ࠪ࣢"), None)
name = md.args.get(l111l1Fuck_You_Anonymous (u"ࠧ࡯ࡣࡰࡩࣣࠬ"), None)
query = md.args.get(l111l1Fuck_You_Anonymous (u"ࠨࡳࡸࡩࡷࡿࠧࣤ"), None)
title = md.args.get(l111l1Fuck_You_Anonymous (u"ࠩࡷ࡭ࡹࡲࡥࠨࣥ"), None)
year = md.args.get(l111l1Fuck_You_Anonymous (u"ࠪࡽࡪࡧࡲࠨࣦ"), None)
l1111lFuck_You_Anonymous = md.args.get(l111l1Fuck_You_Anonymous (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫࣧ"), None)
l11l1llFuck_You_Anonymous = md.args.get(l111l1Fuck_You_Anonymous (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭ࣨ") ,None)
l11ll11Fuck_You_Anonymous = md.args.get(l111l1Fuck_You_Anonymous (u"࠭ࡩ࡯ࡨࡲࡰࡦࡨࡥ࡭ࣩࠩ"), None)
content = md.args.get(l111l1Fuck_You_Anonymous (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ࣪"), None)
l1l11Fuck_You_Anonymous = md.args.get(l111l1Fuck_You_Anonymous (u"ࠨ࡯ࡲࡨࡪࡥࡩࡥࠩ࣫"), None)
l1l11lFuck_You_Anonymous = md.args.get(l111l1Fuck_You_Anonymous (u"ࠩ࡬ࡧࡴࡴࡩ࡮ࡣࡪࡩࠬ࣬"), None)
fan_art = md.args.get(l111l1Fuck_You_Anonymous (u"ࠪࡪࡦࡴ࡟ࡢࡴࡷ࣭ࠫ"), None)
is_folder = md.args.get(l111l1Fuck_You_Anonymous (u"ࠫ࡮ࡹ࡟ࡧࡱ࡯ࡨࡪࡸ࣮ࠧ"), True)
if mode is None or url is None or len(url)<1:
	l1111llFuck_You_Anonymous()
elif mode == l111l1Fuck_You_Anonymous (u"ࠬ࠷࣯ࠧ"):
	l1Fuck_You_Anonymous(url,content)
elif mode == l111l1Fuck_You_Anonymous (u"࠭࠲ࠨࣰ"):
	l11lFuck_You_Anonymous(title, url,l1l11lFuck_You_Anonymous,content,l1111lFuck_You_Anonymous)
elif mode == l111l1Fuck_You_Anonymous (u"ࠧ࠴ࣱࠩ"):
	l1l1111Fuck_You_Anonymous(url)
elif mode == l111l1Fuck_You_Anonymous (u"ࠨ࠶ࣲࠪ"):
	l1ll1l1Fuck_You_Anonymous(url,name,content,fan_art,l11ll11Fuck_You_Anonymous)
elif mode == l111l1Fuck_You_Anonymous (u"ࠩࡶࡩࡦࡸࡣࡩࠩࣳ"):
	l1lll1Fuck_You_Anonymous(content, query)
elif mode == l111l1Fuck_You_Anonymous (u"ࠪࡥࡩࡪ࡯࡯ࡡࡶࡩࡦࡸࡣࡩࠩࣴ"):
	md.addon_search(content,query,fan_art,l11ll11Fuck_You_Anonymous)
elif mode == l111l1Fuck_You_Anonymous (u"ࠫࡦࡪࡤࡠࡴࡨࡱࡴࡼࡥࡠࡨࡤࡺࠬࣵ"):
	md.add_remove_fav(name,url,l11ll11Fuck_You_Anonymous,fan_art,
			  content,l1l11Fuck_You_Anonymous,is_folder)
elif mode == l111l1Fuck_You_Anonymous (u"ࠬ࡬ࡥࡵࡥ࡫ࡣ࡫ࡧࡶࡴࣶࠩ"):
	md.fetch_favs(l1llFuck_You_Anonymous)
elif mode == l111l1Fuck_You_Anonymous (u"࠭ࡡࡥࡦࡲࡲࡤࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧࣷ"):
	l11lll1Fuck_You_Anonymous.show_settings()
elif mode == l111l1Fuck_You_Anonymous (u"ࠧ࡮ࡧࡷࡥࡤࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧࣸ"):
	import metahandler
	metahandler.display_settings()
l11lll1Fuck_You_Anonymous.end_of_directory()