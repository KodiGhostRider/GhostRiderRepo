# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import json,re

def get_page(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.content,'html.parser')
    showsList = []
    for link in soup.find('div',{'class':'panel red'}).findAll('span',{'class':'text'}):
        try:
            showsList.append({'title':link.text,'url':link.parent.get('href'),'image':link.parent.img.get('src')})     
        except:
            continue
    return showsList

def getEpisode(url):
    r = requests.get(url)
    soup = BeautifulSoup(r.text,'html.parser')
    dvi = soup.find('video').get('data-video-id')
    da = soup.find('video').get('data-account')

    return getVideo(da,dvi)

def getVideo(da,dvi):
                
        headers = {
                'Accept': 'application/json;pk=BCpkADawqM2Iex_b1WSK2quDwI8rzeJpxe1cA0RwpDEY17exErxs1Adnvf7j-PKUj9FI8tihvMonKjBIBcBGLij2stKlQW241mZpYKa4d9L9lrmao59EDzbVbx6NGYkc-Zay3zWMPGdrOo-i'
            }
        
        html = requests.get('https://edge.api.brightcove.com/playback/v1/accounts/'+da+'/videos/'+dvi,headers=headers)

        a = json.loads(html.content)
        try:
             return a['sources'][1]['src']

        except:
             pass