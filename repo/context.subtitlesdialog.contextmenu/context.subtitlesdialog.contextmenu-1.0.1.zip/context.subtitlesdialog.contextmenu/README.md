# context.subtitlesdialog.contextmenu
Adds a subtitles dialog contextmenu button
