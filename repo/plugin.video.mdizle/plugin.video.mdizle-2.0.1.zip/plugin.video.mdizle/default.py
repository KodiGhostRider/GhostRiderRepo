import xbmc,xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs
import base64,os,re,requests,shutil,urllib
from addon.common.addon import Addon
from metahandler import metahandlers

#if sys.version_info >= (2,7):
        #from collections import OrderedDict
#else:
        #from resources.lib.ordereddict import OrderedDict
        

#IZLE Add-on Created By Mucky Duck (2/2016) And Recoded With A New Source(8/2016)

User_Agent = 'Mozilla/5.0 (compatible; MSIE 9.0; Windows Phone OS 7.5; Trident/5.0; IEMobile/9.0'
#User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.mdizle'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon_name = selfAddon.getAddonInfo('name')
addon = Addon(addon_id, sys.argv)
art = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
icon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
metaset = selfAddon.getSetting('enable_meta')
metaget = metahandlers.MetaData()
baseurl = 'http://itvmovie.se'
s = requests.session()




def CAT():
        addDir('[B][COLOR white]Recently Added Movies[/COLOR][/B]',baseurl+'/movie',1,icon,fanart,'')
        addDir('[B][COLOR white]Recently Added Shows[/COLOR][/B]',baseurl+'/tv-show',1,icon,fanart,'')
        addDir('[B][COLOR white]TV-Show Genres[/COLOR][/B]',baseurl,4,icon,fanart,'')
        addDir('[B][COLOR white]Movie Genres[/COLOR][/B]',baseurl,3,icon,fanart,'')
        addDir('[B][COLOR white]Most Watched[/COLOR][/B]',baseurl+'/most-watched',1,icon,fanart,'')
        addDir('[B][COLOR white]Country[/COLOR][/B]',baseurl,5,icon,fanart,'')
        addDir('[B][COLOR white]Search[/COLOR][/B]','url',7,icon,fanart,'')
        addDir('[B][COLOR white]Year[/COLOR][/B]',baseurl,6,icon,fanart,'')




def INDEX(url):
        link = OPEN_URL(url)
        link = link.replace('\t','').replace('\n','')
        all_videos = regex_get_all(link, 'col-xs-12">', '</div>                </div>')
        items = len(all_videos)
        for a in all_videos:
                name = regex_from_to(a, 'class="name" href=.*?>', '</')
                name = addon.unescape(name)
                name = name.encode('ascii', 'ignore').decode('ascii')
                url = regex_from_to(a, 'href="', '"')
                thumb = regex_from_to(a, 'src="', '"')
                qual = regex_from_to(a, '"quality.*?">', '</')
                qual = qual.replace('/','').replace('<strong>','').replace('<','').replace('None','').strip()
                if metaset=='true':
                        if 'EPS' in qual:
                                addDir3('[B][COLOR white]%s[/COLOR] [I][COLOR forestgreen](%s)[/COLOR][/I][/B]' %(name,qual),url,2,thumb,items,'',name)
                        elif 'Season' in qual:
                                addDir3('[B][COLOR white]%s[/COLOR] [I][COLOR forestgreen](%s)[/COLOR][/I][/B]' %(name,qual),url,2,thumb,items,'',name)
                        else:
                                addDir2('[B][COLOR white]%s[/COLOR] [I][COLOR forestgreen](%s)[/COLOR][/I][/B]' %(name,qual),url,9,thumb,items)
                else:
                        if 'Ep'in qual:
                                addDir('[B][COLOR white]%s[/COLOR] [I][COLOR forestgreen](%s)[/COLOR][/I][/B]' %(name,qual),url,2,thumb,fanart,'')
                        elif 'Season' in qual:
                                addDir('[B][COLOR white]%s[/COLOR] [I][COLOR forestgreen](%s)[/COLOR][/I][/B]' %(name,qual),url,2,thumb,fanart,'')
                        else:
                                addDir('[B][COLOR white]%s[/COLOR] [I][COLOR forestgreen](%s)[/COLOR][/I][/B]' %(name,qual),url,9,thumb,fanart,'')
        np = re.compile('<a class="pagenav" href="(.*?)">(.*?)</a>').findall(link)
        for url, name in np:
                if '&gt;' in name:
                        addDir('[I][B][COLOR forestgreen]Go To Next Page>>>[/COLOR][/B][/I]',url,1,icon,fanart,'')
        setView('movies', 'index-view')




def EP(name,url,iconimage,show_title):
        if iconimage == None:
                iconimage = icon
        link = OPEN_URL(url)
        if 'class="active" type="embed|drive.google"' in link:
                name = name.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
                all_links = regex_get_all(link, '</i> Server Vip </label>', '</div>')
                all_videos = regex_get_all(str(all_links), '<a', '/a>')
                items = len(all_videos)
                for a in all_videos:
                        name = regex_from_to(a, '">', '<')
                        url = regex_from_to(a, 'href="', '"')
                        if metaset=='true':
                                addDir3('[I][B][COLOR forestgreen]Episode: [/COLOR][/B][/I][B][COLOR white]%s[/COLOR][/B]' %name,url,10,iconimage,items,'',show_title)
                        else:
                                addDir('[I][B][COLOR forestgreen]Episode: [/COLOR][/B][/I][B][COLOR white]%s[/COLOR][/B]' %name,url,10,iconimage,fanart,'')
        setView('tvshows', 'ep-view')




def MGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<li  id="menu-item-.*?"><a href="(.*?)".*?>(.*?)</a></li>').findall(link)
        #match = list(OrderedDict.fromkeys(match))
        for url,name in match:
                if '-movie' in url:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,fanart,'')




def TGENRE(url):
        link = OPEN_URL(url)
        match=re.compile('<li  id="menu-item-.*?"><a href="(.*?)".*?>(.*?)</a></li>').findall(link)
        #match = list(OrderedDict.fromkeys(match))
        for url,name in match:
                if '-tv-shows' in url:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,fanart,'')




def COUNTRY(url):
        link = OPEN_URL(url)
        match=re.compile('<li  id="menu-item-.*?"><a href="(.*?)".*?>(.*?)</a></li>').findall(link)
        #match = list(OrderedDict.fromkeys(match))
        for url,name in match:
                if '/country/' in url:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,fanart,'')




def YEAR(url):
        link = OPEN_URL(url)
        match=re.compile('<li  id="menu-item-.*?"><a href="(.*?)".*?>(.*?)</a></li>').findall(link)
        #match = list(OrderedDict.fromkeys(match))
        for url,name in match:
                if '/release/' in url:
                        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,1,icon,fanart,'')




def SEARCH():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','+')
                url = baseurl+'/search/movie='+search
                INDEX(url)




def RESOLVE(name,url,iconimage):
        link = OPEN_URL(url)
        try:
                match = re.compile('var params = "lnk=(.*?)&type=embed').findall(link)[0]
                if match == '':
                        match = re.compile('var params = "lnk=(.*?)&type').findall(link)[1]
                match = base64.b64decode(match)
                match = re.split(r"/view", str(match), re.I)[0] + '/preview'
                headers = {'User-Agent':User_Agent}
                link = requests.get(match, headers=headers,allow_redirects=False, verify=False).text
                match=re.compile('"url_encoded_fmt_stream_map","itag\\\u003d.*?\\\u0026url\\\u003d(.*?)%3B').findall(link)[0]
                url = urllib.unquote(match)
                url = url.replace('\\u003d','=').replace('\\u0026','&')#.replace('video/x-flv','video/mp4')
                if 'video/x-flv' in url:
                        url = url.partition('url=')[2]
        except:
                vid = re.compile('href="(.*?)".*?type="embed\|.*?\.google">').findall(link)[1]
                link2 = OPEN_URL(vid)
                match = re.compile('var params = "lnk=(.*?)\&type=(.*?)"').findall(link2)
                for param1, param2 in match:
                        form_data = {'lnk': param1, 'type': param2}
                request_url = baseurl + '/ajax/player'
                headers = {'origin': baseurl, 'referer': vid, 'user-agent':User_Agent,'x-requested-with':'XMLHttpRequest'}
                link3 = s.post(request_url, data=form_data, headers=headers, allow_redirects=False).text
                try:
                        url = re.compile('"file":"(.*?)"').findall(link3)[-1]
                except:
                        url = re.compile('"file":"(.*?)"').findall(link3)[0]
                #headers = {'referer': vid, 'user-agent':User_Agent}
                #final_link = requests.get(request_url2, headers=headers, allow_redirects=False)
                #url = final_link.headers['Location']
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




'''def RESOLVE(name,url,iconimage):
        link = OPEN_URL(url)
        try:
                vid = re.compile('href="(.*?)".*?type="embed\|.*?\.google">').findall(link)[0]
                link2 = OPEN_URL(vid)
                match = re.compile('var params = "lnk=(.*?)\&type=(.*?)"').findall(link2)
                for param1, param2 in match:
                        form_data = {'lnk': param1, 'type': param2}
                request_url = baseurl + '/ajax/player'
                headers = {'origin': baseurl, 'referer': vid, 'user-agent':User_Agent,'x-requested-with':'XMLHttpRequest'}
                link3 = s.post(request_url, data=form_data, headers=headers, allow_redirects=False).text
                try:
                        request_url2 = re.compile('<source src="(.*?)"').findall(link3)[-1]
                except:
                        request_url2 = re.compile('<source src="(.*?)"').findall(link3)[0]
                headers = {'referer': vid, 'user-agent':User_Agent}
                final_link = requests.get(request_url2, headers=headers, allow_redirects=False)
                url = final_link.headers['Location']
        except:
                vid = re.compile('href="(.*?)".*?type="embed\|.*?\.google">').findall(link)[1]
                link2 = OPEN_URL(vid)
                match = re.compile('var params = "lnk=(.*?)\&type=(.*?)"').findall(link2)
                for param1, param2 in match:
                        form_data = {'lnk': param1, 'type': param2}
                request_url = baseurl + '/ajax/player'
                headers = {'origin': baseurl, 'referer': vid, 'user-agent':User_Agent,'x-requested-with':'XMLHttpRequest'}
                link3 = s.post(request_url, data=form_data, headers=headers, allow_redirects=False).text
                try:
                        request_url2 = re.compile('<source src="(.*?)"').findall(link3)[-1]
                except:
                        request_url2 = re.compile('<source src="(.*?)"').findall(link3)[0]
                headers = {'referer': vid, 'user-agent':User_Agent}
                final_link = requests.get(request_url2, headers=headers, allow_redirects=False)
                url = final_link.headers['Location']
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)'''




def RESOLVE2(name,url,iconimage):
        link = OPEN_URL(url)
        referer = url
        try:
                match = re.compile('var params = "lnk=(.*?)&type=embed').findall(link)[0]
                if match == '':
                        match = re.compile('var params = "lnk=(.*?)&type').findall(link)[1]
                match = base64.b64decode(match)
                match = re.split(r"/view", str(match), re.I)[0] + '/preview'
                headers = {'User-Agent':User_Agent}
                link = requests.get(match, headers=headers,allow_redirects=False, verify=False).text
                match=re.compile('"url_encoded_fmt_stream_map","itag\\\u003d.*?\\\u0026url\\\u003d(.*?)%3B').findall(link)[0]
                url = urllib.unquote(match)
                url = url.replace('\\u003d','=').replace('\\u0026','&')#.replace('video/x-flv','video/mp4')
                if 'video/x-flv' in url:
                        url = url.partition('url=')[2]
        except:
                match = re.compile('var params = "lnk=(.*?)\&type=(.*?)"').findall(link)
                for param1, param2 in match:
                        form_data = {'lnk': param1, 'type': param2}
                request_url = baseurl + '/ajax/player'
                headers = {'origin': baseurl, 'referer': referer, 'user-agent':User_Agent,'x-requested-with':'XMLHttpRequest'}
                link3 = s.post(request_url, data=form_data, headers=headers, allow_redirects=False).text
                try:
                        url = re.compile('"file":"(.*?)"').findall(link3)[-1]
                except:
                        url = re.compile('"file":"(.*?)"').findall(link3)[0]
                #headers = {'referer': vid, 'user-agent':User_Agent}
                #final_link = requests.get(request_url2, headers=headers, allow_redirects=False)
                #url = final_link.headers['Location']'''
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={"Title":name,"Plot":description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)




def regex_from_to(text, from_string, to_string, excluding=True):
        if excluding:
                try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
                except: r = ''
        else:
                try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
                except: r = ''
        return r




def regex_get_all(text, start_with, end_with):
        r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
        return r




def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addDir(name,url,mode,iconimage,fanart,description):
        name = name.replace('()','')
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title":name,"Plot":description})
        liz.setProperty('fanart_image', fanart)
        if mode==9 or mode==10:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok




def PT(url):
        addon.log('Play Trailer %s' % url)
        notification( addon.get_name(), 'fetching trailer', addon.get_icon())
        xbmc.executebuiltin("PlayMedia(%s)"%url)




def notification(title, message, icon):
        addon.show_small_popup( addon.get_name(), message.title(), 5000, icon)
        return




def addDir2(name,url,mode,iconimage,itemcount):
        title = name.replace('[B][COLOR white]','').partition('[/COLOR]')[0].strip()
        meta = metaget.get_meta('movie',title)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        meta['title'] = name
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        contextMenuItems = []
        contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
        if meta['trailer']:
                contextMenuItems.append(('Play Trailer', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 8, 'url':meta['trailer']})))
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else: liz.setProperty('fanart_image', fanart)
        if mode==9 or mode==10:
            liz.setProperty("IsPlayable","true")
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
             ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok




def addDir3(name,url,mode,iconimage,itemcount,description,show_title):
        show_title = show_title.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
        try:
                show_title = re.split(r"\(", str(show_title), re.I)[0]
        except: pass
        try:
                show_title = re.split(r" Season ", str(show_title), re.I)[0]
        except: pass
        try:
                show_title = re.split(r"[I]", str(show_title), re.I)[0]
        except: pass
        meta = metaget.get_meta('tvshow',show_title)
        if meta['cover_url']=='':
            try:
                meta['cover_url']=iconimage
            except:
                meta['cover_url']=icon
        meta['title'] = name
        contextMenuItems = []
        contextMenuItems.append(('TV Show Info', 'XBMC.Action(Info)'))
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&show_title="+urllib.quote_plus(show_title)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        liz.setInfo( type="Video", infoLabels= meta )
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        if not meta['backdrop_url'] == '':
                liz.setProperty('fanart_image', meta['backdrop_url'])
        else:
                liz.setProperty('fanart_image', fanart)
        if mode==9 or mode==10:
                liz.setProperty("IsPlayable","true")
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=itemcount)
        else:
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=itemcount)
        return ok
        



def addLink(name,url,mode,iconimage,fanart,description=''):
        #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)
        #ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok




def OPEN_URL(url):
        headers = {}
        headers['User-Agent'] = User_Agent
        link = s.get(url, headers=headers, allow_redirects=False).text
        link = link.encode('ascii', 'ignore').decode('ascii')
        return link





def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'Default View':
            VT = addon.get_setting('default-view')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )




params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None
show_title=None




try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass

try:
        show_title=urllib.unquote_plus(params["show_title"])
except:
        pass




if mode==None or url==None or len(url)<1:
        CAT()

elif mode==1:
        INDEX(url)

elif mode==2:
        EP(name,url,iconimage,show_title)

elif mode==3:
        MGENRE(url)

elif mode==4:
        TGENRE(url)

elif mode==5:
        COUNTRY(url)

elif mode==6:
        YEAR(url)

elif mode==7:
        SEARCH()

elif mode==8:
        PT(url)

elif mode==9:
        RESOLVE(name,url,iconimage)

elif mode==10:
        RESOLVE2(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































if xbmcvfs.exists(xbmc.translatePath('special://home/userdata/sources.xml')):
        with open(xbmc.translatePath('special://home/userdata/sources.xml'), 'r+') as f:
                my_file = f.read()
                if re.search(r'http://muckys.mediaportal4kodi.ml', my_file):
                        addon.log('Muckys Source Found in sources.xml, Not Deleting.')
                else:
                        line1 = "you have Installed The MDrepo From An"
                        line2 = "Unofficial Source And Will Now Delete Please"
                        line3 = "Install From [COLOR red]http://muckys.mediaportal4kodi.ml[/COLOR]"
                        line4 = "Removed Repo And Addon"
                        line5 = "successfully"
                        xbmcgui.Dialog().ok(addon_name, line1, line2, line3)
                        delete_addon = xbmc.translatePath('special://home/addons/'+addon_id)
                        delete_repo = xbmc.translatePath('special://home/addons/repository.mdrepo')
                        shutil.rmtree(delete_addon, ignore_errors=True)
                        shutil.rmtree(delete_repo, ignore_errors=True)
                        dialog = xbmcgui.Dialog()
                        addon.log('===DELETING===ADDON+===REPO===')
                        xbmcgui.Dialog().ok(addon_name, line4, line5)








































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































