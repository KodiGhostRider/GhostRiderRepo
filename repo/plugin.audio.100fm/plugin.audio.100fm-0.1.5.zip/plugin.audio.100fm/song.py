class Song(object):
    def __init__(self, picture, artist, title, url):
        self.picture = picture
        self.artist = artist
        self.title = title
        self.url = url