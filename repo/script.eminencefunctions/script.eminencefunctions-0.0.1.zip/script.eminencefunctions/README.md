Used by the Eminence skin for various home screen customisation functions
