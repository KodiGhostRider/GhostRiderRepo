# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/GoProCamera
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc
import xbmcaddon
import xbmcgui
import json

start_index = 1
amount = 30
cats = []


def add_cat(name, playlist_id,thumbnail_img):
	# code for selecting a random img thumbnail from youtube playlist
	#cat_url="http://gdata.youtube.com/feeds/api/playlists/"+ playlist_id + "/?max-results=1"
	#cat_thumbnail=""
	#try:
	#	data = plugintools.read(cat_url)
	#	cat_match = plugintools.find_multiple_matches(data,"<entry>(.*?)</entry>")
	#	for entry in cat_match:
	#		cat_thumbnail = plugintools.find_single_match(entry,"<media\:thumbnail url='([^']+)'")
	#		if cat_thumbnail !="":
	#			continue
	#except Exception as e:
	#	cat_thumbnail="http://www.felix007.com/wp-content/uploads/404.jpg"
	ADDON = xbmcaddon.Addon(id='plugin.video.kodisraelkids')
	THUMBNAIL = os.path.join( ADDON.getAddonInfo( 'path' ),"img", thumbnail_img)
	plugintools.add_item( action="main_list" , title=name , url="?pid=" + playlist_id + "&start-index=1&max-results=30" ,thumbnail=THUMBNAIL , folder=True )
	cats.append(playlist_id);

# Entry point
def run():
	plugintools.log("UCHaEhu1lOjCfHSHg_R2dpkg.run")
	
	# Get params
	params = plugintools.get_params()
	
	if params.get("action") is None:
		category_list(params)
	elif params.get("action")=="main_list":
		main_list(params)
	else:
		plugintools.log("ACTION: " + params.get("action"))
		action = params.get("action")
		exec action + "(params)"
	
	plugintools.close_item_list()

def play_playlist(params):
	#plugintools.log("PLAYLSIT LENGTH: " + str(len(playlist)))
	xbmc.Player(xbmc.PLAYER_CORE_MPLAYER).play(playlist)
	
	
# Categories
def category_list(params):
	add_cat("סמי הכבאי", "PL_TbWUH2U7KmZtYRZlJtxzmYFP_m81vSk","1 (29).jpg")
	add_cat("רינת ויויו", "PLVisQUXwii8qa6lRDe1OmCIup6ylcprfc","1 (40).jpg")
	add_cat("פסטיגל", "PLwimDnICcPKPL4MdOLIQrGDMTOAshuQ2l","1 (32).jpg")
	add_cat("מיקי", "PLwimDnICcPKP4vFp6zklqeNUSdq08mN1H","1 (20).jpg")
	add_cat("מר עגבניה", "PLwimDnICcPKMSeyub1DLM_2jG4aPjqI7n","1 (21).jpg")
	add_cat("לולי", "PLwimDnICcPKNQy5TSz2s5XKWsE6kKV5C1","1 (17).jpg")
	add_cat("סופר סטרייקה", "PLU6_PRY_7y1TQMr67fJ6WC2mzkqtVyU3B","1 (27).jpg")
	add_cat("דורימון", "PL95CWWe9DuaJ6xtv1V8ZxDvoG_cB3z4bc","1 (6).jpg")
	add_cat("שירי ילדים", "PLFw7KwIWHNB03yaEG6T08Mg7haNKv673e","17.jpg")
	add_cat("מיכל הקטנה", "PLTNonj9ImqaKElCJ-4e8X_3BzXvzEYU_0","1 (19).jpg")
	add_cat("הדוד חיים", "PLTNonj9ImqaIuFt2AyqdYFx6bCnKoFsIc","1 (8).jpg")
	add_cat("פים ופימבה", "PLTNonj9ImqaI2F7DHlMxZ3VDn8gwpaTKe","1 (31).jpg")
	add_cat("קופיקו", "PLQj4MAw08GNjVRSCvC8qbpjq0y6Zsfpho","1 (36).jpg")
	add_cat("הלו קיטי", "PL-_BcMXVkaspyjwz7S5Hs_Rgih0F1d8_d","1 (12).jpg")
	add_cat("שירים ישראלים לילדים ערוץ בייבי", "PLErYJg2XgxyXTMAJvmFXoW6Qe66Ztw0Fk","15.jpg")
	add_cat("אוצר מילים עם נוני", "PLErYJg2XgxyXmgk6cyROtlJh2g-Fk_T6n","1 (1).jpg")
	add_cat("מתכוננים לשינה ערוץ בייבי", "PLErYJg2XgxyVYzsbPxH2dzhlWLs9sWGTa","1 (24).jpg")
	add_cat("חיות בערוץ לולי", "PLTleo-h9TFqI2CFuWeFA-Q2Bu3BBHdXqv","1 (16).jpg")
	add_cat("סיפורי התנכ עם סבא טוביה", "PL6jaO-hu0IvwHsU9bzS8caFo8reAxEseX","1 (28).jpg")
	add_cat("סיפורים לילדים מרים רות", "PL6jaO-hu0Ivzi0gndI5Rb6YYcqut13wlD","16.jpg")
	add_cat("בארץ הקטקטים", "PLR7DTcU2p0Qg5sF-jE09YnRymKba8N8l_","1 (2).jpg")
	add_cat("משטרת האגדות", "PLR7DTcU2p0QiaEmc56lGHMpxW4ladE93X","11.jpg")
	add_cat("המעופפים הנועזים", "PLR7DTcU2p0QhYwFJuI0zFXFmAN-q6n4A0","1 (14).jpg")
	add_cat("וולברין והאקס מן", "PLR7DTcU2p0QhGsv3LuA3GnCJWjoPBCafl","1 (15).jpg")
	add_cat("הצגות ומופעים", "PLFw7KwIWHNB2xJnDoV8Us1tbWnFyvxkWO","12.jpg")
	add_cat("הדרדסים", "PLo3vmw8N0knb9tZuIy7AR9fMPTUzr1oiI","1 (9).jpg")
	add_cat("קטני", "PLbHXbhgZi5cL97NlobjLHNtBwIA9VHcmw","1 (37).jpg")
	add_cat("שרגא בישגדא", "PL51YAgTlfPj5KPYOntZkqg2Nwyqj2M1Lf","1 (43).jpg")
	add_cat("מיטב השירים פרפר נחמד", "PL51YAgTlfPj45OPEXI-ibfJy8ON0k1ARh","1 (34).jpg")
	add_cat("קשת וענן", "PL51YAgTlfPj6qcpdP7e44dNj7xHuwd3oo","1 (38).jpg")
	add_cat("בלי סודות", "PL51YAgTlfPj5Alk2qONbzihcO1FVF1irZ","1 (4).jpg")
	add_cat("רגע עם דודלי", "PL51YAgTlfPj5gUK-SIhbYyAMUQASzrZAw","1 (39).jpg")
	add_cat("חגי תשרי", "PL51YAgTlfPj4LOZbA2VzFPUTkheKOlmaE","33.gif")
	add_cat("פיטר פן", "PL_8KXLhQVQMIMJ_lQkl0Z393wwTtRgg_i","1 (30).jpg")
	add_cat("שאלתיאל קוואק", "PL_8KXLhQVQMKOtRoV1SuOu95dvVo-ea2J","1 (41).jpg")
	add_cat("המומינים", "PLFw7KwIWHNB0auE2_BrBLV-j0YgMPPKLO","1 (13).jpg")
	add_cat("נאנוק", "PL_8KXLhQVQMJJ4nHubadbykzbHhzzmUPu","1 (25).jpg")
	add_cat("פינגווינים", "PL_8KXLhQVQMIkR9iafygY0ztBUPSAyUki","13.png")
	add_cat("בוב הבנאי", "PL_8KXLhQVQMK80XCn7g3qVj7RwhrwiGHG","1 (3).jpg")
	add_cat("נילס הולגרסון", "PL_8KXLhQVQMKVZInMgWpGe9osYlO5lcBa","1 (26).jpg")
	add_cat("הלב מרקו", "PL_8KXLhQVQMLx3W2W6YXTmaNHoPmlLl28","1 (11).jpg")
	add_cat("שלגיה ושבעת הגמדים", "PL_8KXLhQVQMKKrMMm0glr1TMQoxCjFuTk","1 (42).jpg")
	add_cat("שלדון", "PL_8KXLhQVQMLzs0EHUhG_9PwxVsFgDAo4","14.jpg")
	add_cat("מולי וצומי", "PLfcYs4SRZfuJHmb8y_BpUpzAsm1guoAlK","1 (18).jpg")
	add_cat("מרתה מדברת", "PL_8KXLhQVQMLtfN5bkh11lSA6Awg5rt9y","1 (22).jpg")
	add_cat("צארלי ולולה", "PL_8KXLhQVQMKNHw4ES_lX1AtkkgN5wyeM","1 (35).jpg")
	add_cat("פרפר נחמד", "PL51YAgTlfPj7XTzORdSrWpgCfF1x7ZUeK","1 (33).jpg")
	add_cat("הורים וגורים", "PL51YAgTlfPj5sp5nUKFuwuUddCXYjiH8F","1 (10).jpg")
	add_cat("צור משלנו", "PLtz5gfkQ59bJw2o_B23A_Pb1ooaHq3-tj","18.jpg")
	add_cat("ילדים מספרים", "PLtz5gfkQ59bLK0Tlj7SsTPrhkPEqmwMnb","19.jpg")
	add_cat("אבות ובנים", "PLtz5gfkQ59bKit3qn_F3HVyZvVIjFfgc5","20.jpg")
	add_cat("גלילאו", "PLFw7KwIWHNB14v2w1rx_drmWtZPldqgtp","21.jpg")
	add_cat("החפרנים", "PLFw7KwIWHNB2JjD4-z7-2vZ3Ku6HtYc2U","22.jpg")
	add_cat("נינג'גו", "PL92EMTBYUH-FoPVTqddFyLgv0-J8Kl6By","24.jpg")
	add_cat("צימה", "PLbxDa3eoPYlIX41Rp9Q1pFljdfy2at8IK","25.jpg")
	add_cat("מיקי מאוס", "PLFw7KwIWHNB14Il3yEmYCImeXjUsuG_fR","26.jpg")
	add_cat("מאסה ומישקה", "PLBE_VtpC1cB8IsjeMynvNnmMxhrdYvn2E","27.jpg")
	add_cat("אותיות מצחיקות", "PL8yBWSFu2PVOlN83H6uWvmH4o1w5871Ws","28.jpg")
	add_cat("גברת פלפלת", "PL6BkF-3g8VpYUlrU-Agk3WUAONoOaI09E","34.jpg")
	add_cat("מר קו", "PL6BkF-3g8VpbfWb-7p-xPPzqPgkfgEQNK","29.jpg")
	add_cat("הזרבובים", "PLR7DTcU2p0QiY-wI8KC6f01uzKLDZcuAc","30.jpg")
	add_cat("דרגון בול זי", "PL92EMTBYUH-HCp123_rEC-Oth1DdDaHNY","31.jpg")
	add_cat("רוץ דייגו רוץ", "PLU6_PRY_7y1RvV72e1mLJHb3RJHiYXpqw","32.jpg")
	add_cat("סיירי החלל", "PLI-xvkzSH0O3sosLsIQkosPCOTorF0StO","33.jpg")
	add_cat("רובוט פולי", "PLsa30wWsZ_kCPrW5BBiFxckb7IBxiOvvs","34.jpg")
	add_cat("יובל המבולבל", "PLzAqQoYm2t2xi_8LMKWYVfW0DjchcSzv0","35.jpg")
	add_cat("זאק וקוואק", "PL_8KXLhQVQMJM70o-LA7S6ufWVvLCJF9m","36.png")
	add_cat("חבורת החצר", "PL59D8hwKyLW7DhR1gG_fJewwF4UClTVrm","37.jpg")
	add_cat("בומבה", "PLTleo-h9TFqLkb8a4Y9aeuZUH0W436ah7","38.jpg")
	add_cat("ברני וחברים", "PLFw7KwIWHNB3eIoqm8vLyYpVzxzOtHrK-","39.jpg")
	add_cat("פלישת הרבידים", "PLo69t7VQCjOHld0iP6VxBIfEdMWdeaSSu","40.jpg")
	add_cat("לימוד אנגלית", "PLqsYSvVJ2b7GhPj-_Xbx7okwcuO8nODHW","41.jpg")
	
	
playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
page_playlist = []
	
# Main menu
def main_list(params):
	global page_playlist
	plugintools.log("UCHaEhu1lOjCfHSHg_R2dpkg.main_list "+repr(params))
	
	# On first page, pagination parameters are fixed
	if params.get("url") is not None:
		pid = plugintools.find_single_match( params.get("url") ,"pid=(.+?)&")
		pageToken = plugintools.find_single_match( params.get("url") ,"pageToken=(.+)")
		max_results = plugintools.find_single_match( params.get("url") ,"max-results=(\d+)")

		p_url = "https://www.googleapis.com/youtube/v3/playlistItems?pageToken=" + pageToken + "&part=snippet,status&maxResults=" + max_results + "&playlistId=" + pid + "&key=AIzaSyDl9siqp_kPJ0WQelU20VaolNn2PKkTeeY"
		#p_url = "http://gdata.youtube.com/feeds/api/playlists/"+pid+"/?start-index=" + start_index + "&max-results=" + max_results
		plugintools.log("MYPID "+p_url)
		
# Fetch video list from YouTube feed
	data = plugintools.read( p_url )

	# Extract items from feed
	pattern = ""
	matches = plugintools.find_multiple_matches(data,"<entry>(.*?)</entry>")
	
	#"kind": "youtube#playlistItem"
	
	plugintools.add_item( action="play_playlist" , title="נגן את כל הפלייליסט" , url="", folder=False )	

	playlist.clear()
	
	parsed_json = json.loads(data)
	
	next_page_token = None
	try:
		next_page_token = parsed_json["nextPageToken"]
	except KeyError:
		next_page_token = None
		
	results = parsed_json["items"]
	#plugintools.log("LIST LENGTH: "+str(len(results)))
	
	for result in results:
		if result["status"]["privacyStatus"] != "public":
			continue
		
		# Not the better way to parse XML, but clean and easy
		title = result["snippet"]["title"]
		plot = result["snippet"]["description"]
		thumbnail = result["snippet"]["thumbnails"]["default"]["url"]
		video_id = result["snippet"]["resourceId"]["videoId"]
		
		
		
		url = "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+video_id

		liz = xbmcgui.ListItem(title, iconImage=thumbnail, thumbnailImage=thumbnail)
		liz.setInfo( type="Video", infoLabels={ "Title": title} )
		liz.setProperty("IsPlayable","true")
		playlist.add(url,liz)
		
		# Appends a new item to the xbmc item list
		plugintools.add_item( action="play" , title=title , plot=plot , url=url ,thumbnail=thumbnail , folder=True )
	
	# Calculates next page URL from actual URL
	if next_page_token is not None:
		if params.get("url") is not None:
			next_page_url = "?pid=" + pid + "&max-results=" + max_results + "&pageToken=" + next_page_token
			plugintools.add_item( action="main_list" , title="<< עמוד הבא" , url=next_page_url.decode().encode('utf-8'), folder=True )	

def play(params):
	plugintools.play_resolved_url( params.get("url") )

run()