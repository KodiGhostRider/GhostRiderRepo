#!/usr/bin/python

import xbmc, xbmcaddon, datetime, time

Addon = xbmcaddon.Addon()
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')
localizedString = Addon.getLocalizedString

def SleepFor(timeS):
    while((not xbmc.abortRequested) and (timeS > 0)):
        xbmc.sleep(1000)
        timeS -= 1

def SetTimer(delta):
	return datetime.datetime.now() + datetime.timedelta(seconds=delta)

print "*** {0}: Wall.Sync - Delay:{1}".format(AddonName,int(Addon.getSetting("StartDelay")))
if int(Addon.getSetting("StartDelay")) > 5:
	SleepFor(int(Addon.getSetting("StartDelay"))*60)
else:
	SleepFor(10)

START=True

# Interval in sec
wallInterval = 6*60*60

wallTimer = SetTimer(wallInterval)

while (not xbmc.abortRequested):
	timenow = SetTimer(1)
	
	if wallTimer < timenow or START:
		wallTimer = SetTimer(wallInterval)
		try:
			xbmc.executebuiltin('RunScript(plugin.video.thewiz.wall,0,wall=update)')
		except:
			pass

	START=False
	SleepFor(30*60)
