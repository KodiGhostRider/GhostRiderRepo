#!/usr/bin/python

import os, sys, urllib, json, re, shutil, glob, platform
import xbmcaddon, xbmcgui, xbmc, time, datetime, urllib2
import json

def upload_file(thewiz_log,kodi_log):
	try:
		thewiz_log = open(thewiz_log, 'r').read()
	except:
		thewiz_log = ''
	try:
		kodi_log = open(kodi_log, 'r').read()
	except:
		kodi_log = ''
		
	post_dict = {
		'api_option' : 'paste',
		'api_dev_key' :'f4cfed294688ed5dd40fb97f00c71c16',
		'api_paste_private':1,
		'api_paste_name': 'TheWiz Wall Logger',
		'api_paste_expire_date': '1M',
		'api_paste_format' : 'text',
		'api_user_key': '',
		'api_paste_code' : thewiz_log+"\n\n\n"+kodi_log,
	}
	req = urllib2.Request('http://pastebin.com/api/api_post.php', urllib.urlencode(post_dict))
	response = urllib2.urlopen(req).read()
	try:
		print "***** Log Upload {0}".format(response)
		return response
	except:
		print "***** Error Log Upload {0}".format(response)
		
def main():
	global AddonName,baseUrl,Addon,LOG,AddonVersion
	addonID = "plugin.video.thewiz.wall"
	Addon = xbmcaddon.Addon(addonID)
	AddonName = Addon.getAddonInfo("name")
	AddonPath = Addon.getAddonInfo("path")
	AddonVersion = Addon.getAddonInfo('version')

	thewiz_log = xbmc.translatePath(os.path.join("special://userdata/addon_data/plugin.video.thewiz.wall/", "thewiz.wall.log")).decode("utf-8")	
	kodi_log = xbmc.translatePath(os.path.join("special://home/", "kodi.log")).decode("utf-8")	
	logID = upload_file(thewiz_log,kodi_log)
	Addon.setSetting("UploadLog","false")
	if logID and len(logID) > 5:
		Addon.setSetting("LastLog",logID)
		dlg = xbmcgui.Dialog()
		dlg.ok('TheWiz Media Wall', 'Log File ID: {0}'.format(logID))
	addonFolder = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
	FileSetting = os.path.join(addonFolder,"settings.xml")
	BackupSetting = os.path.join(addonFolder,"library","settings.xml")
	shutil.copyfile(FileSetting,BackupSetting)

	sys.exit(1)