import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os , sys , re , urllib , urllib2 , random , net , base64
import pyxbmct . addonwindow as pyxbmct
from addon . common . addon import Addon
if 64 - 64: i11iIiiIii
net = net . Net ( )
OO0o = 'plugin.video.livemix'
Oo0Ooo = xbmcaddon . Addon ( id = OO0o )
O0O0OO0O0O0 = '/resources/Blue'
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + O0O0OO0O0O0 , 'power.png' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + O0O0OO0O0O0 , 'logo.png' ) ) ; file = open ( O00ooooo00 , 'r' ) ; I1IiiI = file . read ( )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + O0O0OO0O0O0 , 'logo2.png' ) ) ; file = open ( IIi1IiiiI1Ii , 'r' ) ; I11i11Ii = file . read ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + O0O0OO0O0O0 , 'power_focus.png' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + O0O0OO0O0O0 , 'button_focus1.png' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + O0O0OO0O0O0 , 'button_no_focus1.png' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o + O0O0OO0O0O0 , 'main-bg2.png' ) )
Oo0O = pyxbmct . AddonDialogWindow ( '' )
Oo0O . setGeometry ( 1240 , 650 , 100 , 50 )
IiI = pyxbmct . Image ( IiIi11iIIi1Ii )
Oo0O . placeControl ( IiI , - 5 , 0 , 125 , 51 )
ooOo = Addon ( OO0o , sys . argv )
Oo = ooOo . queries . get ( 'mode' , '' )
if 67 - 67: O00ooOO . I1iII1iiII
def iI1Ii11111iIi ( ) :
 global Africa
 global Canada
 global Germany
 global Denmark
 global Spain
 global France
 global Greece
 global Israel
 global India
 global Italy
 global Netherlands
 global Poland
 global Portugal
 global Romania
 global Russia
 global i1i1II
 global O0oo0OO0
 global List
 global Link
 if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
 #create butttons
 iiI1iIiI = '0xFF000000'
 Africa = pyxbmct . Button ( 'Africa' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Canada = pyxbmct . Button ( 'Canada' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Germany = pyxbmct . Button ( 'Germany' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Denmark = pyxbmct . Button ( 'Denmark' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Spain = pyxbmct . Button ( 'Spain' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 France = pyxbmct . Button ( 'France' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Greece = pyxbmct . Button ( 'Greece' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Israel = pyxbmct . Button ( 'Israel' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 India = pyxbmct . Button ( 'India' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Italy = pyxbmct . Button ( 'Italy' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Netherlands = pyxbmct . Button ( 'Netherlands' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Poland = pyxbmct . Button ( 'Poland' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Portugal = pyxbmct . Button ( 'Portugal' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Romania = pyxbmct . Button ( 'Romania' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Russia = pyxbmct . Button ( 'Russia' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 OOo = pyxbmct . Button ( 'UK' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 Ii1IIii11 = pyxbmct . Button ( 'USA' , focusTexture = OOOo0 , noFocusTexture = Oooo000o , textColor = iiI1iIiI , focusedColor = iiI1iIiI )
 List = pyxbmct . List ( buttonFocusTexture = OOOo0 , buttonTexture = Oooo000o , _space = 11 , _itemTextYOffset = - 7 , textColor = iiI1iIiI )
 Oooo0000 = pyxbmct . Button ( ' ' , noFocusTexture = II1 , focusTexture = oO00oOo )
 i11 = { 'User-Agent' : 'Mozilla/5.0 (Android 4.4; Mobile; rv:41.0) Gecko/41.0 Firefox/41.0' }
 Link = net . http_GET ( I11i11Ii , i11 ) . content
 Oo0Ooo . setSetting ( 'secstore' , 'CA' )
 if 41 - 41: O00o0o0000o0o . oOo0oooo00o * I1i1i1ii - IIIII
 if 26 - 26: O00OoOoo00 . iiiI11 / oooOOOOO * IiiIII111ii / i1iIIi1
 Oo0O . placeControl ( Canada , 20 , 5 , 6 , 10 )
 Oo0O . placeControl ( Germany , 25 , 5 , 6 , 10 )
 Oo0O . placeControl ( Denmark , 30 , 5 , 6 , 10 )
 Oo0O . placeControl ( France , 35 , 5 , 6 , 10 )
 if 50 - 50: IiIi1Iii1I1 - O00O0O0O0
 if 75 - 75: IIIiiiiiIii / oOOoO0 % O00OoOoo00
 if 70 - 70: O00o0o0000o0o % O00o0o0000o0o . O00O0O0O0 % oOo0oooo00o * IIIII % iiiI11
 Oo0O . placeControl ( Italy , 40 , 5 , 6 , 10 )
 Oo0O . placeControl ( Netherlands , 45 , 5 , 6 , 10 )
 if 23 - 23: i11iIiiIii + II1Ii1iI1i
 Oo0O . placeControl ( Portugal , 50 , 5 , 6 , 10 )
 Oo0O . placeControl ( Romania , 55 , 5 , 6 , 10 )
 Oo0O . placeControl ( Russia , 60 , 5 , 6 , 10 )
 Oo0O . placeControl ( Spain , 65 , 5 , 6 , 10 )
 Oo0O . placeControl ( OOo , 70 , 5 , 6 , 10 )
 Oo0O . placeControl ( Ii1IIii11 , 75 , 5 , 6 , 10 )
 Oo0O . placeControl ( List , 20 , 20 , 90 , 25 )
 Oo0O . placeControl ( Oooo0000 , 90 , 8 , 10 , 3 )
 if 68 - 68: I1i1i1ii . iiiI11 . i11iIiiIii
 if 40 - 40: iiiI11 . I1i1i1ii . O00o0o0000o0o . ooO0oo0oO0
 Oo0O . connectEventList (
 [ pyxbmct . ACTION_MOVE_DOWN ,
 pyxbmct . ACTION_MOVE_UP ,
 pyxbmct . ACTION_MOUSE_MOVE ] ,
 I11iii )
 if 54 - 54: oooOOOOO + oooOOOOO % IIIiiiiiIii % i11iIiiIii / I1iII1iiII . oooOOOOO
 if 57 - 57: i1iIIi1 % oooO0oo0oOOOO
 if 61 - 61: IiIi1Iii1I1 . I1iII1iiII * II1Ii1iI1i . oOOoO0 % O00o0o0000o0o
 if 72 - 72: oooOOOOO
 Canada . controlUp ( Ii1IIii11 )
 Canada . controlDown ( Germany )
 Germany . controlUp ( Canada )
 Germany . controlDown ( Denmark )
 Denmark . controlUp ( Germany )
 Denmark . controlDown ( France )
 France . controlUp ( Denmark )
 France . controlDown ( Italy )
 if 63 - 63: i1iIIi1
 if 86 - 86: oOOoO0 . II1Ii1iI1i % O00o0o0000o0o + IIIII
 if 35 - 35: I1iII1iiII % iiiI11 * IiiIII111ii % IiiIII111ii + i111I * IiIi1Iii1I1
 if 54 - 54: IiiIII111ii + O00O0O0O0 / IiIi1Iii1I1
 if 9 - 9: I1i1i1ii / O00o0o0000o0o - O00O0O0O0 . ooO0oo0oO0 / II1Ii1iI1i % O00O0O0O0
 if 71 - 71: IIIiiiiiIii . O00ooOO
 Italy . controlUp ( France )
 Italy . controlDown ( Netherlands )
 Netherlands . controlUp ( Italy )
 Netherlands . controlDown ( Portugal )
 if 73 - 73: oooOOOOO % I1i1i1ii - i1iIIi1
 if 10 - 10: II1Ii1iI1i % O00OoOoo00
 Portugal . controlUp ( Netherlands )
 Portugal . controlDown ( Romania )
 Romania . controlUp ( Portugal )
 Romania . controlDown ( Russia )
 Russia . controlUp ( Romania )
 Russia . controlDown ( Spain )
 Spain . controlUp ( Russia )
 Spain . controlDown ( OOo )
 OOo . controlUp ( Spain )
 OOo . controlDown ( Ii1IIii11 )
 Ii1IIii11 . controlUp ( OOo )
 Ii1IIii11 . controlDown ( Oooo0000 )
 Oooo0000 . controlUp ( Ii1IIii11 )
 Oooo0000 . controlDown ( Canada )
 List . controlLeft ( Canada )
 Oo0O . setFocus ( Canada )
 if 48 - 48: IiiIII111ii + IiiIII111ii / i111I / I1iII1iiII
 if 20 - 20: IIIII
 Oo0O . connect ( Africa , oO00 )
 Oo0O . connect ( Canada , ooo )
 Oo0O . connect ( Germany , ii1I1i1I )
 Oo0O . connect ( Denmark , OOoo0O0 )
 Oo0O . connect ( France , iiiIi1i1I )
 Oo0O . connect ( Greece , oOO00oOO )
 Oo0O . connect ( Israel , OoOo )
 Oo0O . connect ( India , iI )
 Oo0O . connect ( Italy , o00O )
 Oo0O . connect ( Netherlands , OOO0OOO00oo )
 Oo0O . connect ( Poland , Iii111II )
 Oo0O . connect ( Portugal , iiii11I )
 Oo0O . connect ( Romania , Ooo0OO0oOO )
 Oo0O . connect ( Russia , ii11i1 )
 Oo0O . connect ( Spain , IIIii1II1II )
 Oo0O . connect ( OOo , i1i1II )
 Oo0O . connect ( Ii1IIii11 , O0oo0OO0 )
 Oo0O . connect ( List , i1I1iI )
 Oo0O . connect ( Oooo0000 , Oo0O . close )
 oo0OooOOo0 = Oo0Ooo . getSetting ( 'secstore' )
 o0O ( oo0OooOOo0 )
 if oo0OooOOo0 == 'AF' : Oo0O . setFocus ( Africa )
 if oo0OooOOo0 == 'CA' : Oo0O . setFocus ( Canada )
 if oo0OooOOo0 == 'DE' : Oo0O . setFocus ( Germany )
 if oo0OooOOo0 == 'DK' : Oo0O . setFocus ( Denmark )
 if oo0OooOOo0 == 'FR' : Oo0O . setFocus ( France )
 if oo0OooOOo0 == 'GR' : Oo0O . setFocus ( Greece )
 if oo0OooOOo0 == 'IL' : Oo0O . setFocus ( Israel )
 if oo0OooOOo0 == 'IN' : Oo0O . setFocus ( India )
 if oo0OooOOo0 == 'IT' : Oo0O . setFocus ( Italy )
 if oo0OooOOo0 == 'NL' : Oo0O . setFocus ( Netherlands )
 if oo0OooOOo0 == 'PL' : Oo0O . setFocus ( Poland )
 if oo0OooOOo0 == 'PT' : Oo0O . setFocus ( Portugal )
 if oo0OooOOo0 == 'RO' : Oo0O . setFocus ( Romania )
 if oo0OooOOo0 == 'RUS' : Oo0O . setFocus ( Russia )
 if oo0OooOOo0 == 'ES' : Oo0O . setFocus ( Spain )
 if oo0OooOOo0 == 'UK' : Oo0O . setFocus ( OOo )
 if oo0OooOOo0 == 'US' : Oo0O . setFocus ( Ii1IIii11 )
 if not 'livemix' in OO0o : quit ( )
 if 72 - 72: IiIi1Iii1I1 / ooO0oo0oO0 * O00o0o0000o0o - IIIiiiiiIii
def oO00 ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'AF' )
 o0O ( 'AF' )
 Oo0O . setFocus ( List )
 if 51 - 51: i111I * oOo0oooo00o % IIIII * i111I % O00OoOoo00 / oOOoO0
def ooo ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'CA' )
 o0O ( 'CA' )
 Oo0O . setFocus ( List )
 if 49 - 49: IIIII
def ii1I1i1I ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'DE' )
 o0O ( 'DE' )
 Oo0O . setFocus ( List )
 if 35 - 35: I1i1i1ii - oooO0oo0oOOOO / O00OoOoo00 % ooO0oo0oO0
def OOoo0O0 ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'DK' )
 o0O ( 'DK' )
 Oo0O . setFocus ( List )
 if 78 - 78: IiiIII111ii
def iiiIi1i1I ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'FR' )
 o0O ( 'FR' )
 Oo0O . setFocus ( List )
 if 71 - 71: oooOOOOO + oOOoO0 % i11iIiiIii + O00OoOoo00 - O00O0O0O0
def oOO00oOO ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'GR' )
 o0O ( 'GR' )
 Oo0O . setFocus ( List )
 if 88 - 88: I1i1i1ii - oOo0oooo00o % oooOOOOO
def OoOo ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'IL' )
 o0O ( 'IL' )
 Oo0O . setFocus ( List )
 if 16 - 16: II1Ii1iI1i * iiiI11 % O00O0O0O0
def iI ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'IN' )
 o0O ( 'IN' )
 Oo0O . setFocus ( List )
 if 86 - 86: II1Ii1iI1i + i1iIIi1 % i11iIiiIii * iiiI11 . oOOoO0 * IiiIII111ii
def o00O ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'IT' )
 o0O ( 'IT' )
 Oo0O . setFocus ( List )
 if 44 - 44: iiiI11
def OOO0OOO00oo ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'NL' )
 o0O ( 'NL' )
 Oo0O . setFocus ( List )
 if 88 - 88: IIIiiiiiIii % i1iIIi1 . i111I
def Iii111II ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'PL' )
 o0O ( 'PL' )
 Oo0O . setFocus ( List )
 if 38 - 38: IIIII
def iiii11I ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'PT' )
 o0O ( 'PT' )
 Oo0O . setFocus ( List )
 if 57 - 57: O00ooOO / iiiI11 * IIIiiiiiIii / I1i1i1ii . i111I
def Ooo0OO0oOO ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'RO' )
 o0O ( 'RO' )
 Oo0O . setFocus ( List )
 if 26 - 26: IiIi1Iii1I1
def ii11i1 ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'RUS' )
 o0O ( 'RUS' )
 Oo0O . setFocus ( List )
 if 91 - 91: oOo0oooo00o . O00OoOoo00 + oOo0oooo00o - IiIi1Iii1I1 / oooO0oo0oOOOO
def IIIii1II1II ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'ES' )
 o0O ( 'ES' )
 Oo0O . setFocus ( List )
 if 39 - 39: O00OoOoo00 / oOOoO0 - i111I
def i1i1II ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'UK' )
 o0O ( 'UK' )
 Oo0O . setFocus ( List )
 if 98 - 98: O00OoOoo00 / IiiIII111ii % iiiI11 . I1i1i1ii
def O0oo0OO0 ( ) :
 List . reset ( )
 Oo0Ooo . setSetting ( 'secstore' , 'US' )
 o0O ( 'US' )
 Oo0O . setFocus ( List )
 if 91 - 91: iiiI11 % O00o0o0000o0o
def i1I1iI ( ) :
 global playname
 global I1IiiI
 I1IiiI = urllib . quote_plus ( net . http_GET ( I1IiiI ) . content )
 playname = playname . split ( ':' ) [ 1 ]
 O0O0O0OoOO = xbmcgui . ListItem ( playname , iconImage = iiiii , thumbnailImage = iiiii )
 Oo0O . close ( )
 I1IiiI = 'fuck5'
 I11i11Ii = playurl + '|User-Agent=' + I1IiiI
 xbmc . Player ( ) . play ( I11i11Ii , O0O0O0OoOO , False )
 if 74 - 74: i111I
def o0O ( sec ) :
 global chname
 global churl
 global prettyname
 Oo0O . setFocus ( List )
 chname = [ ]
 churl = [ ]
 oO0 = re . compile ( '^#.+?:-?[0-9]*(.*?),(.*?)\n(.*?)\n' , re . I + re . M + re . U + re . S ) . findall ( Link )
 Oo0O00Oo0o0 = [ ]
 for O00O0oOO00O00 , i1 , I11i11Ii in oO0 :
  if i1 . startswith ( 'USA:' ) : i1 = i1 . replace ( 'USA:' , 'US:' )
  i1 = i1 . replace ( ' :' , ':' ) . replace ( ' |' , ':' )
  Oo00 = { "params" : O00O0oOO00O00 , "name" : i1 , "url" : I11i11Ii }
  Oo0O00Oo0o0 . append ( Oo00 )
 list = [ ]
 for i1i in Oo0O00Oo0o0 :
  Oo00 = { "name" : i1i [ "name" ] , "url" : i1i [ "url" ] }
  oO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i1i [ "params" ] )
  for iiI111I1iIiI , II in oO0 :
   Oo00 [ iiI111I1iIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II . strip ( )
  list . append ( Oo00 )
 for i1i in list :
  if i1i [ "name" ] . startswith ( sec + ':' ) :
   chname . append ( i1i [ "name" ] )
   churl . append ( i1i [ "url" ] )
 chname , churl = zip ( * sorted ( zip ( chname , churl ) ) )
 for i1i in chname :
  prettyname = i1i . replace ( sec + ': ' , '' )
  List . addItem ( prettyname )
  if 45 - 45: O00ooOO * IIIII % O00o0o0000o0o * oooO0oo0oOOOO + IiIi1Iii1I1 . I1i1i1ii
  if 67 - 67: i11iIiiIii - ooO0oo0oO0 % O00OoOoo00 . O00ooOO
def I11iii ( ) :
 try :
  global playurl
  global playname
  if Oo0O . getFocus ( ) == List :
   o0oo = List . getSelectedPosition ( )
   playname = chname [ o0oo ]
   playurl = churl [ o0oo ] . replace ( '\n' , '' ) . replace ( '\r' , '' )
 except : pass
 if 91 - 91: O00O0O0O0
def iiIii ( name , url , mode , iconimage , fanart , description = '' ) :
 ooo0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description )
 oOoO0o00OO0 = True
 O0O0O0OoOO = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 O0O0O0OoOO . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 O0O0O0OoOO . setProperty ( 'fanart_image' , fanart )
 oOoO0o00OO0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo0O , listitem = O0O0O0OoOO , isFolder = False )
 return oOoO0o00OO0
 if 7 - 7: oooOOOOO + IIIiiiiiIii + O00ooOO
iI1Ii11111iIi ( )
Oo0O . doModal ( )
del Oo0O
if Oo == 1 : iI1Ii11111iIi ( )
if 9 - 9: i111I . IIIII - oOOoO0 / IIIII
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
