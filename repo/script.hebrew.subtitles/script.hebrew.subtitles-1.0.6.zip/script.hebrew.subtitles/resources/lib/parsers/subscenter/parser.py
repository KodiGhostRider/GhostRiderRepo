# -*- coding: utf-8 -*-

'''
Created on 14/06/2011

@author: sbentin
'''
import urllib2, re
import xbmc, xbmcgui, xbmcaddon

__settings__           = xbmcaddon.Addon(id='script.hebrew.subtitles')
__language__           = __settings__.getLocalizedString
__PLUGIN_PATH__        = __settings__.getAddonInfo('path')
__DEBUG__ = __settings__.getSetting("DEBUG") == "true"

from common import *

BASE_URL = 'http://www.subscenter.org'
TITLE_PATTERN = '<div class="generalWindowRight".*?<a href="(.*?)"'
HEBREW_SECTION = '"he": \{.*?\}\}\}'
HEBREW = 700
ENGLISH = 701
ENGLISH_SECTION = '"en": {.*?}}}'
MOVIE_SUBS = ' "id":.*?(\d*?),.*?"key": "(.*?)",.*?subtitle_version": "(.*?)"'
 
def getSubtitles(fileName, title, originalTitle, tvShow, season, episode, year, isTvShow, progressControl, maxPercent):
    subtitleList = []
    if isTvShow:
        searchString = tvShow.replace(" ", "+")
        percentStep = int(maxPercent / 3)
    else:
        if originalTitle != None and len(originalTitle) > 0:
            searchString = originalTitle.replace(" ", "+")
        else:
            searchString = title.replace(" ", "+")
        percentStep = int(maxPercent / 2)

    if len(searchString) <= 0:
        progressControl.setPercent(progressControl.getPercent() + maxPercent)
        return subtitleList, __language__(800) # missing title
    
    # Retrieve the search results (html)
    searchResults = getData(BASE_URL + "/he/subtitle/search/?q=" + searchString.lower())
    # Search most likely timed out, no results
    if (not searchResults):
        progressControl.setPercent(progressControl.getPercent() + maxPercent)
        return subtitleList, __language__(801)
    progressControl.setPercent(progressControl.getPercent() + percentStep)
    # maybe this is a single selection that is directly set to the movie page
    isSingle = re.findall('<h1 class="pageName">(.*?)</h1>', searchResults) 
    if isSingle and len(isSingle) > 0:
        percentStep = int(percentStep / 2)
        progressControl.setPercent(progressControl.getPercent() + percentStep)
        
        # we get the hebrew subtitles first, then the english
        getByLang(subtitleList, searchResults, 'he', HEBREW_SECTION, HEBREW, fileName, progressControl, percentStep)   
        getByLang(subtitleList, searchResults, 'en', ENGLISH_SECTION, ENGLISH, fileName, progressControl, percentStep)
        progressControl.setPercent(progressControl.getPercent() + maxPercent)
        return subtitleList, ''
    
    titles = re.findall(TITLE_PATTERN, searchResults)   
    percentStep = percentStep / len(titles)    
    for titleRef in titles:
        if isTvShow:
            # find subtitles for tv series
            getTvSubtitles(titleRef, subtitleList, season, episode, fileName, progressControl, percentStep)
        else:
            # find subtitles for a movie
            getMovieSubtitles(titleRef, subtitleList, fileName, progressControl, percentStep)
            
    progressControl.setPercent(progressControl.getPercent() + maxPercent)
    return subtitleList, ''

def getMovieSubtitles(ref, subtitleList, fileName, progressControl, percentStep):
    percentStep = int(percentStep / 2)
    
    # get the page with all the subtitles matching this movie id
    page = getData(BASE_URL + ref)
    progressControl.setPercent(progressControl.getPercent() + percentStep)
    # we get the hebrew subtitles first, then the english
    getByLang(subtitleList, page, 'he', HEBREW_SECTION, HEBREW, fileName, progressControl, percentStep)   
    getByLang(subtitleList, page, 'en', ENGLISH_SECTION, ENGLISH, fileName, progressControl, percentStep)
    

def getByLang(subtitleList, page, path, pattern, lang, fileName, progressControl, percentStep):
    langsubs = re.findall(pattern, page)
    if langsubs and len(langsubs) > 0:
        subs = re.findall(MOVIE_SUBS, langsubs[0])
        progressControl.setPercent(progressControl.getPercent() + percentStep)
        if subs:
            syncedList = []
            for id, key, name in subs:
                sync = False
                if name != None and len(name.lstrip(' ')) > 0 and fileName.capitalize().startswith(name.capitalize()):
                    sync = True
                
                if __DEBUG__:
                    log(__name__, 'sync --> ' + str(sync))
                    log(__name__, 'lang --> ' + str(lang))
                    log(__name__, 'fileName --> ' + name)
                    log(__name__, 'url --> ' + 'http://www.subscenter.org/' + path + '/subtitle/download/' + path + '/' + id + '/?v=' + name + '&key=' + key)
                
                if sync:
                    syncedList.append({'sync':sync, 'lang':lang, 'fileName':urllib2.unquote(name), 'url':'http://www.subscenter.org/' + path + '/subtitle/download/' + path + '/' + id + '/?v=' + name + '&key=' + key}) 
                else :
                    subtitleList.append({'sync':sync, 'lang':lang, 'fileName':urllib2.unquote(name), 'url':'http://www.subscenter.org/' + path + '/subtitle/download/' + path + '/' + id + '/?v=' + name + '&key=' + key})
            if len(syncedList) > 0:
                syncedList.extend(subtitleList)
                subtitleList = syncedList
            
def getTvSubtitles(ref, subtitleList, season, episode, fileName, progressControl, percentStep):
    percentStep = int(percentStep / 2)
    
    # get the page with all the subtitles matching this series and episode
    page = getData(BASE_URL + ref + season + "/" + episode + "/")
    
    progressControl.setPercent(progressControl.getPercent() + percentStep)
    if page:
        # we get the hebrew subtitles first, then the english
        getByLang(subtitleList, page, 'he', HEBREW_SECTION, HEBREW, fileName, progressControl, percentStep)   
        getByLang(subtitleList, page, 'en', ENGLISH_SECTION, ENGLISH, fileName, progressControl, percentStep)    