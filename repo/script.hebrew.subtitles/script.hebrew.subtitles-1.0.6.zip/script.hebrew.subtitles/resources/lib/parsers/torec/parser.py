# -*- coding: utf-8 -*-

'''
Created on 14/06/2011

@author: sbentin
'''
import os, sys, re, string, time, urllib, urllib2
import xbmc, xbmcgui

def getSubtitles(fileName, title, originalTitle, tvShow, season, episode, year, isTvShow, progressControl, maxPercent):
    subtitleList = []
    return subtitleList, ''