# -*- coding: utf-8 -*-

'''
Common functions for all parsers to use
Created on 30/05/2011

@author: sbentin
'''


import sys, urllib2
import xbmc

__settings__           = sys.modules[ "__main__" ].__settings__
__DEBUG__              = sys.modules[ "__main__" ].__DEBUG__

__USERAGENT__ = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
__scriptname__ = sys.modules[ "__main__" ].__scriptname__

def getData(url, clean=True):
        if __DEBUG__:
            print 'url --> ' + url
        try :
            req = urllib2.Request(url)
            req.add_header('User-Agent', __USERAGENT__)
            response = urllib2.urlopen(req)
            if clean:
                data = response.read().replace("\n","").replace("\t","").replace("\r","")
            else:
                data = response.read()
            response.close()
            return data
        except:
            if __DEBUG__:
                errno, errstr = sys.exc_info()[:2]
                print 'Error in getData: ' + str(errno) + ': ' + str(errstr)
            xbmc.log('Error in getData: Unable to save cache', xbmc.LOGERROR)
            return 'unavailable'
        
def getFlag(lang):
    flags = {700: 'Hebrew.png', 701: 'English.png'}
    return flags[lang]

def langToCode(language):
    languages = {
        "עברית"     : 700,
        "אנגלית"    : 701
    }
    try:
        return languages[language]
    except:
        return None
    
def log(module, msg):
    xbmc.output("### [%s-%s] - %s" % (__scriptname__, module, msg,), level=xbmc.LOGDEBUG)
    
def notice(module, msg):
    xbmc.output("### [%s-%s] - %s" % (__scriptname__, module, msg,), level=xbmc.LOGNOTICE)