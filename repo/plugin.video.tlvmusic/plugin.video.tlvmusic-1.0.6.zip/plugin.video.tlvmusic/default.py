# -*- coding: utf-8 -*-
#------------------------------------------------------------
# The TLVmusic Addon by TLVkodi | www.tlvkodi.com
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: TLV kodi 2016 © Tsvika Levy
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.tlvmusic'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "UCCLDOXi2mNQgMxFXV7nzKHQ/playlists"
YOUTUBE_CHANNEL_ID_2 = "PLUS5kaicRzrAiRCTSBABLczGjnThpOR2h"
YOUTUBE_CHANNEL_ID_3 = "PLmwb8pU9hbfe-2fSlBDi7L-Zv0TNw_5_a"
YOUTUBE_CHANNEL_ID_4 = "PLORVsgOwzvD-83JQpYN4TkKcfcLlDNNdW"
YOUTUBE_CHANNEL_ID_5 = "PLIy71HzHYWHffS7vtg1Hj5--8QTPo9g4r"
YOUTUBE_CHANNEL_ID_6 = "PLu7UKx0MrwGdMMl8KGvLgmmT2Mv8tszhh"
YOUTUBE_CHANNEL_ID_7 = "PLq6HUZa4qwg2CT3l04kmtO7vZmJn2dFeX"
YOUTUBE_CHANNEL_ID_8 = "PLZpDUZDTTXLID9dFgTSg_zfc42Jsmp6_Z"
YOUTUBE_CHANNEL_ID_9 = "PL6Odgl2wj5gEUkGjR8YUeqRUe2QXHd270"
YOUTUBE_CHANNEL_ID_10 = "PLwJJKkFUWCurW_7aSAdW32xKWpTLMIlkP"
YOUTUBE_CHANNEL_ID_11 = "PLqxJ7-JU_NFW-E_Yh8MaieEgzY7zd-It7"
YOUTUBE_CHANNEL_ID_12 = "PL1wvFCFLTINjB5d5Bw4DPd28Kb2DZh3Ro"
YOUTUBE_CHANNEL_ID_13 = "PLpHAg78oV2GwSAIgMzsiJhKR0wHX94HzK"
YOUTUBE_CHANNEL_ID_14 = "PLBYezdzRb1AZxV8GbwnqleEE5xbUJQFws"
YOUTUBE_CHANNEL_ID_15 = "PL3OEjm1U4yMZHzZXLcKUzcgRlzjFysnmY"
YOUTUBE_CHANNEL_ID_16 = "PLFH61-AZtWKeIlzxx0bdjsABGP7AL2mqo"
YOUTUBE_CHANNEL_ID_17 = "PLBbxK7xN8kyesfb1J8Nzg0stpZQAhT4Jf"
YOUTUBE_CHANNEL_ID_18 = "PLNBbMlpPMEInvMwmmEYKFuTCH_6fi-rpv"
YOUTUBE_CHANNEL_ID_19 = "PL1awt2GLbWYUrg5MzGkNr_jrQtHCbepxz"
YOUTUBE_CHANNEL_ID_20 = "PL188ktgLukZqJ9DTpQC7t-bq5mqqMCr63"
YOUTUBE_CHANNEL_ID_21 = "PLs6E2r9T5pQPoaT_DF3SK_PevXPPg0mMV"
YOUTUBE_CHANNEL_ID_22 = "PLwKVY_5tp68S1aEDlvGGJ_4iA_b0dcycX"
YOUTUBE_CHANNEL_ID_23 = "PL-Gu_9CRly9pJIkTXYSdhwBogG5o9hCI4"
YOUTUBE_CHANNEL_ID_24 = "PLQHg0DG84XHtP79iP6zDJ9zf6cZSt6bzT"
YOUTUBE_CHANNEL_ID_25 = "PL-NLP22Wok1Bv2WvvNsdNPmN0ewi8_72p"
YOUTUBE_CHANNEL_ID_26 = "PLd673Ksr4BQAbbDyfb006kndPAAxGcOVG"
YOUTUBE_CHANNEL_ID_27 = "PLq1FxHvgkwv39_BRdSHo8cGIm2rPaEdQE"
YOUTUBE_CHANNEL_ID_28 = "PLA1HYuENA0tWxRBk4qGZ6iXwZ8fBS9f5C"
YOUTUBE_CHANNEL_ID_29 = "PL8l1tswucJYjIqI1d8Jkl-tmKCPcxLHta"
YOUTUBE_CHANNEL_ID_30 = "PLExeRPJcD_TCbFV9ws3kb6NKq8apyUGjd"
YOUTUBE_CHANNEL_ID_31 = "PLX-EzxXw4n7SVGL1GmnokB6q822yDib2C"
YOUTUBE_CHANNEL_ID_32 = "PLJ2udVVyDPvXGUeBS8DCfFAdIGT7yoiqg"
YOUTUBE_CHANNEL_ID_33 = "PLRI6x7spQp6KzmS-5g1rtc8-G76ONLxtU"
YOUTUBE_CHANNEL_ID_34 = "PLA4AWGFmZv3QTSZjwKxoR8wdpzxbdoxFa"
YOUTUBE_CHANNEL_ID_35 = "PLnBGxFhuycR-76ZjXpqjKWR1Q0Qj42i32"
YOUTUBE_CHANNEL_ID_36 = "PLptp9ekoNTiWQXgtqtYdp0t6Ra12MXAN9"
YOUTUBE_CHANNEL_ID_37 = "PLRFg9UEelHr9YZcg_nelBz-IZmdHx542p"
YOUTUBE_CHANNEL_ID_38 = "PL6DnOWTkjjSz7u1HgJemJwIPfEBNDHEsG"
YOUTUBE_CHANNEL_ID_39 = "PLVgAsNNsa4gBF9CGfWiwzvSSEHtdHk_vB"
YOUTUBE_CHANNEL_ID_40 = "PL3Ia5kEcmsAlJ3u8UK0i1pf3cuvzdCB6I"
YOUTUBE_CHANNEL_ID_41 = "PLCuZ4DSDyUwbZy_qpepNtMRNzz_w7vipX"
YOUTUBE_CHANNEL_ID_42 = "PLu4mXbc_SYZOZsB1oZwzG-5NvG27Y-TLS"
YOUTUBE_CHANNEL_ID_43 = "PLIiKbVpVAQpbbgPM8EGwO5zd4nQYDDth6"
YOUTUBE_CHANNEL_ID_44 = "PLbpzHjqMACWJ4a435qpbU_L0tObOpiAcb"
YOUTUBE_CHANNEL_ID_45 = "PLIQkxbQ0_r756En7KiQbv9Xdbb6nyKnVe"
YOUTUBE_CHANNEL_ID_46 = "PLV5BwRxW0zpnzjggnDHnD1XXZfYR2r3lP"
YOUTUBE_CHANNEL_ID_47 = "PLldli1FGBgw24x4q8noiFHUsFa4wc8OCD"
YOUTUBE_CHANNEL_ID_48 = "PLcWCTLh0UkxD43JJIi2s9MfjG7_GZ6ODa"
YOUTUBE_CHANNEL_ID_49 = "PLjWpieNNIe5h-eR7lj2M8DxcVSbxUPrQ9"
YOUTUBE_CHANNEL_ID_50 = "PLg4v3gICWbejiFlzno9pza-25wuwFNI2l"
YOUTUBE_CHANNEL_ID_51 = "PLJssM6hqmGcBTP2NgjrEeTjoPhI_9oFIM"
YOUTUBE_CHANNEL_ID_52 = "PLOJ27NQ0yPKtdLA3WXYBMAr5ilM2wfLZ2"
YOUTUBE_CHANNEL_ID_53 = "PLoCoAtzVF5ABWVnvQaKMogDyMYKSBNDwv"
YOUTUBE_CHANNEL_ID_54 = "PLDp9OGvYmdhTJ8XbIUi_q1t54MxsLbErp"
YOUTUBE_CHANNEL_ID_55 = "PLXiKkHKkGc6L6W87-8p2diYmsS743NzJe"
YOUTUBE_CHANNEL_ID_56 = "PLWr7ke8Bm4mMUJbtuK9OnE55gfaMkwB4J"
YOUTUBE_CHANNEL_ID_57 = "PLMUA1aPz-qbL1mJuo8L1XHf4QFxKtWP4y"
YOUTUBE_CHANNEL_ID_58 = "PLgEildUeWGFzOuC1gqkgMudWzRyv1w8bU"
YOUTUBE_CHANNEL_ID_59 = "PL03oUCvaG1k0oKGPN8IJXHo6Ja55lm7p3"
YOUTUBE_CHANNEL_ID_60 = "PLYu_okg9JYlUGk3fWPCCfyYR33mhEhZSM"
YOUTUBE_CHANNEL_ID_61 = "PLe4Xl3BkBD9CsxyXaqHU0VwODm3LAnZv4"
YOUTUBE_CHANNEL_ID_62 = "PLNnT0fwAYVXYynOGcOksY60GyBHB5jzGF"
YOUTUBE_CHANNEL_ID_63 = "PLSWbObFSegm-xF5seAGEKlh5spjo-osV2"
YOUTUBE_CHANNEL_ID_64 = "PLoX54Rc4YV-6eBo6dnDQCOiES25MsgSMV"


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="אוזן מוזיקה ישראלית",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-1p1rD4H6bEI/AAAAAAAAAAI/AAAAAAAAAAA/zqL5NvzHGkc/s100-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מירי מסיקה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.ytimg.com/i/7cwmZGtlWPDkkEWsxkZd-Q/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="עברי לידר",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-dcDK_SlCZkg/AAAAAAAAAAI/AAAAAAAAAAA/FUC0PJKbieU/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="עידן רייכל",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-vsBWN1RBQuk/AAAAAAAAAAI/AAAAAAAAAAA/SWZEbbG5oUY/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="דיויד ברוזה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-jqmb120ys0o/AAAAAAAAAAI/AAAAAAAAAAA/okV8-ozgQU8/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="שירי מימון",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-33p31sJqT88/AAAAAAAAAAI/AAAAAAAAAAA/taeHwLul6Io/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="דודו אהרון",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/-0orZ08za-yw/AAAAAAAAAAI/AAAAAAAAAAA/5axG6k56St4/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="משה פרץ",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://i.ytimg.com/i/0ebT4a-IyuY61X8py3nzsg/mq1.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="הראל סקעת",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://i.ytimg.com/i/BbOw6LiHmj6L9o_HlMvKKg/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מוקי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-AsTNHQK9-Eo/AAAAAAAAAAI/AAAAAAAAAAA/bSK6tfXXF1E/s176-c-k-no/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="פאר טסי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-XdArdL_W374/AAAAAAAAAAI/AAAAAAAAAAA/phGLZNk8iwU/s176-c-k-no/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="אייל גולן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/-PV5wpA_XiiY/AAAAAAAAAAI/AAAAAAAAAAA/XCOsoSqKASA/s176-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="קרן פלס",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/-g-vBfZegycg/AAAAAAAAAAI/AAAAAAAAAAA/3_4Cd3tCOvM/s176-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="שלמה ארצי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://i.ytimg.com/i/QHzG2gtNfXp4yo6_I46eCw/mq1.jpg",
        folder=True ) 
		
    plugintools.add_item( 
        #action="", 
        title="משינה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/-YMMH8p86Qgk/AAAAAAAAAAI/AAAAAAAAAAA/CgHtHDzT1L0/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="כוורת",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://yt3.ggpht.com/-GnJdbs1R77k/AAAAAAAAAAI/AAAAAAAAAAA/rMsr-BxeKqQ/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אריק אינשטיין",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://yt3.ggpht.com/-70TuUnUpj4I/AAAAAAAAAAI/AAAAAAAAAAA/ygRu0cv77QM/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="שרית חדד",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://yt3.ggpht.com/-rirhhHRwKlU/AAAAAAAAAAI/AAAAAAAAAAA/sJyejBLp0fs/s176-c-k-no/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="ריקי גל",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://i.ytimg.com/i/pVnrlDrQzDpNeLWAXXaETQ/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="יהורם גאון",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://i.ytimg.com/i/A3PKEDZ9cEqpi6AnLImgJw/mq1.jpg",
        folder=True )  

		
    plugintools.add_item( 
        #action="", 
        title="ריטה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://yt3.ggpht.com/-mWgBzYMaVyA/AAAAAAAAAAI/AAAAAAAAAAA/fCC_MbpehM0/s176-c-k-no/photo.jpg",
        folder=True )  	

    plugintools.add_item( 
        #action="", 
        title="רונה קינן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://yt3.ggpht.com/-ghrjKXspM1s/AAAAAAAAAAI/AAAAAAAAAAA/2PRG4sK61Ek/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="נורית גלרון",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://i.ytimg.com/i/9Md5MQ5GTF0MYc-lOE__zw/mq1.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="שלומי שבת",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://i.ytimg.com/i/GaHPMv8YIv_0HfRDQQ44cA/mq1.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="קובי אפללו",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://yt3.ggpht.com/-W5wjK70SQ1U/AAAAAAAAAAI/AAAAAAAAAAA/Ibov9BPmodU/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="סגיב כהן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://yt3.ggpht.com/-rG_Oeq8u13I/AAAAAAAAAAI/AAAAAAAAAAA/FEwo6HuzAJM/s176-c-k-no/photo.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="יובל דיין",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://i.ytimg.com/i/aoU3jCV2ViwIziQkO06a-Q/mq1.jpg",
        folder=True )	
		
    plugintools.add_item( 
        #action="", 
        title="לאה שבת",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://yt3.ggpht.com/-ohRq-agRAoE/AAAAAAAAAAI/AAAAAAAAAAA/XnqTdGoERkw/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אהוד בנאי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://yt3.ggpht.com/-PEUc1dLRo-c/AAAAAAAAAAI/AAAAAAAAAAA/EHUJmoEG0ro/s176-c-k-no/photo.jpg",
        folder=True )	
    plugintools.add_item( 
        #action="", 
        title="רמי פורטיס",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://yt3.ggpht.com/-1Nc-g81Hs0o/AAAAAAAAAAI/AAAAAAAAAAA/qb5Q0TpYok8/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Balkan Beat Box",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://yt3.ggpht.com/-B7jVk2QUUvY/AAAAAAAAAAI/AAAAAAAAAAA/D5bJhE9GOSg/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אסף אבידן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="https://i.ytimg.com/i/W4BoKZI710osDQmzt-BdJQ/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אחינועם ניני",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_33+"/",
        thumbnail="https://i.ytimg.com/i/_sZP_Qv3gVUQjOtBqUkJtg/mq1.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="יהודית רביץ",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_34+"/",
        thumbnail="https://yt3.ggpht.com/-8oDYKgR_EcY/AAAAAAAAAAI/AAAAAAAAAAA/qL-nzF-D5GA/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="מוש בן ארי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_35+"/",
        thumbnail="https://yt3.ggpht.com/-kGMcrU7fFyU/AAAAAAAAAAI/AAAAAAAAAAA/gjdGe5E6PFQ/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="ארקדי דוכין",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_36+"/",
        thumbnail="https://yt3.ggpht.com/-MK1Yd6JAWRE/AAAAAAAAAAI/AAAAAAAAAAA/e4vLO42F_0c/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="אביב גפן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_37+"/",
        thumbnail="https://yt3.ggpht.com/-n9kLUZul28Q/AAAAAAAAAAI/AAAAAAAAAAA/O86BinP3aQw/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="שלום חנוך",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_38+"/",
        thumbnail="https://yt3.ggpht.com/-6DiGw2l8Nrk/AAAAAAAAAAI/AAAAAAAAAAA/3qnrk75SjaA/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="ברי סחרוף",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_39+"/",
        thumbnail="https://yt3.ggpht.com/-vWq0Ei1WsRQ/AAAAAAAAAAI/AAAAAAAAAAA/5Y_fTrKAFoo/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="מתי כספי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_40+"/",
        thumbnail="https://i.ytimg.com/i/hV4_Q6R4edNRfMoQiOHa7A/mq1.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="נינט טייב",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_41+"/",
        thumbnail="https://yt3.ggpht.com/-vjuOCDX_B4o/AAAAAAAAAAI/AAAAAAAAAAA/kRBC-od5JzM/s176-c-k-no/photo.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="דנה אינטרנשיונל",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_42+"/",
        thumbnail="https://yt3.ggpht.com/-mrXhP27w_Us/AAAAAAAAAAI/AAAAAAAAAAA/omGgmuQWDoc/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אריאל זילבר",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_43+"/",
        thumbnail="https://yt3.ggpht.com/-BmKqVNPRv0U/AAAAAAAAAAI/AAAAAAAAAAA/u_qee3euwF4/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="מאיר בנאי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_44+"/",
        thumbnail="https://yt3.ggpht.com/-WQglHjfoC4o/AAAAAAAAAAI/AAAAAAAAAAA/hMQUdsAQgxQ/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="טיפקס",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_45+"/",
        thumbnail="https://yt3.ggpht.com/-g0tzoTXWJ6k/AAAAAAAAAAI/AAAAAAAAAAA/uP5aRLdVqn0/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אתניקס",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_46+"/",
        thumbnail="https://i.ytimg.com/i/3x2sCUeEW4BidSBClBHchA/mq1.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="הדג נחש",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_47+"/",
        thumbnail="https://yt3.ggpht.com/-p7M1mRBKD4A/AAAAAAAAAAI/AAAAAAAAAAA/uHxN4-rnvV4/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="דנה ברגר",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_48+"/",
        thumbnail="https://yt3.ggpht.com/-gkbYjd0J0Zw/AAAAAAAAAAI/AAAAAAAAAAA/tw2WIW5qu-Q/s176-c-k-no/photo.jpg",
        folder=True )		
	
    plugintools.add_item( 
        #action="", 
        title="איה כורם",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_49+"/",
        thumbnail="https://i.ytimg.com/i/Qzpq-Y6UvFTMJCeUvCl52g/mq1.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="ירדנה ארזי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_50+"/",
        thumbnail="https://yt3.ggpht.com/-Qaq5WgP84jw/AAAAAAAAAAI/AAAAAAAAAAA/ANHwX9DVbX0/s176-c-k-no/photo.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="חוה אלברשטיין",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_51+"/",
        thumbnail="https://i.ytimg.com/i/Q87KyUq4NtYi1NvC5rD5Vw/mq1.jpg",
        folder=True )	

    plugintools.add_item( 
        #action="", 
        title="ליאור נרקיס",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_52+"/",
        thumbnail="https://yt3.ggpht.com/-rty-RitLrSM/AAAAAAAAAAI/AAAAAAAAAAA/yjXa3UqBrlk/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="אביתר בנאי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_53+"/",
        thumbnail="https://yt3.ggpht.com/-Te7WcZKDLB4/AAAAAAAAAAI/AAAAAAAAAAA/WHNxjxRGCrg/s176-c-k-no/photo.jpg",
        folder=True )		
		
    plugintools.add_item( 
        #action="", 
        title="קרולינה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_54+"/",
        thumbnail="https://yt3.ggpht.com/-odfpSwG_OxA/AAAAAAAAAAI/AAAAAAAAAAA/FQozWRfo-Fk/s176-c-k-no/photo.jpg",
        folder=True )			

    plugintools.add_item( 
        #action="", 
        title="עדן בן זקן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_55+"/",
        thumbnail="https://yt3.ggpht.com/-pGh03p0c_20/AAAAAAAAAAI/AAAAAAAAAAA/PXLB08tAKa8/s176-c-k-no/photo.jpg",
        folder=True )		

    plugintools.add_item( 
        #action="", 
        title="רמי קלינשטיין",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_56+"/",
        thumbnail="https://yt3.ggpht.com/-w0s7cBy2UZM/AAAAAAAAAAI/AAAAAAAAAAA/imwGV27TLck/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="החברים של נטאשה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_57+"/",
        thumbnail="https://yt3.ggpht.com/-6NHc1w11up4/AAAAAAAAAAI/AAAAAAAAAAA/M7Qsh8KSiWs/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מאיה בוסקילה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_58+"/",
        thumbnail="https://yt3.ggpht.com/-5PEvWjlVLN4/AAAAAAAAAAI/AAAAAAAAAAA/tNQGMUjQfxE/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="עידן יניב",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_59+"/",
        thumbnail="https://yt3.ggpht.com/-t6S0EuipGkA/AAAAAAAAAAI/AAAAAAAAAAA/nwz0JTWpzfA/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="יהודה פוליקר",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_60+"/",
        thumbnail="https://yt3.ggpht.com/-kO_zYQwYNcs/AAAAAAAAAAI/AAAAAAAAAAA/e4rq8-PzCDc/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="בן ארצי",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_61+"/",
        thumbnail="https://i.ytimg.com/i/8G3ncGuD8y7UOeEFU9O9jw/mq1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="אריק ברמן",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_62+"/",
        thumbnail="https://yt3.ggpht.com/-OftGeeqv5Ro/AAAAAAAAAAI/AAAAAAAAAAA/g63muwNYhpY/s176-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="מיקה קרני",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_63+"/",
        thumbnail="https://i.ytimg.com/i/07ykhmlSDpDUsejxzRhiVQ/mq1.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="טונה",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_64+"/",
        thumbnail="https://yt3.ggpht.com/-MiiyGDqcznI/AAAAAAAAAAI/AAAAAAAAAAA/iUX8dahvXAQ/s176-c-k-no/photo.jpg",
        folder=True )
		
run()
