import xbmc,xbmcgui,os,re,urllib,time
import adultresolver
adultresolver = adultresolver.streamer()
import kodi
import client
import utils
import history
import log_utils
import downloader

@utils.url_dispatcher.register('801', ['url'], ['name', 'iconimage', 'pattern']) 
def resolve_url(url, name=None, iconimage=None, pattern=None):

    xbmc.executebuiltin("ActivateWindow(busydialog)")
        
    notifymsg = False
    if '- [' in name: 
        name = name.split('- [')[0]
    if 'notify|' in url:
        url,notifymsg = url.split('notify|')

    try: url,site = url.split('|SPLIT|')
    except: 
        site = 'Unknown'
        log_utils.log('Error getting site information from :: %s' % (url), log_utils.LOGERROR)
    
    u = adultresolver.resolve(url,pattern)
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    
    if u == 'offline':
        kodi.notify(msg='This performer is offline.', duration = 5000, sound = True)
        quit()
    if u:
        play(u,name,iconimage,url,site)
        time.sleep(5)
        if notifymsg: kodi.notify(header='Chaturbate', msg=notifymsg, duration=15000, sound=True)
    else: 
        log_utils.log('Failed to get any playable link for :: %s' % (url), log_utils.LOGERROR)
        kodi.notify(msg='Failed to get any playable link.', duration=7500, sound=True)
        quit()

@utils.url_dispatcher.register('803', ['url'], ['name', 'iconimage', 'ref', 'site']) 
def play(url, name, iconimage, ref=None, site=None):

    if (not isinstance(url, str)): url = multilinkselector(url)
    if not site: 
        if 'site=' in url: url,site = url.split('site=')
        else: site = 'Unknown'
    if not name: name = 'Unknown'
    if not iconimage: iconimage = kodi.addonicon
    if '] - ' in name: name = name.split('] - ')[1] 
    name = re.sub(r'(\[.+?\])','',name); name = name.lstrip()

    history_on_off  = kodi.get_setting("history_setting")
    if history_on_off == "true":
        web_checks = ['http:','https:','rtmp:']
        locak_checks = ['.mp4']
        if any(f for f in web_checks if f in url): site = site.title()
        elif any(f for f in locak_checks if f in url): site = 'Local File'
        else: site = 'Unknown'
        
        history.delEntry(url)
        history.addHistory(name, url, site.title(), iconimage)
        
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    xbmc.Player().play(url, liz, False)
 
@utils.url_dispatcher.register('802',['name','url','iconimage'])
def specialplayer(name,url,iconimage):

    a,b,c,d,url = url.split('|SPLIT|')
    name = a
    date_now = datetime.datetime.now().strftime("%d-%m-%Y")
    time_now = datetime.datetime.now().strftime("%H:%M")
    string = '\n<item>\n<date>'+date_now+'</date>\n<time>'+time_now+'</time>\n<name>'+a+'</name>\n<link>'+b+'</link>\n<site>'+c+'</site>\n<icon>'+d+'</icon>\n</item>\n'
    a=open(historyfile).read()
    b=a.replace('#START OF FILE#', '#START OF FILE#' + string)
    f= open(historyfile, mode='w')
    f.write(str(b))
    f.close()

    if iconimage == "None":
        iconimage = icon

    if "highwebmedia" in url:
        kodi.dialog.ok(kodi.get_name(), '[COLOR white]Chaturbate links are taken at the time of broadcasting. If this broadcast has ended the link will no longer play. [/COLOR]')
    import urlresolver
    if urlresolver.HostedMediaFile(url).valid_url(): 
        url = urlresolver.HostedMediaFile(url).resolve()
    liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    xbmc.Player ().play(url, liz, False)

def multilinkselector(url):

    try:
        mobile_mode = kodi.get_setting('mobile_mode')
        auto_play = kodi.get_setting('auto_play')
        if mobile_mode == 'true': url = url[-1][-1]
        elif auto_play == 'true': url = url[0][1]
        elif len(url) == 1: url = url[0][1]
        else:
            sources = []
            for i in url:
                c = client.request(i[1], output='headers')
                sources += [(i[0],kodi.convertSize(int(c['Content-Length'])),i[1])]

            quals = []
            srcs  = []
            for i in sources:
                qual = '%s - [ %s ]' % (i[0],i[1])
                quals.append(kodi.giveColor(qual,'white',True))
                srcs.append(i[2])

            selected = kodi.dialog.select('Select a quality.',quals)
            if selected < 0:
                kodi.notify(msg='No option selected.')
                return 'quit'
            else:
                url = srcs[selected]
        return url
    except: return url[0][1]
