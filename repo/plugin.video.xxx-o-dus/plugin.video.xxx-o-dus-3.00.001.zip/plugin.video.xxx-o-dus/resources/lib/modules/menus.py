"""
    Copyright (C) 2016 ECHO Coder

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import xbmc,xbmcplugin,os,urllib
import kodi
import log_utils
import helper
import utils
import search
import downloader
import parental
import misc
import history
import favorites
from scrapers import __all__
from scrapers import *

buildDirectory = utils.buildDir
art_location        = xbmc.translatePath(os.path.join('special://home/addons/' + kodi.get_id(), 'resources/art/'))
specific_icon       = xbmc.translatePath(os.path.join('special://home/addons/script.xxxodus.artwork/resources/art/', '%s/icon.png'))
specific_fanart     = xbmc.translatePath(os.path.join('special://home/addons/script.xxxodus.artwork/resources/art/', '%s/fanart.jpg'))

@utils.url_dispatcher.register('0')
def mainMenu():

    dirlst = []
    c = []
    
    if kodi.get_setting('mobile_mode') == 'true':
        c += [(kodi.giveColor('Mobile Mode ON','deeppink',True),None,19,None,'Mobile Mode auto selects low bandwidth files to limit mobile data usage.',False)]
    c += [
         ('Search...',None,1,None,'Search XXX-O-DUS',True), \
         ('Chaturbate',None,300,'chaturbate','Chaturbate',True), \
         ('Tubes',None,4,None,'Videos',True), \
         ('Parental Controls',None,5,None,'View/Change Parental Control Settings.',True), \
         ('Your History',None,20,None,'View Your History.',True), \
         ('Your Favourites',None,23,None,'View Your Favourites.',True), \
         ('Your Downloads',None,27,None,'View Your Downloads.',True), \
         ('Your Settings',None,19,None,'View/Change Addon Settings.',False), \
         ('View Disclaimer',xbmc.translatePath(os.path.join(kodi.addonfolder, 'resources/disclaimer.txt')),17,None,'View XXX-O-DUS Disclaimer.',False), \
         ('View Addon Information',xbmc.translatePath(os.path.join(kodi.addonfolder, 'resources/information.txt')),17,None,'View XXX-O-DUS Information.',False), \
         ('RESET XXX-O-DUS',None,18,None,'Reset XXX-O-DUS to Factory Settings.',False), \
         ]
    
    for i in c:
        if i[3]: 
            icon    = specific_icon % i[3]
            fanart  = specific_fanart % i[3]
        else:
            icon   = kodi.addonicon
            fanart = kodi.addonfanart
        dirlst.append({'name': kodi.giveColor(i[0],'white'), 'url': i[1], 'mode': i[2], 'icon': icon, 'fanart': fanart, 'description': i[4], 'folder': i[5]})

    buildDirectory(dirlst, cache=False)
    
@utils.url_dispatcher.register('4')
def VIDEOS():

    sources = __all__ ; video_sources = []; base_name = []; menu_mode = []; art_dir = []
    sources = [i for i in sources if i != 'chaturbate']
    for i in sources:
        try:
            if eval(i + ".type") == 'video': 
                base_name.append(eval(i + ".base_name"))
                menu_mode.append(eval(i + ".menu_mode"))
                art_dir.append(i)
                video_sources = zip(base_name,menu_mode,art_dir)
        except: pass

    if video_sources:
        dirlst = []
        for i in sorted(video_sources):
            dirlst.append({'name': kodi.giveColor(i[0],'white'), 'url': None, 'mode': i[1], 'icon': specific_icon % i[2], 'fanart': specific_fanart % i[2], 'folder': True})

    buildDirectory(dirlst)