import os,sys
import kodi

class run:

    def __init__(self):
    
        self.firstRunFile = os.path.join(kodi.datafolder, 'firstrun.txt')
        self.informationFile = os.path.join(kodi.addonfolder, 'resources/information.txt')

        if ( not os.path.isfile(self.firstRunFile) ): 
            self.checkAge()
            self.notice()
        return

    def checkAge(self):

        choice = kodi.dialog.yesno(kodi.get_name(), 'To use this addon you you must be legally allowed to under the laws of your State/Country. By pressing I Agree you accept that you are legally allowed to view adult content.',yeslabel='I Agree',nolabel='Exit')
        if choice: 
            try:
                with open(self.firstRunFile,mode='w')as f: f.close()
            except: pass
        else: sys.exit(1)
   
    def notice(self):
        with open(self.informationFile,mode='r')as f: msg = f.read()
        kodi.TextBoxes("%s" % msg)