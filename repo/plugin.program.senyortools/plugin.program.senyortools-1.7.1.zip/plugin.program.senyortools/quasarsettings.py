# -*- coding: utf-8 -*-
import os, urllib, xbmc, zipfile, time,xbmcgui

dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()

def ExtractAll(_in, _out):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False

	return True

def requestsen():
  if os.path.exists(os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'script.quasar.rarbg-mc')):
   query = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s", "properties": ["enabled"]}' % 'script.quasar.rarbg-mc')
   if '"enabled":true' in query:
    dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  אותרו ספקי קוואזר ישנים " ,"נא להסירם","") 

def quasarset():
		
	url = "https://github.com/kobiko3030/kodi-senyor/blob/master/quasarwizard/userdata/userdata.zip?raw=true"
	addonsDir = xbmc.translatePath(os.path.join('special://home')).decode("utf-8")
	packageFile = os.path.join(addonsDir,'isra.zip')
	
	urllib.urlretrieve(url, packageFile)
	ExtractAll(packageFile, addonsDir)
		
	try:
		os.remove(packageFile)
	except:
		pass	
			
