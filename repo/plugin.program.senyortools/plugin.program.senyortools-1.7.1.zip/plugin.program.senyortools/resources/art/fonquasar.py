# -*- coding: utf-8 -*-
import json
import xbmc, xbmcgui, xbmcaddon
import time

dialog = xbmcgui.Dialog()
Progress = xbmcgui.DialogProgress()

jsonSetq = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"services.esenabled","value":true}, "id":1}'
jsonSetqa = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"services.esallinterfaces","value":true}, "id":1}'



xbmc.executeJSONRPC(jsonSetq)
xbmc.executeJSONRPC(jsonSetqa)





def fon():

    choice = xbmcgui.Dialog().yesno('[COLOR=green]הגדרת טלוויזיה חיה[/COLOR]', '', 'האם תרצו להתקין טלוויזיה חיה?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        pass
    elif choice == 1:
        prs()

    choice = xbmcgui.Dialog().yesno('[COLOR=green]התקנת ספריית סרטים וסדרות[/COLOR]', '', 'האם תרצו להתקין ספריית סרטים וסדרות?', nolabel='לא',yeslabel='כן')
    if choice == 0:
        pass
    elif choice == 1:
        wizwall()
				
    
    kodiset()		

def wizwall():
        xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/wall.py)')
        time.sleep(10)
        dialog.ok('אשף הגדרת הקודי ','במסך הבא הגדירו את ספריית הסרטים והסדרות')	
        xbmc.executebuiltin('RunScript(plugin.video.thewiz.wall,0,0)')
	

def kodiset():	
    dialog.ok('אשף הגדרת הקודי ','התקנת הרחבות בקליק','במסך הבא בחרו את ההרחבות שתרצו להתקין')	
    xbmc.executebuiltin('RunScript(plugin.program.repotools)')

	
def prsb():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])


    if version >= 15.0 and version <= 15.9:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/ltr.py)')
    if version >= 16.0 and version <= 16.9:
		xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.senyortools/resources/art/ltr.py)')
    if version >= 17.0 and version <= 17.9:
		pass

	
def prs(): 
    Progress.create("מגדיר ומפעיל לקוח טלוויזיה חיה", "נא להמתין...")
    Progress.update(0)
    addonsettings.Prvr_Settings() 
    Progress.update(100)
    videoAddon.prset() 
    prsb()
    Updates()

      
xbmc.executebuiltin("UpdateLocalAddons")
xbmc.executebuiltin("UpdateAddonRepos")      
dialog=xbmcgui.Dialog(); dialog.ok("senyor tools",  "  קיר הסרטים הותקן " ,"","")  

	
