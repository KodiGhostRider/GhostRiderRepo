def get(function, timeout, *args, **table):
     return function(*args)

def clear(table=None):
    return
