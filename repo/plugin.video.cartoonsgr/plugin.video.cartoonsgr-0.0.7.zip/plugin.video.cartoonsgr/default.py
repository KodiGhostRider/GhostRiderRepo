# -*- coding: utf-8 -*-
import urllib, xbmcgui, xbmcaddon, xbmcplugin, xbmc, re, sys, os
import urlresolver 
import unshortenit
import shutil
from resources.lib.modules import client
from addon.common.addon import Addon


ADDON_PATH = xbmc.translatePath('special://home/addons/plugin.video.cartoonsgr')
addon_id = 'plugin.video.cartoonsgr'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
ICON = ADDON_PATH + 'icon.png'
FANART = ADDON_PATH + 'fanart.jpg'
PATH = 'CartoonsGR'
VERSION = '0.0.7'
BASEURL = 'http://paidikestainies.online/'
ART = ADDON_PATH + "/resources/icons/"
ADDON       = xbmcaddon.Addon()
ADDON_DATA  = ADDON.getAddonInfo('profile')
ADDON_PATH  = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART      = ADDON.getAddonInfo('fanart')
ICON        = ADDON.getAddonInfo('icon')
ID          = ADDON.getAddonInfo('id')
NAME        = ADDON.getAddonInfo('name')
VERSION     = ADDON.getAddonInfo('version')
Lang        = ADDON.getLocalizedString
Dialog      = xbmcgui.Dialog()




def Main_addDir():
	addDir('[B][COLOR yellow]' +Lang(32005).encode('utf-8')+ '[/COLOR][/B]',BASEURL,8,ICON,FANART,'')
	addDir('[B][COLOR yellow]' +Lang(32004).encode('utf-8')+ '[/COLOR][/B]',BASEURL+'quality/metaglotismeno/',5,ICON,FANART,'')
	addDir('[B][COLOR yellow]' +Lang(32003).encode('utf-8')+ '[/COLOR][/B]',BASEURL+'quality/ellinikoi-ypotitloi/',5,ICON,FANART,'')
	addDir('[B][COLOR yellow]' +Lang(32000).encode('utf-8')+ '[/COLOR][/B]','',13,ART + 'movies.jpg',FANART,'')
	addDir('[B][COLOR yellow]' +Lang(32001).encode('utf-8')+ '[/COLOR][/B]','',14,ART + 'tvshows.jpg',FANART,'')
	addDir('[B][COLOR gold]' +Lang(32002).encode('utf-8')+ '[/COLOR][/B]','url',6,ICON,FANART,'')
	addDir('[B][COLOR gold]' +Lang(32019).encode('utf-8')+ '[/COLOR][/B]','',17,ICON,FANART,'')
	


def Peliculas():
	addDir('[B][COLOR orangered]' +Lang(32008).encode('utf-8')+ '[/COLOR][/B]',BASEURL,5,ART + 'movies.jpg',FANART,'')
	addDir('[B][COLOR orangered]' +Lang(32006).encode('utf-8')+ '[/COLOR][/B]',BASEURL,3,ART + 'genre.jpg',FANART,'')
	addDir('[B][COLOR orangered]' +Lang(32007).encode('utf-8')+ '[/COLOR][/B]',BASEURL,15,ART + 'etos.jpg',FANART,'')



def Series():
	addDir('[B][COLOR orangered]' +Lang(32006).encode('utf-8')+ '[/COLOR][/B]',BASEURL,7,ART + 'genre.jpg',FANART,'')
	addDir('[B][COLOR orangered]' +Lang(32007).encode('utf-8')+ '[/COLOR][/B]',BASEURL,16,ART + 'etos.jpg',FANART,'')
	addDir('[B][COLOR orangered]' +Lang(32010).encode('utf-8')+ '[/COLOR][/B]',BASEURL+'tvshows-genre/κινούμενα-σχέδια/',4,ART + 'tvshows.jpg',FANART,'')
	addDir('[B][COLOR orangered]' +Lang(32009).encode('utf-8')+ '[/COLOR][/B]',BASEURL+'tvshows/',4,ART + 'tvshows.jpg',FANART,'')



def Get_Genres(url): #3
	OPEN = client.request(url)
	Regex = re.compile('id="moviehome"(.+?)</ul>',re.DOTALL).findall(OPEN)[0]
	Regex2 = re.compile('<li.+?href="(.+?)".+?internal">(.+?)</a>\s*<span>(.+?)</span>',re.DOTALL).findall(str(Regex))
	for url,name, items in Regex2:
		name = clear_Title(name) +' ([COLORlime]'+items+'[/COLOR])'
		addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'movies.jpg',FANART,'')


def year(url):
	OPEN = client.request(url)
	Regex = re.compile('filtro_y">(.+?)</ul>',re.DOTALL).findall(OPEN)[0]
	Regex2 = re.compile('<li>.+?href="(.+?)".+?internal">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
	for url,year in Regex2:
		addDir('[B][COLOR white]%s[/COLOR][/B]' %year,url,5,ART + 'movies.jpg',FANART,'')


def Get_TV_Genres(url): #7
	OPEN = client.request(url)
	Regex = re.compile('id="serieshome"(.+?)</ul>',re.DOTALL).findall(OPEN)[0]
	Regex2 = re.compile('<li.+?href="(.+?)".+?internal">(.+?)</a>\s*<span>(.+?)</span>',re.DOTALL).findall(str(Regex))
	for url,name, items in Regex2:
		name = clear_Title(name) +' ([COLORlime]'+items+'[/COLOR])'
		addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,4,ART + 'tvshows.jpg',FANART,'')


def year_TV(url):
	OPEN = client.request(url)
	Regex = re.compile('filtro_y">(.+?)</ul>',re.DOTALL).findall(OPEN)[1]
	Regex2 = re.compile('<li>.+?href="(.+?)".+?internal">(.+?)</a></li>',re.DOTALL).findall(str(Regex))
	for url,year in Regex2:
		addDir('[B][COLOR white]%s[/COLOR][/B]' %year,url,4,ART + 'tvshows.jpg',FANART,'')


def Get_random(url):#8
	OPEN = client.request(url)
	Regex = re.compile('<div class="item">.+?href="(.+?)".+?src="(.+?)"\s*alt="(.+?)"',re.DOTALL).findall(OPEN)
	for url,icon, name in Regex:
		name = clear_Title(name)
		if '/ ' in name:
			name = name.split('/ ')
			name = name[1]
		else: pass
		if 'tvshows' in url or 'syllogh' in url:
			addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,11,icon,FANART,'')
		else:
			addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
	setView('movies', 'movie-view')

def Get_content(url): #5
	OPEN = client.request(url)
	Regex = re.compile('id="mt-\d{3,}".+?href="(.+?)".+?src="(.+?)".+?alt="(.+?)".+?class="ttx">(.+?)<div.+?"year">(.+?)</span>.+?calidad2">(.+?)</span>', re.DOTALL).findall(OPEN)
	for url,icon, name, desc, year, calidad in Regex:
		calidad = calidad.replace('Μεταγλωτισμένο','Μετ').replace('Ελληνικοί Υπότιτλοι','Υποτ')
		if '/' in calidad:
			calidad = Lang(32014).encode('utf-8')
		elif 'Προσ' in calidad:
			calidad = Lang(32017).encode('utf-8')
		elif calidad == 'Μετ':
			calidad = Lang(32015).encode('utf-8')
		else:
			calidad = Lang(32016).encode('utf-8')		
		desc = clear_Title(desc)
		name = clear_Title(name)
		if '/ ' in name:
			name = name.split('/ ')
			name = name[1] + ' ([COLORlime]'+year+'[/COLOR])'
		else:
			name = name + ' ([COLORlime]' + year + '[/COLOR])'
		if 'tvshows' in url or 'syllogh' in url:
			addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(name,calidad),url,11,icon,FANART,desc)
		else:
			addDir('[B][COLOR white]{0} [{1}][/COLOR][/B]'.format(name,calidad),url,10,icon,FANART,desc)
	try:
		np = re.compile('class="pag_b"><a href="(.+?)"',re.DOTALL).findall(OPEN)
		for url in np:
			page = re.compile('page/(\d+)/',re.DOTALL).findall(url)[0]
			page = '[B][COLORlime]'+page+'[B][COLORwhite])[/B][/COLOR]'
			addDir('[B][COLORgold]>>>' +Lang(32011).encode('utf-8')+ '[/COLOR] [COLORwhite](%s' %page,url,5,ART + 'next.jpg',FANART,'')
	except: pass
	setView('movies', 'movie-view')

def Get_TV_content(url): #4
	OPEN = client.request(url)
	Regex = re.compile('id="mt-\d{3,}".+?href="(.+?)".+?src="(.+?)".+?alt="(.+?)".+?class="ttx">(.+?)<div', re.DOTALL).findall(OPEN)
	for url,icon, name, desc in Regex:
		desc = clear_Title(desc)
		name = clear_Title(name)
		if '/ ' in name:
			name = name.split('/ ')
			name = name[1]
		else: pass
		if 'tvshows' in url or 'syllogh' in url:
			addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,11,icon,FANART,desc)
		else:
			addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,desc)
	try:
		np = re.compile('class="pag_b"><a href="(.+?)"',re.DOTALL).findall(OPEN)
		for url in np:
			page = re.compile('page/(\d+)/',re.DOTALL).findall(url)[0]
			page = '[B][COLORlime]'+page+'[B][COLORwhite])[/B][/COLOR]'
			addDir('[B][COLORgold]>>>' +Lang(32011).encode('utf-8')+ '[/COLOR] [COLORwhite](%s' %page,url,4,ART + 'next.jpg',FANART,'')
	except: pass
	setView('movies', 'movie-view')



def Get_links(name,url):
	name = re.sub('\)\s*\[.+?]',')',name)
	OPEN = client.request(url)
	calidad = re.compile('class="calidad2">(.+?)</span>',re.DOTALL).findall(OPEN)[0]
	if 'Προσε' in calidad:
		trailer = Trailer(url)
		addDir('[B][COLOR white]%s | [B][COLOR lime]Trailer[/COLOR][/B]' %name,trailer,100,iconimage,FANART,'')
	else:	
		Regex = re.compile('<h2 class=(.+?)</div>|<b>Δείτε(.+?)</b></div>|<strong>Δειτε(.+?)</em></p>',re.DOTALL).findall(OPEN)[0]
		Regex2 = re.compile('<a href="(.+?)".+?noreferrer">(.+?)</a>', re.DOTALL).findall(str(Regex))
		description = Sinopsis(url)
		trailer = Trailer(url)
		addDir('[B][COLOR white]%s | [B][COLOR lime]Trailer[/COLOR][/B]' %name,trailer,100,iconimage,FANART,'')
		for url,title in Regex2:
			title = clear_Title(title)
			if 'buck' in url: continue
			if 'adf.ly' in url :
				url = unshortenit.unshorten(url)
				if not url[1] == 200: continue
				else:
					url = url[0]

			if 'easybytez' in url: continue
			if 'zippy' in url: continue
			if 'flash' in url: continue
			title = name + ' [B]|' +'[B]' +title
			addDir('[B][COLOR white]%s[/COLOR][/B]' %title,url,100,iconimage,FANART,str(description))
	setView('movies', 'movie-view')



def Get_epis_links(name,url):#11
	OPEN = client.request(url)
	Regex2 = re.compile('<a href="(http[s]?://adf.ly.+?|http[s]?://vidlox.+?|http[s]?://openload.+?|http[s]?://vidto.+?|http[s]?://streamin.+?)".+?target="_blank".*?>(.*?)</a>', re.DOTALL).findall(OPEN)
	description = Sinopsis(url)
	trailer = Trailer(url)
	addDir('[B][COLOR white]%s | [B][COLOR lime]Trailer[/COLOR][/B]' %name,trailer,100,iconimage,FANART,'')
	for url, title in Regex2:
		title = clear_Title(title)
		if title == "": 
			title = Lang(32018).encode('utf-8')
		if 'buck' in url: continue
		if '73901' in url:
				url = url.split('http')[2]
				url = 'http' + url
		elif 'adf.ly' in url:
			url = unshortenit.unshorten(url)
			if not url[1] == 200: continue
			else:
				url = url[0]
		if 'easybytez' in url: continue
		if 'zippy' in url: continue
		if 'flash' in url: continue

		addDir('[B][COLOR white]%s[/COLOR][/B]' %title,url,100,iconimage,FANART,str(description))
	setView('movies', 'movie-view')


def Sinopsis(url):
	OPEN = client.request(url)
	OPEN = OPEN.replace('<p>&nbsp;</p>','')
	pattern = ['<p><span.+?12pt;"><strong>(.+?)</p>',
			   '<div itemprop="description">\n<p>(.+?)</span></p>\n<p>',
			   '<div itemprop="description">.+?<strong>(.+?)</strong></span></p>.+?responsive-tabs">',
			   'id="cap1".+?<p><strong>(.+?)</strong></p>.+?responsive-tabs">',
			   '<div itemprop="description">.+?</span></p>\s*<p>(.+?)</p>.+?<h2\sclass=',
			   '<div itemprop="description".+?>\s*<p>(.+?)</p>',
			   '<div itemprop="description".+?>\s*<strong>(.+?)</div>',
			   '<div itemprop="description".+?".+?14pt;">(.+?)</span></p>',
			   '<div itemprop="description">\s*<p>(.+?)</p>']
	try:
		for pattern in pattern:
			Sinopsis = re.findall(pattern, OPEN, flags=re.DOTALL)
			for part in Sinopsis:
				if 'http' in part:
					continue
				part = re.sub('<s.*?>', '', part)
				part = re.sub('</s.*?>', '', part)
				desc = clear_Title(part)
				return desc
	except: pass

def Trailer(url):
	OPEN = client.request(url)
	patron = 'class="youtube_id.+?src="([^"]+)".+?></iframe>'
	trailer_link = find_single_match(OPEN,patron)
	trailer_link = trailer_link.replace('//www.','http://')
	return trailer_link


def Search():
		keyb = xbmc.Keyboard('', 'Search')
		keyb.doModal()
		if (keyb.isConfirmed()):
				search = keyb.getText().replace(' ','+')
				url = BASEURL + "?s=" + search
				Get_TV_content(url)
		else: return

########################################

def find_single_match(data,patron,index=0):
	try:
		matches = re.findall( patron , data , flags=re.DOTALL )
		return matches[index]
	except:
		return ""


def clear_Title(txt):
	txt = re.sub('(\d{4})','',txt)
	txt = txt.replace("&quot;", "\"").replace('()','').replace("&#038;", "&").replace('&#8211;',':').replace('<b>','').replace('\n',' ')
	txt = txt.replace("&amp;", "&").replace('&#8217;',"'").replace('&#039;',':').replace('&#;','\'').replace('</b>','')
	txt = txt.replace("&#38;", "&").replace('&#8221;','"').replace('&#8216;','"').replace('&amp;#038;','&').replace('&#160;','')
	txt = txt.replace("&nbsp;", "").replace('</a>','').replace('<br />','').replace('&#8220;','"').replace('&#8216;','"').replace('\t',' ')
	return txt



def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok



def resolve(name,url,iconimage,description):
	host = url
	stream_url = evaluate(host)
	name = name.split(' [B]|')[0]
	try:
		liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
		liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description })
		liz.setProperty("IsPlayable","true")
		liz.setPath(str(stream_url))
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
	except:
		xbmc.executebuiltin("XBMC.Notification("+Lang(32012)+" ,2000)")

def evaluate(host):
	try:
		if 'userscloud' in host:
			OPEN = client.request(host)
			host = re.compile('<source src="(.+?)"',re.DOTALL).findall(OPEN)
			host = urlresolver.resolve(str(host))

		elif 'gamovideo' in host:
			cookie = client.request(host, output='cookie', close=False)
			OPEN = client.request(host, cookie=cookie, referer=BASEURL)
			host = re.compile('file: "(.+?)"',re.DOTALL).findall(OPEN)[1]

		elif 'streamin' in host:
			host = urlresolver.resolve(host)

		
		elif urlresolver.HostedMediaFile(host):
			host = urlresolver.resolve(host)

		return host
	except:pass


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]
	return param

params=get_params()
url=BASEURL
name=NAME
iconimage=ICON
mode=None
fanart=FANART
description=DESCRIPTION
query=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		iconimage=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:        
		mode=int(params["mode"])
except:
		pass		
try:        
		fanart=urllib.unquote_plus(params["fanart"])
except:
		pass
try:        
		description=urllib.unquote_plus(params["description"])
except:
		pass

def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

def check_source():
	REPO_PATH = xbmc.translatePath('special://home/addons/repository.GRecoTM')
	if not os.path.exists(REPO_PATH):
		shutil.rmtree(ADDON_PATH, ignore_errors=True)
		Dialog.ok(PATH,Lang(32013))

def Open_settings():
	selfAddon.openSettings(sys.argv[0])
	return Main_addDir()



print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


#########################################################

if mode == None: Main_addDir()
elif mode == 3 : Get_Genres(url)
elif mode == 4 : Get_TV_content(url)
elif mode == 5 : Get_content(url)
elif mode == 6 : Search()
elif mode == 7 : Get_TV_Genres(url)
elif mode == 8 : Get_random(url)
elif mode == 10 : Get_links(name,url)
elif mode == 11 : Get_epis_links(name,url)
elif mode == 13 : Peliculas()
elif mode == 14 : Series()
elif mode == 15 : year(url)
elif mode == 16 : year_TV(url)
elif mode == 17 : Open_settings()
elif mode == 100 : resolve(name,url,iconimage,description)

check_source()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
