# -*- coding: utf-8 -*-
# KodiAddon (Adult Swim)
#
from t1mlib import t1mAddon
from operator import itemgetter
import json, re, urllib, urllib2, xbmcplugin, xbmcgui, xbmc, time, sys, os


class myAddon(t1mAddon):
    def getAddonMenu(self, url, ilist):
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        epiHTML = self.getRequest('http://www.adultswim.com/videos')
        shows = re.search("""__AS_INITIAL_DATA__\s*=\s*({.*?});""", epiHTML).groups()[0]
        shows = json.loads(shows.replace("\/", "/"))
        shows = shows["shows"]
        
        blacklist = ["live simulcast", "music videos", "on cinema", "promos", "shorts", 'williams street swap shop', 'stupid morning bullshit', 'last stream on the left', 'fishcenter live', 'convention panels']
        for show in shows:
            name = show["title"].encode("utf-8")
            if not any(x in name.lower() for x in blacklist):
                poster = self.addonIcon
                infoList = {}
                infoList['Title'] = name
                infoList['TVShowTitle'] = name
                infoList['mediatype'] = 'tvshow'
                infoList['Studio'] = 'Adult Swim'
                url = show
                contextMenu = []
                url = show["url"]
                url = 'http://www.adultswim.com' + url
                ilist = self.addMenuItem(name, 'GE', ilist, url, poster, self.addonFanart, infoList, isFolder=True, cm=contextMenu)
            else:
                continue
                
        return(ilist)

    def getAddonEpisodes(self, url, ilist):
        html = self.getRequest(url)
        epis = re.search("""__AS_INITIAL_DATA__\s*=\s*({.*?});""", html).groups()[0]
        epis = json.loads(epis.replace("\/", "/"))
        epis = epis["show"]["videos"]
        #epis = sorted(epis, key=itemgetter('launch_date')) 

        for epi in epis:
            if epi["type"] == 'episode' and not epi["auth"]:
                name = epi['title'].encode("utf-8")
                #name = name if not epi["auth"] else "[COLOR red]%s[/COLOR]" % name
                try: fanart = epi['images'][1]["url"] if not epi['images'][1]["url"] == "" else self.addonFanart
                except: fanart = self.addonFanart
                try: thumb = epi['images'][0]["url"] if not epi['images'][0]["url"] == "" else self.addonIcon
                except: thumb = self.addonIcon
                infoList = {}
                try: infoList['Date'] = time.strftime('%Y-%m-%d', time.localtime(int(epi['launch_date'])))
                except: infoList['Date'] = time.strftime('%Y-%m-%d', time.localtime(0))
                infoList['Aired'] = infoList['Date']
                infoList['Duration'] = str(int(epi['duration']))
                infoList['MPAA'] = epi['tv_rating']
                try: infoList['TVShowTitle'] = epi['collection_title']
                except: pass
                infoList['Title'] = name
                infoList['Episode'] = epi["episode_number"]
                infoList['Season'] = epi["season_number"]
                infoList['Plot'] = epi["description"].encode("utf-8")
                infoList['mediatype'] = 'episode'
                url = epi["id"]
                ilist = self.addMenuItem(name, 'GV', ilist, url, thumb, fanart, infoList, isFolder=False)
            else:
                continue

        if len(ilist) == 0:
            ilist = self.addMenuItem("No episodes available to stream", 'GV', ilist, '', self.addonIcon, self.addonFanart, '', isFolder=False)

        return(ilist)

    def getAddonVideo(self, url):
        ep_id = url
        api_url = 'http://www.adultswim.com/videos/api/v2/videos/%s?fields=title,type,duration,collection_title,images,stream,segments,title_id&iframe=false' % ep_id
        api_data = self.getRequest(api_url)
        api_data = api_data.replace("\/", "/")
        try: a = json.loads(api_data)
        except:
            dialog = xbmcgui.Dialog()
            dialog.notification("Adult Swim", 'Unable to retrieve sources', xbmcgui.NOTIFICATION_WARNING, 3000)
            sys.exit()
        sources = a["data"]["stream"]["assets"]
        u = None
        for source in sources:
            if source["mime_type"]== "application/x-mpegURL" and self.__test_stream(source["url"]):
               u = source["url"]
               break
        if not u: 
            dialog = xbmcgui.Dialog()
            dialog.notification("Adult Swim", 'No playable streams found', xbmcgui.NOTIFICATION_WARNING, 3000)
            sys.exit()
        liz = xbmcgui.ListItem(path = u)
        infoList ={}
        infoList['mediatype'] = xbmc.getInfoLabel('ListItem.DBTYPE')
        infoList['Title'] = xbmc.getInfoLabel('ListItem.Title')
        infoList['TVShowTitle'] = xbmc.getInfoLabel('ListItem.TVShowTitle')
        infoList['Year'] = xbmc.getInfoLabel('ListItem.Year')
        infoList['Premiered'] = xbmc.getInfoLabel('Premiered')
        infoList['Plot'] = xbmc.getInfoLabel('ListItem.Plot')
        infoList['Studio'] = xbmc.getInfoLabel('ListItem.Studio')
        infoList['Genre'] = xbmc.getInfoLabel('ListItem.Genre')
        infoList['Duration'] = xbmc.getInfoLabel('ListItem.Duration')
        infoList['MPAA'] = xbmc.getInfoLabel('ListItem.Mpaa')
        infoList['Aired'] = xbmc.getInfoLabel('ListItem.Aired')
        infoList['Season'] = xbmc.getInfoLabel('ListItem.Season')
        infoList['Episode'] = xbmc.getInfoLabel('ListItem.Episode')
        liz.setInfo('video', infoList)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

    def __test_stream(self, stream_url):
        '''
        Returns True if the stream_url gets a non-failure http status (i.e. <400) back from the server
        otherwise return False

        Intended to catch stream urls returned by resolvers that would fail to playback
        '''
        # parse_qsl doesn't work because it splits elements by ';' which can be in a non-quoted UA
        try: headers = dict([item.split('=') for item in (stream_url.split('|')[1]).split('&')])
        except: headers = {}
        for header in headers:
            headers[header] = urllib.unquote_plus(headers[header])

        try:
            msg = ''
            request = urllib2.Request(stream_url.split('|')[0], headers=headers)
            #  set urlopen timeout to 15 seconds
            http_code = urllib2.urlopen(request, timeout=15).getcode()
        except urllib2.URLError as e:
            if hasattr(e, 'reason'):
                # treat an unhandled url type as success
                if 'unknown url type' in str(e.reason).lower():
                    return True
                else:
                    msg = e.reason
                    
            if isinstance(e, urllib2.HTTPError):
                http_code = e.code
            else:
                http_code = 600
            if not msg: msg = str(e)
        except Exception as e:
            http_code = 601
            msg = str(e)

        return int(http_code) < 400
